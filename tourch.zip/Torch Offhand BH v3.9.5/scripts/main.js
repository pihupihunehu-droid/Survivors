import {world, system, EquipmentSlot, ItemStack, EntityEquippableComponent, BlockPermutation} from "@minecraft/server";
import {ActionFormData, ModalFormData} from '@minecraft/server-ui';

let light_distance = 2;
let only_survival = false;
let place_torch = true;
let holding_sound = false;
export function configBP(p){
  const modalForm = new ModalFormData()
    .title('§l§6--Torch Config--') 
    .dropdown(
      { translate: "dropdown.config.distance" },
      [
        { translate: "dropdown.config.distance_low" },
        { translate: "dropdown.config.distance_mid" },
        { translate: "dropdown.config.distance_high" }
      ],
      light_distance
    )
    .toggle({ translate: "toggle.config.place_torch" }, Boolean(place_torch))
    .toggle({ translate: "toggle.config.only_survival" }, Boolean(only_survival))
    .toggle({ translate: "toggle.config.holding_sound" }, Boolean(holding_sound));
  modalForm.show(p).then((response) => {
    if (response.canceled) return;
    const [distance, placeTorch, onlySurvival, soundHolding] = response.formValues;
    light_distance = Number(distance) || 0;
		world.setDynamicProperty("light_distance", distance);

    place_torch = placeTorch;
		world.setDynamicProperty("place_torch", place_torch);

    only_survival = onlySurvival;
		world.setDynamicProperty("only_survival", only_survival);

    holding_sound = soundHolding;
		world.setDynamicProperty("holding_sound", holding_sound);
  });
}

export function addItem(player, itemId, keepOnDeath, lockMode, lore){
	let container = player.getComponent("inventory").container;
	let item = new ItemStack(itemId);
	item.keepOnDeath = keepOnDeath
	item.lockMode = lockMode;
	item.setLore(lore);
	container.addItem(item);
}

world.afterEvents.playerSpawn.subscribe(({player: p})=>{
   if(!p.hasTag("t_book_config")){
      p.runCommand("gamerule showtags false")
      addItem(p, "stv:t_book_config", true, "none", [""]);
      const defaultProperties = {
          light_distance: 2,
          place_torch: true,
          only_survival: false,
          holding_sound: false
      };
      for (const [key, value] of Object.entries(defaultProperties)) {
        if (world.getDynamicProperty(key) === undefined) {
            world.setDynamicProperty(key, value);
        }
      }
      p.addTag("t_book_config")
   }
})

const light_all = ["minecraft:redstone_torch", "minecraft:soul_torch", "minecraft:torch", "minecraft:sea_pickle", "minecraft:copper_torch"]

let torch= 15
let storch= 13
let rtorch= 11
let seaP= 13

system.runInterval( () =>{
  try{
    for(const p of world.getPlayers()){
      config_default(p);
      const inv = p.getComponent("minecraft:inventory")?.container;
      if (inv) {
        for (let slot = 0; slot < inv.size; slot++) {
          const item = inv.getItem(slot);
          if (!item) continue;
          const id = item.typeId;
          const lore = item.getLore?.() ?? [];
          if (lore.length === 0) {
            if (id === "minecraft:sea_pickle") {
              item.setLore([`§6Lighting: §7${seaP} Blocks`, "You can use it underwater"]);
              inv.setItem(slot, item);
            }
            if (id === "minecraft:torch") {
              item.setLore([`§6Lighting: §7${torch} Blocks`]);
              inv.setItem(slot, item);
            }
            if (id === "minecraft:soul_torch") {
              item.setLore([`§6Lighting: §7${storch} Blocks`]);
              inv.setItem(slot, item);
            }
            if (id === "minecraft:redstone_torch") {
              item.setLore([`§6Lighting: §7${rtorch} Blocks`]);
              inv.setItem(slot, item);
            }
            if (id === "minecraft:copper_torch") {
              item.setLore([`§6Lighting: §7${storch} Blocks`]);
              inv.setItem(slot, item);
            }
          }
        }
      }
      const equip = p.getComponent(EntityEquippableComponent.componentId);
      const hand = equip.getEquipment(EquipmentSlot.Mainhand);
      const offhand = equip.getEquipment(EquipmentSlot.Offhand);
      for(const offlight of light_all){
        if(p.hasTag("offhand") && !p.hasTag("mainhand")){
          p.removeTag("offhand")
          p.runCommandAsync(`execute as @s[hasitem={item=${offlight},location=slot.weapon.offhand,quantity=0}] run function no_light`);
        }
      }
      for(const light of light_all){
        if(p.hasTag("mainhand") && !p.hasTag("offhand")){
          p.removeTag("mainhand")
          p.runCommandAsync(`execute as @s[hasitem={item=${light},location=slot.weapon.mainhand,quantity=0}] run function no_light`);
        }
      }
      if(!only_survival||p.matches({ gameMode: "survival" })){
        if(offhand){
          if(offhand.typeId=="minecraft:torch"){
            p.addTag("offhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function light${torch}`);
          }
          if(offhand.typeId=="minecraft:sea_pickle"){
            p.addTag("offhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function sea_pickle${seaP}`);
          }
          if(offhand.typeId=="minecraft:soul_torch"){
            p.addTag("offhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function light${storch}`);
          }
          if(offhand.typeId=="minecraft:redstone_torch"){
            p.addTag("offhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function light${rtorch}`);
          }
          if(offhand.typeId=="minecraft:copper_torch"){
            p.addTag("offhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function light${storch}`);
          }
        }
        if(hand && !p.hasTag("offhand")){
          if(hand.typeId=="minecraft:torch"){
            p.addTag("mainhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function light${torch}`);
          }
          if(hand.typeId=="minecraft:sea_pickle"){
            p.addTag("mainhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function sea_pickle${seaP}`);
          }
          if(hand.typeId=="minecraft:soul_torch"){
            p.addTag("mainhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function light${storch}`);
          }
          if(hand.typeId=="minecraft:copper_torch"){
            p.addTag("mainhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function light${storch}`);
          }
          if(hand.typeId=="minecraft:redstone_torch"){
            p.addTag("mainhand")
            p.runCommandAsync(`execute as @s positioned ~~1~1 run function light${rtorch}`);
          }
        }
      }
      if (holding_sound) {
        const hasTorchMain = hand?.typeId.includes("torch");
        const hasTorchOff = offhand?.typeId.includes("torch");
        if (hasTorchMain) {
          if (!p.hasTag("holding_sound")) {
            p.playSound("fire.ignite");
            p.addTag("holding_sound");
          }
        } else {
          p.removeTag("holding_sound");
        }
        if (hasTorchOff) {
          if (!p.hasTag("holding_sound_off")) {
            p.playSound("fire.ignite");
            p.addTag("holding_sound_off");
          }
        } else {
          p.removeTag("holding_sound_off");
        }
      } else {
        p.removeTag("holding_sound");
        p.removeTag("holding_sound_off");
      }
    } 
  }catch(e){

  }
})


export function getEquip(p, itemId, slot) {
  const equipComp = p.getComponent("minecraft:equippable");
  const equiItem = equipComp?.getEquipment(slot);
  if(equipComp&&equiItem&&equiItem.typeId.includes(itemId)){
    return equiItem;
  }else{
    return false
  }
}
world.afterEvents.entityHitBlock.subscribe(({ hitBlock, damagingEntity }) => {
    if(place_torch){
      const equip = getEquip(damagingEntity, "torch", "Offhand");
      if (!equip || !damagingEntity.isSneaking) return;
      const view = damagingEntity.getBlockFromViewDirection({
          maxDistance: 7
      });
      if (!view?.block) return;
      const block = view.block;
      const face = view.face;
      let x = block.location.x;
      let y = block.location.y;
      let z = block.location.z;
      switch (face) {
          case "Up": y++; break;
          case "Down": y--; break;
          case "North": z--; break;
          case "South": z++; break;
          case "East": x++; break;
          case "West": x--; break;
      }
      const placeBlock = block.dimension.getBlock({ x, y, z });
      if (placeBlock?.isAir) {
          placeBlock.setPermutation(
              BlockPermutation.resolve(equip.typeId)
          );
          damagingEntity.runCommand(`/clear @s ${equip.typeId} 0 1`)
      }
    }
});
world.afterEvents.itemUse.subscribe(use =>{
  let item = use.itemStack;
  let p = use.source;
  let equip = p.getComponent(EntityEquippableComponent.componentId);
  let off = equip.getEquipment(EquipmentSlot.Offhand);
  const b = p.getBlockFromViewDirection({maxDistance: 8})
  if(!b){
    if (item.typeId === "stv:t_book_config") {
      configBP(p);
    }
    if(item.typeId == "minecraft:torch"||item.typeId == "minecraft:redstone_torch"||item.typeId == "minecraft:soul_torch"||item.typeId == "minecraft:sea_pickle"||item.typeId == "minecraft:copper_torch"){
      if(off == undefined){
        p.runCommand(`replaceitem entity @s slot.weapon.offhand 0 ${item.typeId} ${item.amount}`)
        equip.setEquipment(EquipmentSlot.Mainhand, undefined)
      }
    }
  }
})

export function config_default(p){
  torch=light_distance==0?6:light_distance==1?10:15
  storch=light_distance==0?5:light_distance==1?8:13
  rtorch=light_distance==0?4:light_distance==1?7:11
  seaP=light_distance==0?6:light_distance==1?9:13

	light_distance = Number(world.getDynamicProperty("light_distance") ?? 2);

	only_survival = Boolean(world.getDynamicProperty("only_survival") ?? false);
	place_torch = Boolean(world.getDynamicProperty("place_torch") ?? true);
	holding_sound = Boolean(world.getDynamicProperty("holding_sound") ?? true);
}
