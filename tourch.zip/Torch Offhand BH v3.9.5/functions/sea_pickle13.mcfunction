fill ~~~  ~ ~1 ~ light_block ["block_light_level"=13] replace air
fill ~4 ~2 ~4 ~-4 ~4 ~-4 air [] replace light_block ["block_light_level"=13]
fill ~4 ~-1 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=13]
fill ~4 ~2 ~4 ~1 ~ ~1 air [] replace light_block ["block_light_level"=13]
fill ~-4 ~2 ~-4 ~-1 ~ ~-1 air [] replace light_block ["block_light_level"=13]
fill ~4 ~2 ~-4 ~1 ~ ~-1 air [] replace light_block ["block_light_level"=13]
fill ~-4 ~2 ~4 ~-1 ~ ~1 air [] replace light_block ["block_light_level"=13]
fill ~-4 ~2 ~ ~-1 ~ ~ air [] replace light_block ["block_light_level"=13]
fill ~4 ~2 ~ ~1 ~ ~ air [] replace light_block ["block_light_level"=13]
fill ~ ~2 ~-4 ~ ~ ~-1 air [] replace light_block ["block_light_level"=13]
fill ~ ~2 ~4 ~ ~ ~1 air [] replace light_block ["block_light_level"=13]


fill ~4 ~4 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=15]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=6]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=11]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=10]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=9]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=8]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=7]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=5]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 air [] replace light_block ["block_light_level"=4]



fill ~~~  ~ ~1 ~ light_block ["block_light_level"=13] replace water
fill ~4 ~2 ~4 ~-4 ~4 ~-4 water [] replace light_block ["block_light_level"=13]
fill ~4 ~-1 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=13]
fill ~4 ~2 ~4 ~1 ~ ~1 water [] replace light_block ["block_light_level"=13]
fill ~-4 ~2 ~-4 ~-1 ~ ~-1 water [] replace light_block ["block_light_level"=13]
fill ~4 ~2 ~-4 ~1 ~ ~-1 water [] replace light_block ["block_light_level"=13]
fill ~-4 ~2 ~4 ~-1 ~ ~1 water [] replace light_block ["block_light_level"=13]
fill ~-4 ~2 ~ ~-1 ~ ~ water [] replace light_block ["block_light_level"=13]
fill ~4 ~2 ~ ~1 ~ ~ water [] replace light_block ["block_light_level"=13]
fill ~ ~2 ~-4 ~ ~ ~-1 water [] replace light_block ["block_light_level"=13]
fill ~ ~2 ~4 ~ ~ ~1 water [] replace light_block ["block_light_level"=13]


fill ~4 ~4 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=15]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=6]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=11]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=10]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=9]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=8]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=7]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=5]
fill ~4 ~4 ~4 ~-4 ~-2 ~-4 water [] replace light_block ["block_light_level"=4]