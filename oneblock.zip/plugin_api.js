$ sudo Summon free Coffe
$ sudo Give Money 99999
=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=

□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□
□□□□■■■■■■□□□■■■■■■□□□□■■■■■■■□□□□□
□□□□■■■■□□□□□■■□□□□■□□□■■■■■■■□□□□□
□□□□■■□□□□□□□■■□□□□■□□□□□□□□■■□□□□□
□□□□■■□□□□□□□■■■■■■□□□□□□□□■■□□□□□□
□□□□■■□□□□□□□■■■■■■□□□□□□■■□□□□□□□□
□□□□■■□□□□□□□■■□□□□■□□□■■□□□□□□□□□□
□□□□■■■■□□□□□■■□□□□■□□□■■■■■■■□□□□□
□□□□■■■■■■□□□■■■■■■□□□□■■■■■■■□□□□□
□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□□


Through this document we let you know that our "CBZ Studio" team works continuously to offer you quality content, for which we kindly ask you to respect the following.

You Can :

- Modify our content for personal use only
- Use our plugins for your projects as long as you grant us our credits
- Share our work on gameplays or reviews, as long as you put our credits and original download links in the description.
- Report to users or platforms that are violating these terms and conditions.

Its Forbidden :

- Remove creator credits
- Modify or steal our content
- Add your own shorteners or ads to download our content
- Re-upload our content on other platforms without authorization

[] WARNING!! []
If our team finds content of our authorship on other platforms without authorization and that violate our copyright terms and conditions, we will proceed to legally report it on the corresponding platform, since it would be considered a fraudulent act, in addition to which you must pay compensation for lost and illegal distribution of our content (All this will come from not reaching an agreement)

To get permission or information you can contact us via Email or you can meet me at my apartement.

Apartement: Jl. jalan ketepi pantai, jangan lupa ngopi sambil nyantai, pos code 55555
•[🇮🇩] Design    : Arta Mulyana
•[🇮🇩] Debuger : Nabila Rachmadani

[] Social Media []      
Email      : cbz.official.id@gmail.com
IG            : @Curezor
Youtube : CubeyzM

No other person than the mentioned Owner or Manager can grant permissions regarding the content of the CBZ Studio.
=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=