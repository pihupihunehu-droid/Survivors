execute @e[tag=on-block,rm=0] ~ ~ ~ tag @s add m0
execute @e[tag=m0] ~ ~ ~ clear @a mojang.minecraft:ascend
execute @e[tag=m0] ~ ~ ~ summon mojang.minecraft:entity "§bBox Menu" 0 3.545 0
execute @e[tag=m0] ~ ~ ~ summon mojang.minecraft:main "Hold here to open" 0 3 0
execute @e[tag=m0] ~ ~ ~ tag @e[type=mojang.minecraft:entity,r=1,x=0,y=3.545,z=0] add dis
execute @e[tag=m0] ~ ~ ~ tag @e[type=mojang.minecraft:main] add npc
execute @e[tag=m0] ~ ~ ~ tellraw @p {"rawtext":[{"text":"§7Menu GUI has been §aenabled"}]}
execute @e[tag=on-block,tag=!m0] ~ ~ ~ tellraw @p {"rawtext":[{"text":"§cFailed to open menu, you're in another dimension. Go back to acces the menu"}]}
execute @e[tag=on-block,tag=!m0] ~ ~ ~ give @p[hasitem={item=mojang.minecraft:ascend,quantity=..0}] mojang.minecraft:ascend 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
tag @e[tag=on-block] remove m0
kill @s