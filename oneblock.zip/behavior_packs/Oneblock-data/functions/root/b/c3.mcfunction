# functions/root/b/c3.mcfunction

# Oak Log (log 0)
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=10..}] ~ ~ ~ clear @s log 0 10

# Birch Log (log 2)
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=10..}] ~ ~ ~ clear @s log 2 10

# Spruce Log (log 1)
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=10..}] ~ ~ ~ clear @s log 1 10

# Jungle Log (log 3)
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=10..}] ~ ~ ~ clear @s log 3 10

# Acacia Log (log 4)
execute @s[scores={buy=5},hasitem={item=wheat,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=5},hasitem={item=wheat,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=5},hasitem={item=wheat,quantity=10..}] ~ ~ ~ clear @s wheat 0 10

# Dark Log (log 5)
execute @s[scores={buy=6},hasitem={item=apple,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=6},hasitem={item=apple,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=6},hasitem={item=apple,quantity=10..}] ~ ~ ~ clear @s apple 0 10

# Potato
execute @s[scores={buy=7},hasitem={item=potato,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=7},hasitem={item=potato,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=7},hasitem={item=potato,quantity=10..}] ~ ~ ~ clear @s potato 0 10

# Bone
execute @s[scores={buy=8},hasitem={item=bone,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=8},hasitem={item=bone,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=8},hasitem={item=bone,quantity=10..}] ~ ~ ~ clear @s bone 0 10

# Gunpowder
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=10..}] ~ ~ ~ clear @s gunpowder 0 10

# Gold Ingot
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=10..}] ~ ~ ~ clear @s gold_ingot 0 10

# Emerald
execute @s[scores={buy=11},hasitem={item=emerald,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=11},hasitem={item=emerald,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=11},hasitem={item=emerald,quantity=10..}] ~ ~ ~ clear @s emerald 0 10

# Diamond
execute @s[scores={buy=12},hasitem={item=diamond,quantity=..9}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=12},hasitem={item=diamond,quantity=10..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=12},hasitem={item=diamond,quantity=10..}] ~ ~ ~ clear @s diamond 0 10