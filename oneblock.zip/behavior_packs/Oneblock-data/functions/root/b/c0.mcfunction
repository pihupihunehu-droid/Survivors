scoreboard players operation @s cash += @s temp
scoreboard players operation @s ec2 += @s temp
tellraw @s[scores={count=1}] {"rawtext":[{"translate":"mojang.text.msg27"},{"score":{"name":"@s","objective":"temp"}}]}
tellraw @s[scores={count=!1}] {"rawtext":[{"translate":"mojang.text.msg18"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg19"},{"score":{"name":"@s","objective":"temp"}}]}

#mojang.text.msg20=§aPembelian berhasil! Uang anda dikurangi sebesar §c-§7$§e
#mojang.text.msg21=§cUang tidak cukup!
