# functions/root/b/c4.mcfunction

# Oak Log (log 0)
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=50..}] ~ ~ ~ clear @s log 0 50

# Birch Log (log 2)
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=50..}] ~ ~ ~ clear @s log 2 50

# Spruce Log (log 1)
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=50..}] ~ ~ ~ clear @s log 1 50

# Jungle Log (log 3)
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=50..}] ~ ~ ~ clear @s log 3 50

# Acacia Log (log 4)
execute @s[scores={buy=5},hasitem={item=wheat,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=5},hasitem={item=wheat,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=5},hasitem={item=wheat,quantity=50..}] ~ ~ ~ clear @s wheat 0 50

# Dark Log (log 5)
execute @s[scores={buy=6},hasitem={item=apple,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=6},hasitem={item=apple,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=6},hasitem={item=apple,quantity=50..}] ~ ~ ~ clear @s apple 0 50

# Potato
execute @s[scores={buy=7},hasitem={item=potato,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=7},hasitem={item=potato,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=7},hasitem={item=potato,quantity=50..}] ~ ~ ~ clear @s potato 0 50

# Bone
execute @s[scores={buy=8},hasitem={item=bone,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=8},hasitem={item=bone,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=8},hasitem={item=bone,quantity=50..}] ~ ~ ~ clear @s bone 0 50

# Gunpowder
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=50..}] ~ ~ ~ clear @s gunpowder 0 50

# Gold Ingot
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=50..}] ~ ~ ~ clear @s gold_ingot 0 50

# Emerald
execute @s[scores={buy=11},hasitem={item=emerald,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=11},hasitem={item=emerald,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=11},hasitem={item=emerald,quantity=50..}] ~ ~ ~ clear @s emerald 0 50

# Diamond
execute @s[scores={buy=12},hasitem={item=diamond,quantity=..49}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=12},hasitem={item=diamond,quantity=50..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=12},hasitem={item=diamond,quantity=50..}] ~ ~ ~ clear @s diamond 0 50