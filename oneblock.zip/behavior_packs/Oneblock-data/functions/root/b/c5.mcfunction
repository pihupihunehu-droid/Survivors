# functions/root/b/c5.mcfunction

# Oak Log (log 0)
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=100..}] ~ ~ ~ clear @s log 0 100

# Birch Log (log 2)
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=100..}] ~ ~ ~ clear @s log 2 100

# Spruce Log (log 1)
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=100..}] ~ ~ ~ clear @s log 1 100

# Jungle Log (log 3)
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=100..}] ~ ~ ~ clear @s log 3 100

# Acacia Log (log 4)
execute @s[scores={buy=5},hasitem={item=wheat,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=5},hasitem={item=wheat,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=5},hasitem={item=wheat,quantity=100..}] ~ ~ ~ clear @s wheat 0 100

# Dark Log (log 5)
execute @s[scores={buy=6},hasitem={item=apple,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=6},hasitem={item=apple,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=6},hasitem={item=apple,quantity=100..}] ~ ~ ~ clear @s apple 0 100

# Potato
execute @s[scores={buy=7},hasitem={item=potato,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=7},hasitem={item=potato,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=7},hasitem={item=potato,quantity=100..}] ~ ~ ~ clear @s potato 0 100

# Bone
execute @s[scores={buy=8},hasitem={item=bone,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=8},hasitem={item=bone,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=8},hasitem={item=bone,quantity=100..}] ~ ~ ~ clear @s bone 0 100

# Gunpowder
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=100..}] ~ ~ ~ clear @s gunpowder 0 100

# Gold Ingot
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=100..}] ~ ~ ~ clear @s gold_ingot 0 100

# Emerald
execute @s[scores={buy=11},hasitem={item=emerald,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=11},hasitem={item=emerald,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=11},hasitem={item=emerald,quantity=100..}] ~ ~ ~ clear @s emerald 0 100

# Diamond
execute @s[scores={buy=12},hasitem={item=diamond,quantity=..99}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=12},hasitem={item=diamond,quantity=100..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=12},hasitem={item=diamond,quantity=100..}] ~ ~ ~ clear @s diamond 0 100