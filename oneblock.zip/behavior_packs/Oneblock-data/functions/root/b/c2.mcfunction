# functions/root/b/c2.mcfunction

# Oak Log (log 0)
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=1},hasitem={item=log,data=0,quantity=5..}] ~ ~ ~ clear @s log 0 5

# Birch Log (log 2)
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=2},hasitem={item=log,data=2,quantity=5..}] ~ ~ ~ clear @s log 2 5

# Spruce Log (log 1)
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=3},hasitem={item=log,data=1,quantity=5..}] ~ ~ ~ clear @s log 1 5

# Jungle Log (log 3)
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=4},hasitem={item=log,data=3,quantity=5..}] ~ ~ ~ clear @s log 3 5

# Acacia Log (log 4)
execute @s[scores={buy=5},hasitem={item=wheat,quantity=..0}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=5},hasitem={item=wheat,quantity=1..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=5},hasitem={item=wheat,quantity=1..}] ~ ~ ~ clear @s wheat 0 5

# Dark Log (log 5)
execute @s[scores={buy=6},hasitem={item=apple,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=6},hasitem={item=apple,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=6},hasitem={item=apple,quantity=5..}] ~ ~ ~ clear @s apple 0 5

# Potato
execute @s[scores={buy=7},hasitem={item=potato,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=7},hasitem={item=potato,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=7},hasitem={item=potato,quantity=5..}] ~ ~ ~ clear @s potato 0 5

# Bone
execute @s[scores={buy=8},hasitem={item=bone,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=8},hasitem={item=bone,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=8},hasitem={item=bone,quantity=5..}] ~ ~ ~ clear @s bone 0 5

# Gunpowder
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=9},hasitem={item=gunpowder,quantity=5..}] ~ ~ ~ clear @s gunpowder 0 5

# Gold Ingot
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=10},hasitem={item=gold_ingot,quantity=5..}] ~ ~ ~ clear @s gold_ingot 0 5

# Emerald
execute @s[scores={buy=11},hasitem={item=emerald,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=11},hasitem={item=emerald,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=11},hasitem={item=emerald,quantity=5..}] ~ ~ ~ clear @s emerald 0 5

# Diamond
execute @s[scores={buy=12},hasitem={item=diamond,quantity=..4}] ~ ~ ~ tellraw @s {"rawtext":[{"translate":"mojang.text.msg22"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg24"}]}
execute @s[scores={buy=12},hasitem={item=diamond,quantity=5..}] ~ ~ ~ function root/b/c0
execute @s[scores={buy=12},hasitem={item=diamond,quantity=5..}] ~ ~ ~ clear @s diamond 0 5