tag @s add p0_2
#patch note 2.4.24: tolong itunya diapakan dulu biar ga apa kalo
#inject before.worldStartup = true
#load: Menu GUI v0.3, Progress bar v0.1, Economy API v0.1

#install package-0
gamerule showcoordinates false
gamerule commandblockoutput false
scoreboard objectives add ec1 dummy
scoreboard objectives add ec2 dummy