scoreboard players operation @s total = @s unit
scoreboard players operation @s total *= @s count
## check funds: temp = cash - total
scoreboard players operation @s temp = @s cash
scoreboard players operation @s temp -= @s total
## if enough funds, subtract cash and call root/a
scoreboard players operation @s[scores={temp=0..}] cash -= @s total
scoreboard players operation @s[scores={temp=0..}] ec1 += @s total
execute @s[scores={count=1,temp=0..}] ~ ~ ~ function root/a/c1
execute @s[scores={count=5,temp=0..}] ~ ~ ~ function root/a/c2
execute @s[scores={count=10,temp=0..}] ~ ~ ~ function root/a/c3
execute @s[scores={count=50,temp=0..}] ~ ~ ~ function root/a/c4
execute @s[scores={count=100,temp=0..}] ~ ~ ~ function root/a/c5
tellraw @s[scores={count=1,temp=0..}] {"rawtext":[{"translate":"mojang.text.msg20"},{"translate":"mojang.text.msg25"},{"score":{"name":"@s","objective":"total"}}]}
tellraw @s[scores={count=!1,temp=0..}] {"rawtext":[{"translate":"mojang.text.msg20"},{"score":{"name":"@s","objective":"count"}},{"translate":"mojang.text.msg26"},{"score":{"name":"@s","objective":"total"}}]}
tellraw @s[scores={temp=..-1}] {"rawtext":[{"translate":"mojang.text.msg21"},{"score":{"name":"@s","objective":"temp"}}]}