scoreboard players operation @s temp = @s unit
scoreboard players operation @s temp *= @s count
execute @s[scores={count=1}] ~ ~ ~ function root/b/c1
execute @s[scores={count=5}] ~ ~ ~ function root/b/c2
execute @s[scores={count=10}] ~ ~ ~ function root/b/c3
execute @s[scores={count=50}] ~ ~ ~ function root/b/c4
execute @s[scores={count=100}] ~ ~ ~ function root/b/c5