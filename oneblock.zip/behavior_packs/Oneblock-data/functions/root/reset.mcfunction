scoreboard players set @s total 0
scoreboard players set @s temp 0
scoreboard players set @s count 0
scoreboard players set @s unit 0
scoreboard players set @s buy 0
scoreboard players add @s cash 0
scoreboard players add @s ec1 0
scoreboard players add @s ec2 0