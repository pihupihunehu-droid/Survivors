execute @s[scores={buy=1}] ~ ~ ~ give @s lava_bucket 5
execute @s[scores={buy=2}] ~ ~ ~ give @s water_bucket 5
execute @s[scores={buy=3}] ~ ~ ~ give @s obsidian 5
execute @s[scores={buy=4}] ~ ~ ~ give @s raw_iron 5
execute @s[scores={buy=5}] ~ ~ ~ give @s raw_gold 5
execute @s[scores={buy=6}] ~ ~ ~ give @s diamond 5
execute @s[scores={buy=7}] ~ ~ ~ give @s emerald 5
execute @s[scores={buy=8}] ~ ~ ~ give @s netherite_ingot 5