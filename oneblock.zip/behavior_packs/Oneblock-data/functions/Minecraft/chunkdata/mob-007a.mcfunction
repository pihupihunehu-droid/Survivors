##One Block version 2.4.0 McLogic By CuBeyzM ( It is forbidden to change or steal our content without the knowledge of the manager or content owner, to get permission or information you can contact us via email : cbz.official.id@gmail.com )
##2xC

scoreboard players random @s ea 1 6
scoreboard players random @s ea 1 6