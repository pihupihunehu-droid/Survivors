##Custom SFX by: DJ Cz Asekpalepale

playsound hit.chain @a[x=0,y=0,z=0,r=6] 0 1 0 0.5 0.8
playsound mob.shulker.teleport @a[x=0,y=0,z=0,r=6] 0 1 0 0.4 0.7

##effect
function Minecraft/visualdata/ki-02a