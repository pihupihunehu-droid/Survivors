
scoreboard players random @s er 1 18

execute @s[scores={er=1..2}] ~ ~ ~ summon turtle 0 1 0
execute @s[scores={er=3}] ~ ~ ~ summon squid 0 1 0
execute @s[scores={er=4..5}] ~ ~ ~ summon drowned 0 1 0
execute @s[scores={er=6..7}] ~ ~ ~ summon salmon 0 1 0
execute @s[scores={er=8..9}] ~ ~ ~ summon tropicalfish 0 1 0
execute @s[scores={er=10..12}] ~ ~ ~ summon guardian 0 1 0
execute @s[scores={er=13}] ~ ~ ~ summon pufferfish 0 1 0
execute @s[scores={er=14..15}] ~ ~ ~ summon cod 0 1 0
execute @s[scores={er=16..17}] ~ ~ ~ summon elder_guardian 0 1 0
execute @s[scores={er=18}] ~ ~ ~ summon dolphin 0 1 0

scoreboard players random @s ea 1 7

execute @s[scores={ea=7,er=1..2}] ~ ~ ~ summon turtle 0 1.08 0
execute @s[scores={ea=7,er=3}] ~ ~ ~ summon squid 0 1.08 0
execute @s[scores={ea=7,er=4..5}] ~ ~ ~ summon drowned 0 1.08 0
execute @s[scores={ea=7,er=6..7}] ~ ~ ~ summon salmon 0 1.08 0
execute @s[scores={ea=7,er=8..9}] ~ ~ ~ summon tropicalfish 0 1.08 0
execute @s[scores={ea=7,er=10..12}] ~ ~ ~ summon guardian 0 1.08 0
execute @s[scores={ea=7,er=13}] ~ ~ ~ summon pufferfish 0 1.08 0
execute @s[scores={ea=7,er=14..15}] ~ ~ ~ summon cod 0 1.08 0
execute @s[scores={ea=7,er=18}] ~ ~ ~ summon dolphin 0 1.08 0

scoreboard players reset @s ea
scoreboard players reset @s er
