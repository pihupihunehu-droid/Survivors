##v1.0.1

execute @s[scores={mt=482}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg6"}]}
execute @s[scores={mt=481}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] times 10 50 20
execute @s[scores={mt=481}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] actionbar {"rawtext":[{"translate":"mojang.text.render13"},{"text":"§g2"}]}
execute @s[scores={mt=480}] ~ ~ ~ weather rain
execute @s[scores={mt=479}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound item.trident.thunder @s ~ ~ ~ 0.6 1.5
execute @s[scores={mt=478}] ~ ~ ~ summon elder_guardian 0 -60 0
execute @s[scores={mt=465}] ~ ~ ~ summon drowned 0 -60 0
execute @s[scores={mt=464}] ~ ~ ~ summon guardian 0 -60 0
execute @s[scores={mt=445}] ~ ~ ~ summon elder_guardian 0 -60 0
execute @s[scores={mt=440}] ~ ~ ~ summon drowned 0 -60 0
execute @s[scores={mt=60}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg7"}]}
execute @s[scores={mt=60}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound misc.ambient @s ~ ~ ~ 0.7 0.85 1.0