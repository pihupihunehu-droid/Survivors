
execute @e[type=skeleton] ~ ~ ~ execute @s[x=~,y=48,z=~,dy=3] ~ ~ ~ function Minecraft/entitydata/item/iron
execute @s[scores={mt=325}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg6"}]}
execute @s[scores={mt=325}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] times 10 50 20
execute @s[scores={mt=325}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] actionbar {"rawtext":[{"translate":"mojang.text.render13"},{"text":"§c4"}]}
execute @s[scores={mt=325}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound item.trident.thunder @s ~ ~ ~ 0.6 1.5
execute @s[scores={mt=325}] ~ ~ ~ weather rain
execute @s[scores={mt=325}] ~ ~ ~ function Minecraft/entitydata/mob/silverfish-r
execute @s[scores={mt=300}] ~ ~ ~ function Minecraft/entitydata/mob/skeleton-r
execute @s[scores={mt=275}] ~ ~ ~ function Minecraft/entitydata/mob/vex
execute @s[scores={mt=250}] ~ ~ ~ function Minecraft/entitydata/mob/cavespider-r
execute @s[scores={mt=225}] ~ ~ ~ function Minecraft/entitydata/mob/evoker-r
execute @s[scores={mt=200}] ~ ~ ~ function Minecraft/entitydata/mob/silverfish-r
execute @s[scores={mt=175}] ~ ~ ~ function Minecraft/entitydata/mob/skeleton-r
execute @s[scores={mt=150}] ~ ~ ~ function Minecraft/entitydata/mob/cavespider-r
execute @s[scores={mt=125}] ~ ~ ~ function Minecraft/entitydata/mob/silverfish-r
execute @s[scores={mt=30}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg7"}]}
execute @s[scores={mt=30}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound random.glass @s ~ ~ ~ 0.7 0.85 1.0