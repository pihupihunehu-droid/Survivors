tag @s remove d1
scoreboard players add @s death 1

give @s[tag=!u1,scores={death=1}] wooden_shovel
give @s[tag=!u1,scores={death=2}] wooden_axe
give @s[tag=!u1,scores={death=3}] stone_axe

tellraw @s[tag=!u1,scores={death=1..3}] {"rawtext":[{"translate":"mojang.text.msg31"},{"score":{"name":"@s","objective":"death"}},{"text":"/3)"}]}