## addon by CubeyzM
execute @s[scores={bp=7}] ~ ~ ~ summon piglin 0 1 0 spawn_adult_no_hunting
execute @s[scores={bp=7}] ~ ~ ~ summon piglin 0 1 0 spawn_adult_no_hunting