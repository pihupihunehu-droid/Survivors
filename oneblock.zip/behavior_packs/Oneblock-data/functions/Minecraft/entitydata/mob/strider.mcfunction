## Addon by CubeyzM
summon strider 0 1 0