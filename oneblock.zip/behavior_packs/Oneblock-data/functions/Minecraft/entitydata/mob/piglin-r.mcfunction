summon piglin 0 -60 0 spawn_adult
function Minecraft/chunkdata/mob-007a
execute @s[scores={ea=5..6}] ~ ~ ~ summon piglin 0 -60 0 spawn_adult
scoreboard players reset @s ea