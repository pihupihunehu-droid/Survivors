## Addon by CubeyzM
summon ghast 0 1 0
function Minecraft/chunkdata/mob-007a
execute @s[scores={bp=7,ea=5..6}] ~ ~ ~ summon ghast 0 1 0
scoreboard players reset @s ea