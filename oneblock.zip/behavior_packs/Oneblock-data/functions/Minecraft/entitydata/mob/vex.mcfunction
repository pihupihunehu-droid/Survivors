summon vex 0 1 0
function Minecraft/chunkdata/mob-009a
execute @s[scores={bp=9,ea=5..6}] ~ ~ ~ summon vex 0 1 0
scoreboard players reset @s ea