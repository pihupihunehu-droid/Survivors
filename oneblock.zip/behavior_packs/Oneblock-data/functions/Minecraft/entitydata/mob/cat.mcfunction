summon cat 0 1 0
function Minecraft/chunkdata/mob-008a
execute @s[scores={bp=8,ea=5..6}] ~ ~ ~ summon cat 0 1 0
scoreboard players reset @s ea