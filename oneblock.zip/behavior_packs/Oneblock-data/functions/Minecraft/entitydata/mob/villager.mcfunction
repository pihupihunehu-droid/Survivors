## Addon by CubeyzM
summon villager 0 1 0
function Minecraft/chunkdata/mob-006a
execute @s[scores={bp=6,ea=5}] ~ ~ ~ summon villager 0 1 0
scoreboard players reset @s ea