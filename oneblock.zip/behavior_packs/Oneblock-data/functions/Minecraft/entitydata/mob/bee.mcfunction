
function Minecraft/chunkdata/mob-008a
execute @s[scores={bp=8,ea=1..4}] ~ ~ ~ summon bee 0 1 0
execute @s[scores={bp=8,ea=3..4}] ~ ~ ~ summon bee 0 1 0
execute @s[scores={bp=8,ea=5..6}] ~ ~ ~ summon bee 0 1 0 hive_destroyed "Killer Bee"
execute @s[scores={bp=8,ea=5..6}] ~ ~ ~ summon bee 0 1 0 hive_destroyed "Killer Bee"
execute @s[scores={bp=8,ea=5..6}] ~ ~ ~ summon bee 0 1 0 hive_destroyed "Killer Bee"
execute @s[scores={bp=8,ea=6}] ~ ~ ~ summon bee 0 1 0 hive_destroyed "Killer Bee"
scoreboard players reset @s ea