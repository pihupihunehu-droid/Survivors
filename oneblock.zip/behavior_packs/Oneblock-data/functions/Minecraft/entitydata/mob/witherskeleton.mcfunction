## Addon by CubeyzM
summon wither_skeleton 0 1 0
function Minecraft/chunkdata/mob-007a
execute @s[scores={bp=7,ea=5..6}] ~ ~ ~ summon wither_skeleton 0 1 0
scoreboard players reset @s ea