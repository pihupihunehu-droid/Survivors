## Addon by CubeyzM
summon blaze 0 1 0
function Minecraft/chunkdata/mob-007a
execute @s[scores={bp=7,ea=5..6}] ~ ~ ~ summon blaze 0 1 0
scoreboard players reset @s ea