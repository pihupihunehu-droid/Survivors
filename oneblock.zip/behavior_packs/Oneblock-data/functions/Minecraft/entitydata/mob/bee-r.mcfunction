summon bee 0 2 0 hive_destroyed "Killer Bee"
summon bee 0 2 0 hive_destroyed "Killer Bee"
function Minecraft/chunkdata/mob-008a
execute @s[scores={bp=8,ea=5..6}] ~ ~ ~ summon bee 0 2 0 hive_destroyed "Killer Bee"
scoreboard players reset @s ea