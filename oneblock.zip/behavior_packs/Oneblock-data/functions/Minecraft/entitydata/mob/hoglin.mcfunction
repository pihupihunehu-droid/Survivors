## Addon by CubeyzM
summon hoglin 0 1 0
function Minecraft/chunkdata/mob-007a
execute @s[scores={bp=7,ea=5..6}] ~ ~ ~ summon hoglin 0 1 0
scoreboard players reset @s ea