## Addon by CubeyzM
summon husk 0 1 0
execute @s[scores={bp=6}] ~ ~ ~ summon husk 0 1 0
function Minecraft/chunkdata/mob-006a
execute @s[scores={bp=6,ea=5}] ~ ~ ~ summon husk 0 1 0
execute @s[scores={bp=6,ea=5}] ~ ~ ~ summon husk 0 1 0
scoreboard players reset @s ea