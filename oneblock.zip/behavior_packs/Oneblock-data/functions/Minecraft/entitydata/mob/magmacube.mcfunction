## Addon by CubeyzM
summon magma_cube 0 1 0
execute @s[scores={bp=7}] ~ ~ ~ summon magma_cube 0 1 0
function Minecraft/chunkdata/mob-007a
execute @s[scores={bp=7,ea=5..6}] ~ ~ ~ summon magma_cube 0 1 0
scoreboard players reset @s ea