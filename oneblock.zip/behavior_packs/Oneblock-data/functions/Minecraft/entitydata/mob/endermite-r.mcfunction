summon endermite 0 -60 0
function Minecraft/chunkdata/mob-010a
execute @s[scores={bp=10,ea=5..6}] ~ ~ ~ summon endermite 0 -60 0
scoreboard players reset @s ea