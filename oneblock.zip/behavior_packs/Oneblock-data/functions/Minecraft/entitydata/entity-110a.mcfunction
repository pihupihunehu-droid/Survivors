
execute @s[scores={mt=500}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg8"}]}
execute @s[scores={mt=500}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] times 10 50 20
execute @s[scores={mt=500}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] actionbar {"rawtext":[{"translate":"mojang.text.render13"},{"text":"§430"}]}
execute @s[scores={mt=500}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound item.trident.thunder @s ~ ~ ~ 0.6 1.5
execute @s[scores={mt=375}] ~ ~ ~ function Minecraft/entitydata/mob/endermite-r
execute @s[scores={mt=350}] ~ ~ ~ function Minecraft/entitydata/mob/endermite-r
execute @s[scores={mt=325}] ~ ~ ~ function Minecraft/entitydata/mob/enderman-r
execute @s[scores={mt=300}] ~ ~ ~ summon shulker 0 1 0
execute @s[scores={mt=275}] ~ ~ ~ function Minecraft/entitydata/mob/endermite-r
execute @s[scores={mt=250}] ~ ~ ~ function Minecraft/entitydata/mob/endermite-r
execute @s[scores={mt=225}] ~ ~ ~ function Minecraft/entitydata/mob/enderman-r
execute @s[scores={mt=200}] ~ ~ ~ function Minecraft/entitydata/mob/endermite-r
execute @s[scores={mt=175}] ~ ~ ~ function Minecraft/entitydata/mob/endermite-r
execute @s[scores={mt=150}] ~ ~ ~ function Minecraft/entitydata/mob/enderman-r
execute @s[scores={mt=125}] ~ ~ ~ function Minecraft/entitydata/mob/endermite-r
execute @s[scores={mt=30}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg9"}]}
execute @s[scores={mt=30}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound misc.ambient @s ~ ~ ~ 0.7 0.85 1.0