
scoreboard players random @s er 1 14

execute @s[scores={er=1..2}] ~ ~ ~ summon parrot 0 1 0
execute @s[scores={er=1..2}] ~ ~ ~ summon parrot 0 1 0
execute @s[scores={er=3..5}] ~ ~ ~ summon vex 0 1 0
execute @s[scores={er=3..5}] ~ ~ ~ summon vex 0 1 0
execute @s[scores={er=6..8}] ~ ~ ~ summon ocelot 0 1 0
execute @s[scores={er=7}] ~ ~ ~ summon ocelot 0 1 0
execute @s[scores={er=9}] ~ ~ ~ summon panda 0 1 0
execute @s[scores={er=10..12}] ~ ~ ~ summon witch 0 1 0
execute @s[scores={er=11}] ~ ~ ~ summon witch 0 1 0
execute @s[scores={er=13..14}] ~ ~ ~ summon horse 0 1 0

scoreboard players random @s ea 1 6
scoreboard players random @s ea 1 6

execute @s[scores={ea=6,er=1..2}] ~ ~ ~ summon parrot 0 1.08 0
execute @s[scores={ea=6,er=6..8}] ~ ~ ~ summon ocelot 0 1.08 0
execute @s[scores={ea=6,er=7}] ~ ~ ~ summon ocelot 0 1.08 0
execute @s[scores={ea=6,er=9}] ~ ~ ~ summon panda 0 1.08 0
execute @s[scores={ea=6,er=10..12}] ~ ~ ~ summon witch 0 1.08 0
execute @s[scores={ea=6,er=13..14}] ~ ~ ~ summon horse 0 1.08 0

scoreboard players reset @s ea
scoreboard players reset @s er
