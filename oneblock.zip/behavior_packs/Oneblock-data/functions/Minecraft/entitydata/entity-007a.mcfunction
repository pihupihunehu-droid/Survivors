
scoreboard players random @s er 1 18

execute @s[scores={er=1..3}] ~ ~ ~ function Minecraft/entitydata/mob/piglin
execute @s[scores={er=4..6}] ~ ~ ~ function Minecraft/entitydata/mob/magmacube
execute @s[scores={er=7..9}] ~ ~ ~ function Minecraft/entitydata/mob/hoglin
execute @s[scores={er=10..12}] ~ ~ ~ function Minecraft/entitydata/mob/blaze
execute @s[scores={er=13..14}] ~ ~ ~ function Minecraft/entitydata/mob/strider
execute @s[scores={er=15..16}] ~ ~ ~ function Minecraft/entitydata/mob/witherskeleton
execute @s[scores={er=17..18}] ~ ~ ~ function Minecraft/entitydata/mob/ghast

scoreboard players reset @s er