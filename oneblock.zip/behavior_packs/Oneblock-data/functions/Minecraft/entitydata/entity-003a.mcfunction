
scoreboard players random @s er 1 14

execute @s[scores={er=1..3}] ~ ~ ~ summon wolf 0 1 0
execute @s[scores={er=4..10}] ~ ~ ~ summon stray 0 1 0
execute @s[scores={er=11..13}] ~ ~ ~ summon fox 0 1 0
execute @s[scores={er=14}] ~ ~ ~ summon polar_bear 0 1 0

scoreboard players random @s ea 1 8
scoreboard players random @s ea 1 8

execute @s[scores={ea=7,er=4..10}] ~ ~ ~ summon stray 0 1.08 0
execute @s[scores={ea=7,er=11..13}] ~ ~ ~ summon fox 0 1.08 0

scoreboard players reset @s ea
scoreboard players reset @s er
