
execute @e[type=piglin] ~ ~ ~ execute @s[x=~,y=48,z=~,dy=3] ~ ~ ~ function Minecraft/entitydata/item/gold
execute @s[scores={mt=500}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg8"}]}
execute @s[scores={mt=500}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] times 10 50 20
execute @s[scores={mt=500}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] actionbar {"rawtext":[{"translate":"mojang.text.render13"},{"text":"§c4"}]}
execute @s[scores={mt=500}] ~ ~ ~ weather clear
execute @s[scores={mt=500}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound item.trident.thunder @s ~ ~ ~ 0.6 1.5
execute @s[scores={mt=480}] ~ ~ ~ function Minecraft/entitydata/mob/piglin-r
execute @s[scores={mt=440}] ~ ~ ~ function Minecraft/entitydata/mob/piglin-r
execute @s[scores={mt=360}] ~ ~ ~ summon magma_cube 0 -60 0
execute @s[scores={mt=300}] ~ ~ ~ summon blaze 0 -60 0
execute @s[scores={mt=260}] ~ ~ ~ summon ghast 0 10 0
execute @s[scores={mt=160}] ~ ~ ~ function Minecraft/entitydata/mob/piglin-r
execute @s[scores={mt=100}] ~ ~ ~ summon magma_cube 0 -60 0
execute @s[scores={mt=60}] ~ ~ ~ summon magma_cube 0 -60 0
execute @s[scores={mt=30}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg9"}]}
execute @s[scores={mt=30}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound misc.ambient @s ~ ~ ~ 0.7 0.85 1.0