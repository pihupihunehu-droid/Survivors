
scoreboard players random @s er 1 19

execute @s[scores={er=1..2}] ~ ~ ~ function Minecraft/entitydata/mob/llama
execute @s[scores={er=3..4}] ~ ~ ~ function Minecraft/entitydata/mob/fox
execute @s[scores={er=5..6}] ~ ~ ~ function Minecraft/entitydata/mob/villager
execute @s[scores={er=7..10}] ~ ~ ~ function Minecraft/entitydata/mob/husk
execute @s[scores={er=11..13}] ~ ~ ~ function Minecraft/entitydata/mob/pillager
execute @s[scores={er=14..15}] ~ ~ ~ function Minecraft/entitydata/mob/wanderingtrader
execute @s[scores={er=16..17}] ~ ~ ~ function Minecraft/entitydata/mob/donkey
execute @s[scores={er=18..19}] ~ ~ ~ function Minecraft/entitydata/mob/vindicator

scoreboard players reset @s er
