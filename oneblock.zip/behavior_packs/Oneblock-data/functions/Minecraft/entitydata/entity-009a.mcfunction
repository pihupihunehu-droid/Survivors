
scoreboard players random @s er 1 18

execute @s[scores={er=1..3}] ~ ~ ~ summon silverfish 0 1 0
execute @s[scores={er=1..3}] ~ ~ ~ summon silverfish 0 1 0
execute @s[scores={er=1..3}] ~ ~ ~ summon silverfish 0 1 0
execute @s[scores={er=4}] ~ ~ ~ summon creeper 0 1 0 minecraft:become_charged "§7[§e!§7] §l§6TSAR BOMBA §r§7[§e!§7]"
execute @s[scores={er=4}] ~ ~ ~ summon creeper 0 1 0 minecraft:become_charged "§7[§e!§7] §l§6TSAR BOMBA §r§7[§e!§7]"
execute @s[scores={er=5..8}] ~ ~ ~ summon cave_spider 0 1 0
execute @s[scores={er=5..8}] ~ ~ ~ summon cave_spider 0 1 0
execute @s[scores={er=9..10}] ~ ~ ~ summon skeleton_horse 0 1 0 minecraft:set_trap
execute @s[scores={er=11..12}] ~ ~ ~ summon creeper 0 1 0 minecraft:start_exploding_forced "§cKABOOM"
execute @s[scores={er=13..14}] ~ ~ ~ summon evocation_illager 0 1 0
execute @s[scores={er=15..18}] ~ ~ ~ summon skeleton 0 1 0
execute @s[scores={er=15..18}] ~ ~ ~ summon skeleton 0 1 0

scoreboard players random @s ea 1 5
scoreboard players random @s ea 1 5

execute @s[scores={ea=4..5,er=1..3}] ~ ~ ~ summon silverfish 0 1.08 0
execute @s[scores={ea=4..5,er=5..8}] ~ ~ ~ summon cave_spider 0 1.08 0
execute @s[scores={ea=4..5,er=13..14}] ~ ~ ~ summon evocation_illager 0 1.08 0
execute @s[scores={ea=4..5,er=15..18}] ~ ~ ~ summon skeleton 0 1.08 0

scoreboard players reset @s ea
scoreboard players reset @s er
