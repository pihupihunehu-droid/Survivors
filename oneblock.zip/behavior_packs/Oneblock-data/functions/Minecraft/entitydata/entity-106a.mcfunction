##v1.0.1

execute @s[scores={mt=402}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg6"}]}
execute @s[scores={mt=401}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] times 10 50 20
execute @s[scores={mt=401}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] actionbar {"rawtext":[{"translate":"mojang.text.render13"},{"text":"§63"}]}
execute @s[scores={mt=400}] ~ ~ ~ weather rain
execute @s[scores={mt=399}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound item.trident.thunder @s ~ ~ ~ 0.7 1.5
execute @s[scores={mt=398}] ~ ~ ~ summon husk 0 -60 0
execute @s[scores={mt=360}] ~ ~ ~ summon husk 0 -60 0
execute @s[scores={mt=300}] ~ ~ ~ summon vindicator 0 -60 0
execute @s[scores={mt=260}] ~ ~ ~ summon pillager 0 -60 0
execute @s[scores={mt=100}] ~ ~ ~ summon vindicator 0 -60 0
execute @s[scores={mt=60}] ~ ~ ~ summon husk 0 -60 0
execute @s[scores={mt=60}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg7"}]}
execute @s[scores={mt=59}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound misc.ambient @s ~ ~ ~ 0.7 0.85 1.0