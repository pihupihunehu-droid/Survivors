##mt0.25 1.2

execute @s[scores={mt=455}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound mob.wither.spawn @s ~ ~ ~ 1 1.2
execute @s[scores={mt=454}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg8"}]}
execute @s[scores={mt=453}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] times 10 50 20
execute @s[scores={mt=453}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] actionbar {"rawtext":[{"translate":"mojang.text.render13"},{"text":"§c3"}]}
execute @s[scores={mt=452}] ~ ~ ~ effect @a[r=64] night_vision 25 20 true
execute @s[scores={mt=451}] ~ ~ ~ weather clear
execute @s[scores={mt=450}] ~ ~ ~ particle minecraft:dragon_breath_fire 0 1 0
execute @s[scores={mt=450}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound mob.vex.charge @s ~ ~ ~ 2 1.3
execute @s[scores={mt=442}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound mob.vex.charge @s ~ ~ ~ 2 1.4
execute @s[scores={mt=429}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound mob.vex.charge @s ~ ~ ~ 2 1.6
execute @s[scores={mt=449}] ~ ~ ~ summon endermite 0 -60 0
execute @s[scores={mt=420}] ~ ~ ~ summon endermite 0 -60 0
execute @s[scores={mt=400}] ~ ~ ~ summon enderman 0 -60 0
execute @s[scores={mt=380}] ~ ~ ~ summon shulker 0 1 0
execute @s[scores={mt=350}] ~ ~ ~ summon endermite 0 -60 0
execute @s[scores={mt=340}] ~ ~ ~ summon endermite 0 -60 0
execute @s[scores={mt=300}] ~ ~ ~ summon endermite 0 -60 0
execute @s[scores={mt=260}] ~ ~ ~ summon enderman 0 -60 0
execute @s[scores={mt=225}] ~ ~ ~ summon endermite 0 -60 0
execute @s[scores={mt=200}] ~ ~ ~ summon enderman 0 -60 0
execute @s[scores={mt=180}] ~ ~ ~ summon endermite 0 -60 0
execute @s[scores={mt=60}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg9"}]}
execute @s[scores={mt=60}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound random.levelup @s ~ ~ ~ 1 0.7