
## This map based of Oneblock by IJAMinecraft
## This content was created by him, you can visit his site at the link here: ijaminecraft.com or visit his own Youtube: IJAMinecraft
## One Block version 2.4.0 McLogic By CuBeyzM ( It is forbidden to change or steal our content without the knowledge of the manager or content owner, to get permission or information you can contact us via email : cbz.official.id@gmail.com )
## My YouTube: CubeyzM

scoreboard players random @s er 1 3

execute @s[scores={er=1..2}] ~ ~ ~ summon pig 0 1 0
execute @s[scores={er=3}] ~ ~ ~ summon sheep 0 1 0

scoreboard players reset @s er
