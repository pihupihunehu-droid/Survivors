
scoreboard players random @s er 1 8

execute @s[scores={er=1..2}] ~ ~ ~ summon pig 0 1 0
execute @s[scores={er=3..4}] ~ ~ ~ summon cow 0 1 0
execute @s[scores={er=5..6}] ~ ~ ~ summon sheep 0 1 0
execute @s[scores={er=7..8}] ~ ~ ~ summon chicken 0 1 0

scoreboard players random @s ea 1 8

execute @s[scores={ea=7,er=7..8}] ~ ~ ~ summon chicken 0 1.08 0

scoreboard players reset @s ea
scoreboard players reset @s er
