
scoreboard players random @s er 1 18

execute @s[scores={er=1..2}] ~ ~ ~ summon bee 0 1 0
execute @s[scores={er=3..5}] ~ ~ ~ summon bee 0 1 0 hive_destroyed "Killer Bee"
execute @s[scores={er=3..5}] ~ ~ ~ summon bee 0 1 0 hive_destroyed "Killer Bee"
execute @s[scores={er=3..5}] ~ ~ ~ summon bee 0 1 0 hive_destroyed "Killer Bee"
execute @s[scores={er=6..8}] ~ ~ ~ summon cat 0 1 0
execute @s[scores={er=9..12}] ~ ~ ~ summon slime 0 1 0
execute @s[scores={er=9..12}] ~ ~ ~ summon slime 0 1 0
execute @s[scores={er=13..14}] ~ ~ ~ summon mule 0 1 0
execute @s[scores={er=15}] ~ ~ ~ summon skeleton_horse 0 1 0
execute @s[scores={er=16..17}] ~ ~ ~ summon phantom 0 1 0
execute @s[scores={er=18}] ~ ~ ~ summon zombie_horse 0 1 0

scoreboard players random @s ea 1 7
scoreboard players random @s ea 1 7

execute @s[scores={ea=5..7,er=1..2}] ~ ~ ~ summon bee 0 1.08 0
execute @s[scores={ea=5..7,er=3..5}] ~ ~ ~ summon bee 0 1.085 0 hive_destroyed "Killer Bee"
execute @s[scores={ea=5..7,er=6..8}] ~ ~ ~ summon cat 0 1.08 0
execute @s[scores={ea=5..7,er=9..10}] ~ ~ ~ summon slime 0 1.08 0
execute @s[scores={ea=5..7,er=9..12}] ~ ~ ~ summon slime 0 1.085 0
execute @s[scores={ea=5..7,er=13..14}] ~ ~ ~ summon mule 0 1.08 0
execute @s[scores={ea=5..7,er=15}] ~ ~ ~ summon skeleton_horse 0 1.08 0
execute @s[scores={ea=5..7,er=16..17}] ~ ~ ~ summon phantom 0 1.08 0

scoreboard players reset @s ea
scoreboard players reset @s er
