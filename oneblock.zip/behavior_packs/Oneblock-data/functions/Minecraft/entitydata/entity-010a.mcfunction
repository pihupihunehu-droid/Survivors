
scoreboard players random @s er 1 17

execute @s[scores={er=1..7}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=1..7}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=1..7}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=8..13}] ~ ~ ~ summon enderman 0 1 0
execute @s[scores={er=14..15}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=14..15}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=14..15}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=14..15}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=14..15}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=14..15}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=14..15}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=14..15}] ~ ~ ~ summon endermite 0 1 0
execute @s[scores={er=16..17}] ~ ~ ~ summon shulker 0 1 0

scoreboard players random @s ea 1 8
scoreboard players random @s ea 1 8

execute @s[scores={ea=1..4,er=1..7}] ~ ~ ~ summon endermite 0 1.08 0
execute @s[scores={ea=1..4,er=5..7}] ~ ~ ~ summon endermite 0 1.085 0
execute @s[scores={ea=1..4,er=8..13}] ~ ~ ~ summon enderman 0 1.08 0
execute @s[scores={ea=1..4,er=12..13}] ~ ~ ~ summon enderman 0 1.085 0
execute @s[scores={ea=1..4,er=14..15}] ~ ~ ~ summon endermite 0 1.08 0
execute @s[scores={ea=1..4,er=15}] ~ ~ ~ summon endermite 0 1.09 0
execute @s[scores={ea=1..4,er=15}] ~ ~ ~ summon endermite 0 1.085 0

scoreboard players reset @s ea
scoreboard players reset @s er
