##v1.0.1

execute @s[scores={mt=402}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg6"}]}
execute @s[scores={mt=401}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] times 10 50 20
execute @s[scores={mt=401}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=60] actionbar {"rawtext":[{"translate":"mojang.text.render13"},{"text":"§e1"}]}
execute @s[scores={mt=400}] ~ ~ ~ weather rain
execute @s[scores={mt=399}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound item.trident.thunder @s ~ ~ ~ 0.6 1.5
execute @s[scores={mt=398}] ~ ~ ~ summon chicken 0 -60 0
execute @s[scores={mt=360}] ~ ~ ~ summon pig 0 -60 0
execute @s[scores={mt=300}] ~ ~ ~ summon stray 0 -60 0
execute @s[scores={mt=260}] ~ ~ ~ summon sheep 0 -60 0
execute @s[scores={mt=100}] ~ ~ ~ summon cow 0 -60 0
execute @s[scores={mt=65}] ~ ~ ~ summon fox 0 -60 0
execute @s[scores={mt=60}] ~ ~ ~ tellraw @a[x=0,y=0,z=0,r=60] {"rawtext":[{"translate":"mojang.text.msg7"}]}
execute @s[scores={mt=60}] ~ ~ ~ execute @a[r=60] ~ ~ ~ playsound misc.ambient @s ~ ~ ~ 0.7 0.85 1.0