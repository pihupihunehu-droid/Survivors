
scoreboard players random @s er 1 11

execute @s[scores={er=1..2}] ~ ~ ~ summon mooshroom 0 1 0
execute @s[scores={er=3..4}] ~ ~ ~ summon creeper 0 1 0
execute @s[scores={er=5..7}] ~ ~ ~ summon zombie 0 1 0
execute @s[scores={er=8..9}] ~ ~ ~ summon spider 0 1 0
execute @s[scores={er=10..11}] ~ ~ ~ summon rabbit 0 1 0
execute @s[scores={er=10..11}] ~ ~ ~ summon rabbit 0 1 0

scoreboard players random @s ea 1 8

execute @s[scores={ea=7,er=3..4}] ~ ~ ~ summon creeper 0 1.08 0
execute @s[scores={ea=7,er=5..7}] ~ ~ ~ summon zombie 0 1.08 0
execute @s[scores={ea=7,er=8..9}] ~ ~ ~ summon spider 0 1.08 0
execute @s[scores={ea=7,er=10..11}] ~ ~ ~ summon rabbit 0 1.08 0
execute @s[scores={ea=7,er=11}] ~ ~ ~ summon rabbit 0 1.085 0

scoreboard players reset @s ea
scoreboard players reset @s er
