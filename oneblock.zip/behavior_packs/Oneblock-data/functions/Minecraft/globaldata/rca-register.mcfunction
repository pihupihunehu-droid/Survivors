scoreboard players add @s bb 0
scoreboard players add @s death 0
scoreboard players operation @s blockdisplay = @s bb
dialogue change @e[tag=npc] a0 @s