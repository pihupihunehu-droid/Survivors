## credit-filepath: #"../../../../../credits.html"

particle minecraft:end_chest 0 0 0

execute @s[scores={bb=0}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"translate":"mojang.text.render1"}]}
execute @s[scores={bb=1}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"translate":"mojang.text.render2"}]}
execute @s[scores={bb=2}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"translate":"mojang.text.render3"}]}
execute @s[scores={bb=3}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"translate":"mojang.text.render4"}]}
execute @s[scores={bb=4}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"translate":"mojang.text.render5"}]}