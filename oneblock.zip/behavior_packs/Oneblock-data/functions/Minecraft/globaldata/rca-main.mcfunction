execute @s[scores={air=0,cd=0,ss=0}] ~ ~ ~ detect 0 0 0 air 0 function Minecraft/eventdata/blockcooldown
scoreboard players remove @s[scores={cd=1..}] cd 1
execute @s[scores={air=1,cd=0,ss=0}] ~ ~ ~ function Minecraft/eventdata/blockbreak
execute @s[scores={bb=0..4}] ~ ~ ~ function Minecraft/globaldata/rca-000a
execute @s[scores={air=0,bp=..5}] ~ ~ ~ spawnpoint @a[x=0,y=0,z=0,r=3] 0 2 0


#hybrid-data: #system-initialize({\\"engine_version\\":{\\"min\\":\\"1.18.30.20-beta\\",\\"max\\":\\"1.21.120\\"}})
execute @s[tag=mr-show,scores={bp=0..}] ~ ~ ~ function Minecraft/eventdata/party/partyset
tp @s 0 0.4975 0
execute @s[scores={cd=1..}] ~ ~ ~ tp @e[type=item,r=1.1] 0 1 0
execute @s[scores={ss=1..}] ~ ~ ~ function Minecraft/eventdata/blockupgrade
execute @a[tag=!d1,rm=0] ~ ~ ~ tag @s[x=~,y=-104,z=~,dy=1] add d1
execute @a[rm=0] ~ ~ ~ kill @s[x=~,y=-104,z=~,dy=1]
execute @a[tag=d1] ~ ~ ~ execute @s[y=-6,x=~,z=~,dy=15] ~ ~ ~ function Minecraft/entitydata/item/recovery
execute @s[scores={r1=0..}] ~ ~ ~ function Minecraft/eventdata/menuspawn
execute @s[scores={r2=0..}] ~ ~ ~ function Minecraft/eventdata/doublepattern
execute @s[tag=u1] ~ ~ ~ tag @a add u1
execute @s[tag=!p0_2] ~ ~ ~ function root/patch_upd