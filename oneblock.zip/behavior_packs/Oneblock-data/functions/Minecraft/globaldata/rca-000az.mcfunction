titleraw @a[x=0,y=0,z=0,rm=0] actionbar {"rawtext":[{"translate":"mojang.text.render11"}]}

execute @a[r=11] ~ ~ ~ playsound beacon.activate @s ~ ~ ~ 2.4 1.1

function Minecraft/visualdata/ki-01a
scoreboard players add @s bp 1
scoreboard players set @s bd 0
scoreboard objectives remove blockdisplay

execute @s[scores={bp=2}] ~ ~ ~ scoreboard players set size pattern 5
execute @s[scores={bp=3}] ~ ~ ~ scoreboard players set size pattern 2
execute @s[scores={bp=4..5}] ~ ~ ~ scoreboard players set size pattern 5
execute @s[scores={bp=6}] ~ ~ ~ scoreboard players set size pattern 6
execute @s[scores={bp=7}] ~ ~ ~ scoreboard players set size pattern 4
execute @s[scores={bp=8}] ~ ~ ~ scoreboard players set size pattern 3
execute @s[scores={bp=9}] ~ ~ ~ scoreboard players set size pattern 4
execute @s[scores={bp=10}] ~ ~ ~ scoreboard players set size pattern 7

tag @e[tag=boss] add del
tp @e[tag=boss] 0 -104 0

##
# Warning: Backend engineer class 2 or less only
##
tag @s[tag=system31,tag=!system114] remove c0
tag @s[tag=system31,tag=!system114] add c0f
execute @s[tag=c0f,scores={bp=1}] ~ ~ ~ tellraw @p[tag=o] {"rawtext":[{"text":"§cCBZ-ENGINE: Silent error B-11-33, system32 missing dependency, you may need system114\n§6This means the map continues to run normally, but additional features like \"Essential\" are disabled because your Minecraft version contains a bug. Minimum version required to try features: 1.21.114"}]}
execute @s[tag=c0f,scores={bp=1}] ~ ~ ~ playsound hit.chain @a[rm=0] 0 1 0

tellraw @a[rm=0] {"rawtext":[{"text":" "}]}
execute @s[tag=c0,scores={bp=1}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e1" 0 0.4975 0
execute @s[scores={bp=1}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bp=1}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eI"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title1"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: §a0.4s"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §g"},{"translate":"entity.cow.name"},{"text":"§e, §f"},{"translate":"entity.chicken.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: §3"},{"translate":"tile.clay.name"},{"text":"§e, §6"},{"translate":"tile.pumpkin.name"},{"text":"§e, §a"},{"translate":"tile.melon_block.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=2}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e2" 0 0.4975 0
execute @s[scores={bp=2}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bp=2}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eII"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title2"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: 0.40s §f>> §a0.35s"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §f"},{"translate":"entity.rabbit.name"},{"text":"§e, §c"},{"translate":"entity.mooshroom.name"},{"text":"§e, §2"},{"translate":"entity.creeper.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: "},{"translate":"tile.stone.stone.name"},{"text":"§e, §3"},{"translate":"tile.clay.name"},{"text":"§e, §f"},{"translate":"tile.iron_ore.name"},{"text":"§e, §7"},{"translate":"tile.coal_ore.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=3}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e3" 0 0.4975 0
execute @s[scores={bp=3}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bp=3}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eIII"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title3"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: 0.35s §f>> §a0.30s"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §f"},{"translate":"entity.wolf.name"},{"text":"§e, §6"},{"translate":"entity.fox.name"},{"text":"§e, §3"},{"translate":"entity.stray.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: §f"},{"translate":"tile.snow.name"},{"text":"§e, §b"},{"translate":"tile.ice.name"},{"text":"§e, §6"},{"translate":"tile.gold_ore.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=4}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e4" 0 0.4975 0
execute @s[scores={bp=4}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bp=4}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eIV"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title4"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: 0.30s §f>> §a0.25s"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §2"},{"translate":"entity.turtle.name"},{"text":"§e, §a"},{"translate":"entity.tropicalfish.name"},{"text":"§e, §1"},{"translate":"entity.squid.name"},{"text":"§e, §3"},{"translate":"entity.guardian.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: §c"},{"translate":"tile.coral.red.name"},{"text":"§e, §3"},{"translate":"tile.prismarine.rough.name"},{"text":"§e, §b"},{"translate":"tile.diamond_ore.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=5}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e5" 0 0.4975 0
execute @s[scores={bp=5}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bp=5}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eV"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title5"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: 0.25s §f>> §a0.20s"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §a"},{"translate":"entity.parrot.name"},{"text":"§e, §7"},{"translate":"entity.vex.name"},{"text":"§e, §g"},{"translate":"entity.ocelot.name"},{"text":"§e, §d"},{"translate":"entity.witch.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: "},{"translate":"tile.cobblestone.name"},{"text":"§e, §2"},{"translate":"tile.mossy_cobblestone.name"},{"text":"§e, §c"},{"translate":"tile.redstone_ore.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=6}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e6" 0 0.4975 0
execute @s[scores={bp=6}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bp=6}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eVI"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title6"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: §6"},{"translate":"library.text.regen_phase1"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §6"},{"translate":"entity.villager.name"},{"text":"§e, §7"},{"translate":"entity.husk.name"},{"text":"§e, §3"},{"translate":"entity.vindicator.name"},{"text":"§e, §7"},{"translate":"entity.donkey.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: §a"},{"translate":"tile.emerald_ore.name"},{"text":"§e, §c"},{"translate":"tile.sand.red.name"},{"text":"§e, §e"},{"translate":"tile.gold_ore.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=7}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e7" 0 0.4975 0
execute @s[scores={bp=7}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bp=7}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eVII"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title7"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: §e"},{"translate":"library.text.regen_phase1"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §f"},{"translate":"entity.ghast.name"},{"text":"§e, §e"},{"translate":"entity.blaze.name"},{"text":"§e, §c"},{"translate":"entity.piglin.name"},{"text":"§e, §4"},{"translate":"entity.strider.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: §4"},{"translate":"tile.nether_brick.name"},{"text":"§e, §f"},{"translate":"tile.quartz_ore.name"},{"text":"§e, §c"},{"translate":"tile.red_mushroom_block.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=8}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e8" 0 0.4975 0
execute @s[scores={bp=8}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bp=8}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eVIII"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title8"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: §a"},{"translate":"library.text.regen_phase2"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §e"},{"translate":"entity.bee.name"},{"text":"§e, §a"},{"translate":"entity.slime.name"},{"text":"§e, §f"},{"translate":"entity.skeleton_horse.name"},{"text":"§e, §7"},{"translate":"entity.mule.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: §a"},{"translate":"tile.beehive.name"},{"text":"§e, §c"},{"translate":"tile.crying_obsidian.name"},{"text":"§e, §e"},{"translate":"tile.ancient_debris.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=9}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e9" 0 0.4975 0
execute @s[scores={bp=9}] ~ ~ ~ setblock 0 0 0 glass
execute @s[scores={bp=9}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eIX"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title9"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: §3"},{"translate":"library.text.regen_phase3"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §6"},{"translate":"entity.silverfish.name"},{"text":"§e, §3"},{"translate":"entity.cave_spider.name"},{"text":"§e, §1"},{"translate":"entity.phantom.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: §a"},{"translate":"tile.mycelium.name"},{"text":"§e, §c"},{"translate":"tile.brown_mushroom_block.mushroom.name"},{"text":"§e, §e"},{"translate":"tile.bone_block.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=10}] ~ ~ ~ summon mojang.minecraft:boss "§bPhase Progress §7- §bPhase §e10" 0 0.4975 0
execute @s[scores={bp=10}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bp=10}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg1"},{"text":" §eX"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title10"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: §b"},{"translate":"library.text.regen_phase4"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §d"},{"translate":"entity.endermite.name"},{"text":"§e, §5"},{"translate":"entity.shulker.name"},{"text":"§e, §d"},{"translate":"entity.enderman.name"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: §f"},{"translate":"tile.end_stone.name"},{"text":"§e, §d"},{"translate":"tile.purpur_block.default.name"},{"text":"§e, §e"},{"translate":"tile.purpur_block.chiseled.name"},{"translate":"mojang.text.msg5"}]}

execute @s[tag=c0,scores={bp=11}] ~ ~ ~ summon mojang.minecraft:boss "§bInfinite Blocks §7- §bAfterphases" 0 0.4975 0
execute @s[scores={bp=11}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bp=11}] ~ ~ ~ tellraw @a[rm=0] {"rawtext":[{"text":"§l§3"},{"translate":"mojang.text.msg17"},{"text":" §e"},{"translate":"mojang.text.enchantment"},{"text":" §8- §r§7"},{"translate":"mojang.text.header.title11"},{"text":"\n§r§f"},{"translate":"mojang.text.msg2"},{"text":"§7: §d"},{"translate":"library.text.regen_phase5"},{"text":"\n§f"},{"translate":"mojang.text.msg3"},{"text":"§7: §e???"},{"text":"\n§f"},{"translate":"mojang.text.msg4"},{"text":"§7: §e???"}]}
tellraw @a[rm=0] {"rawtext":[{"text":" "}]}

tag @e[type=mojang.minecraft:boss,r=1] add boss
execute @s[scores={bp=!11}] ~ ~ ~ damage @e[tag=boss] 940 void
effect @e[tag=boss] invisibility 1000000 255 true
scoreboard players set @s[scores={bp=!11}] hp 1