##clear area
fill 1 -57 1 -1 -61 -1 air 0 destroy
##outline
setblock 0 -61 0 barrier
setblock 0 -57 0 barrier
fill 1 -60 0 1 -58 0 barrier
fill 0 -60 1 0 -58 1 barrier
fill -1 -60 0 -1 -58 0 barrier
fill 0 -60 -1 0 -58 -1 barrier
fill 0 -60 0 0 -58 0 air

##msg
tag @s remove plon
scoreboard players add negative b-u2 1
tellraw @a[r=64] {"rawtext":[{"translate":"mojang.text.msg38"},{"score":{"name":"negative","objective":"b-u2"}},{"translate":"mojang.text.msg39"}]}

##raid duration
execute @s[scores={bp=..3}] ~ ~ ~ scoreboard players set @s mt 402
execute @s[scores={bp=4}] ~ ~ ~ scoreboard players set @s mt 482
execute @s[scores={bp=5}] ~ ~ ~ scoreboard players set @s mt 402
execute @s[scores={bp=6}] ~ ~ ~ scoreboard players set @s mt 402
execute @s[scores={bp=7..}] ~ ~ ~ scoreboard players set @s mt 500