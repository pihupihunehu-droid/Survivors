
scoreboard players random @s br 1 1146
##ter:stainHcly
##wh:0
##ylw:4
##lghgry:8
##cyan:9
##brown:12
##rd:14
##orng:1
##magen:2
##ter:hardened_clay
##LOG
##ac:log2

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=101..191}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={br=192..275}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={br=276..336}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={br=337..384}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={br=385..423}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={br=424..462}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={br=463..501}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={br=502..538}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={br=539..571}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={br=572..602}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={br=603..633}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=634..660}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={br=661..686}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=687..710}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={br=711..733}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={br=734..755}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={br=756..777}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={br=778..799}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={br=800..819}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={br=820..839}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={br=840..859}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={br=860..879}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={br=880..899}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=900..915}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={br=916..931}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={br=932..947}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={br=948..963}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={br=964..979}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={br=980..995}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={br=996..1009}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={br=1010..1023}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=1024..1034}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={br=1035..1045}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={br=1046..1056}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={br=1057..1067}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={br=1068..1076}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={br=1077..1084}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={br=1085..1091}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={br=1092..1098}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={br=1099..1105}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=1106..1111}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={br=1112..1117}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={br=1118..1122}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={br=1123..1127}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={br=1128..1132}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=1133..1136}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={br=1137..1140}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={br=1141..1143}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={br=1144..1146}] ~ ~ ~ setblock 0 0 0 log 2

scoreboard players reset @s br
