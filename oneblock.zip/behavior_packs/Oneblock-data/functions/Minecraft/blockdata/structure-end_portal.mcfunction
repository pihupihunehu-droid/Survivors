#clear area
fill 3 -7 -3 -3 -6 3 air 0 destroy
#5 facing x-
fill 2 -6 -1 2 -6 1 end_portal_frame 5
#6 facing z-
fill 1 -6 2 -1 -6 2 end_portal_frame 6
#7 facing x+
fill -2 -6 -1 -2 -6 0 end_portal_frame 7
setblock -2 -6 1 end_portal_frame 3
#4 facing z+
fill 0 -6 -2 1 -6 -2 end_portal_frame 0
setblock -1 -6 -2 end_portal_frame 4
#layer 4×4
fill 3 -7 -3 -3 -7 3 end_stone

playsound mob.enderdragon.growl @a 0 -5 0 0.95
tellraw @a {"rawtext":[{"translate":"mojang.text.msg11"},{"text":"\n"},{"translate":"mojang.text.msg12"}]}
##Creator notes: date [11/02/25]
#tellraw @a {"rawtext":[{"text":"<"},{"translate":"doc.text.me"},{"text":"> "},{"translate":"mojang.text.chat1"}]}