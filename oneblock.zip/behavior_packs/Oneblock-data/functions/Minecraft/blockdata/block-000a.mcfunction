
## This map based of Oneblock by IJAMinecraft
## This content was created by him, you can visit his site at the link here: ijaminecraft.com or visit his own Youtube: IJAMinecraft
## One Block version 2.4.0 McLogic By CuBeyzM ( It is forbidden to change or steal our content without the knowledge of the manager or content owner, to get permission or information you can contact us via email : cbz.official.id@gmail.com )
## My YouTube: CubeyzM

scoreboard players random @s br 1 5

execute @s[scores={br=1}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=2..3}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=4..5}] ~ ~ ~ setblock 0 0 0 log

scoreboard players reset @s br