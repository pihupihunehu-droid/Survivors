
scoreboard players random @s br 1 202

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=101..128}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=129..150}] ~ ~ ~ setblock 0 0 0 log 0
execute @s[scores={br=151..167}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=168..184}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=185..195}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=196..202}] ~ ~ ~ setblock 0 0 0 pumpkin

scoreboard players reset @s br