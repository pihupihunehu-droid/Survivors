
scoreboard players random @s br 1 870

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=101..191}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={br=192..275}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={br=276..336}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={br=337..375}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={br=376..412}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={br=413..443}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={br=444..474}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=475..502}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={br=503..529}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={br=530..556}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={br=557..582}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=583..605}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={br=606..627}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={br=628..647}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={br=648..667}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={br=668..687}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={br=688..707}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={br=708..727}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=728..743}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={br=744..757}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={br=758..771}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=772..782}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={br=783..793}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={br=794..804}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={br=805..813}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={br=814..820}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={br=821..827}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={br=828..834}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=835..840}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={br=841..846}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={br=847..851}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={br=852..856}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={br=857..861}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=862..863}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={br=864..868}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={br=869..870}] ~ ~ ~ setblock 0 0 0 log 2

scoreboard players reset @s br
