
scoreboard players random @s br 1 1755

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=101..171}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={br=172..239}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={br=240..307}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={br=308..370}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={br=371..422}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={br=423..468}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={br=469..514}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={br=515..560}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={br=561..602}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={br=603..644}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={br=645..683}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={br=684..722}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=723..760}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={br=761..797}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={br=798..833}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={br=834..863}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={br=864..893}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={br=894..923}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={br=924..953}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={br=954..983}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={br=984..1013}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={br=1014..1041}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={br=1042..1068}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={br=1069..1091}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={br=1092..1114}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={br=1115..1137}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={br=1138..1157}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={br=1158..1177}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={br=1178..1197}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={br=1198..1217}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={br=1218..1236}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=1237..1253}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={br=1254..1270}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={br=1271..1287}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={br=1288..1304}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={br=1305..1321}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={br=1322..1338}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={br=1339..1353}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={br=1354..1368}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={br=1369..1383}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={br=1384..1398}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={br=1399..1413}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=1414..1428}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={br=1429..1442}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={br=1443..1455}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={br=1456..1468}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={br=1469..1481}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={br=1482..1493}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={br=1494..1505}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={br=1506..1517}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={br=1518..1529}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={br=1530..1541}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={br=1542..1553}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={br=1554..1563}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={br=1564..1573}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={br=1574..1583}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=1584..1593}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={br=1594..1603}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={br=1604..1612}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={br=1613..1621}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={br=1622..1630}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={br=1631..1639}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={br=1640..1648}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={br=1649..1657}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={br=1658..1666}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={br=1667..1675}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={br=1676..1682}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={br=1683..1689}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={br=1690..1696}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={br=1697..1701}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={br=1702..1706}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={br=1707..1711}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={br=1712..1716}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=1717..1721}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={br=1722..1726}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={br=1727..1730}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={br=1731..1734}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={br=1735..1738}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=1739..1741}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={br=1742..1743}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=1744..1745}] ~ ~ ~ setblock 0 0 0 slime
execute @s[scores={br=1746..1747}] ~ ~ ~ setblock 0 0 0 honey_block
execute @s[scores={br=1748..1749}] ~ ~ ~ setblock 0 0 0 ancient_debris
execute @s[scores={br=1750..1751}] ~ ~ ~ setblock 0 0 0 lit_pumpkin
execute @s[scores={br=1752..1753}] ~ ~ ~ setblock 0 0 0 crying_obsidian
execute @s[scores={br=1754}] ~ ~ ~ setblock 0 0 0 beehive
execute @s[scores={br=1755}] ~ ~ ~ setblock 0 0 0 bee_nest

scoreboard players reset @s br