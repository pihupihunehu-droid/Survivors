
scoreboard players random @s br 1 744

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={br=101..193}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=194..240}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={br=241..276}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={br=277..312}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=313..343}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={br=344..373}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=374..401}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={br=402..427}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={br=428..452}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={br=453..476}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={br=477..500}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={br=501..524}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={br=525..548}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={br=549..572}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={br=573..596}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=597..614}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={br=615..630}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={br=631..646}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=647..659}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={br=660..670}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={br=671..679}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={br=680..687}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={br=688..695}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={br=696..703}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=704..710}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={br=711..717}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={br=718..723}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={br=724..729}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={br=730..735}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=736..739}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={br=740..741}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=742..744}] ~ ~ ~ setblock 0 0 0 diamond_ore

scoreboard players reset @s br
