
scoreboard players random @s br 1 1278

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=101..171}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={br=172..239}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={br=240..302}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={br=303..348}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={br=349..385}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={br=386..421}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={br=422..451}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={br=452..481}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={br=482..511}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={br=512..541}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={br=542..571}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={br=572..600}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={br=601..628}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={br=629..651}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={br=652..674}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=675..695}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={br=696..715}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={br=716..735}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={br=736..755}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={br=756..774}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=775..791}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={br=792..808}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={br=809..825}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={br=826..842}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={br=843..859}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={br=860..875}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={br=876..890}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={br=891..905}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={br=906..920}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=921..935}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={br=936..950}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=951..963}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={br=964..976}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={br=977..989}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={br=990..1001}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={br=1002..1013}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={br=1014..1025}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={br=1026..1037}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={br=1038..1049}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={br=1050..1061}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={br=1062..1073}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={br=1074..1084}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={br=1085..1094}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={br=1095..1104}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={br=1105..1114}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={br=1115..1124}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=1125..1134}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={br=1135..1143}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={br=1144..1152}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={br=1153..1161}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={br=1162..1170}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={br=1171..1179}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={br=1180..1188}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={br=1189..1197}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={br=1198..1204}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={br=1205..1211}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={br=1212..1216}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={br=1217..1221}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={br=1222..1226}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={br=1227..1231}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={br=1232..1236}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=1237..1241}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={br=1242..1246}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={br=1247..1251}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={br=1252..1255}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={br=1256..1259}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={br=1260..1263}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=1264..1266}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={br=1267..1268}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=1269..1270}] ~ ~ ~ setblock 0 0 0 slime
execute @s[scores={br=1271..1272}] ~ ~ ~ setblock 0 0 0 honey_block
execute @s[scores={br=1273..1274}] ~ ~ ~ setblock 0 0 0 ancient_debris
execute @s[scores={br=1275..1276}] ~ ~ ~ setblock 0 0 0 crying_obsidian
execute @s[scores={br=1277}] ~ ~ ~ setblock 0 0 0 beehive
execute @s[scores={br=1278}] ~ ~ ~ setblock 0 0 0 bee_nest

scoreboard players reset @s br
