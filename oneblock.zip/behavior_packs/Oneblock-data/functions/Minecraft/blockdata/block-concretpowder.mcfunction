setblock 0 -1 0 barrier 0 keep

##collours
##0 white, 1 rgb
##if score = 9 run cmd 8 "keep"
execute @s[scores={bp=!9}] ~ ~ ~ setblock 0 0 0 concretepowder 9
execute @s[scores={bp=9}] ~ ~ ~ setblock 0 0 0 concretepowder 8