
scoreboard players random @s br 1 1480

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=101..191}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={br=192..275}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={br=276..336}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={br=337..384}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={br=385..423}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={br=424..462}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={br=463..501}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={br=502..540}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={br=541..579}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={br=580..616}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={br=617..649}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={br=650..680}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={br=681..711}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=712..738}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={br=739..765}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={br=766..792}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={br=793..818}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=819..842}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={br=843..865}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={br=866..887}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={br=888..909}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={br=910..931}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={br=932..953}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={br=954..975}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={br=976..995}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={br=996..1015}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={br=1016..1035}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={br=1036..1055}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={br=1056..1075}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=1076..1093}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={br=1094..1111}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={br=1112..1129}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={br=1130..1145}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={br=1146..1161}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={br=1162..1177}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={br=1178..1193}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={br=1194..1209}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={br=1210..1225}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={br=1226..1239}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={br=1240..1253}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={br=1254..1267}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={br=1268..1281}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=1282..1294}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={br=1295..1305}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={br=1306..1316}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={br=1317..1327}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={br=1328..1338}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={br=1339..1349}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={br=1350..1360}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={br=1361..1371}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={br=1372..1382}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={br=1383..1391}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={br=1392..1400}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={br=1401..1408}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={br=1409..1415}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={br=1416..1422}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={br=1423..1429}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=1430..1435}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={br=1436..1441}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={br=1442..1447}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={br=1448..1452}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={br=1453..1457}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={br=1458..1462}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=1463..1466}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={br=1467..1470}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={br=1471..1473}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={br=1474..1476}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=1477..1478}] ~ ~ ~ setblock 0 0 0 ancient_debris
execute @s[scores={br=1479..1480}] ~ ~ ~ setblock 0 0 0 crying_obsidian

scoreboard players reset @s br
