
scoreboard players random @s br 1 1520

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=101..171}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={br=172..239}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={br=240..302}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={br=303..348}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={br=349..394}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={br=395..433}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={br=434..472}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=473..509}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={br=510..545}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={br=546..581}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={br=582..613}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={br=614..643}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={br=644..673}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={br=674..703}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={br=704..733}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={br=734..763}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={br=764..793}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={br=794..821}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={br=822..846}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={br=847..869}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={br=870..892}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={br=893..915}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={br=916..935}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={br=936..955}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={br=956..975}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={br=976..994}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=995..1011}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={br=1012..1028}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={br=1029..1045}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={br=1046..1062}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={br=1063..1079}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={br=1080..1096}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={br=1097..1112}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={br=1113..1127}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={br=1128..1142}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={br=1143..1157}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={br=1158..1172}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={br=1173..1187}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=1188..1201}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={br=1202..1214}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={br=1215..1227}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={br=1228..1240}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={br=1241..1253}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={br=1254..1265}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={br=1266..1277}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={br=1278..1289}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={br=1290..1301}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={br=1302..1313}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={br=1314..1325}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={br=1326..1335}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={br=1336..1345}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={br=1346..1355}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=1356..1365}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={br=1366..1374}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={br=1375..1383}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={br=1384..1392}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={br=1393..1401}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={br=1402..1410}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={br=1411..1419}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={br=1420..1428}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={br=1429..1435}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={br=1436..1442}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={br=1443..1449}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={br=1450..1456}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={br=1457..1461}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={br=1462..1466}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={br=1467..1471}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={br=1472..1476}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=1477..1481}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={br=1482..1486}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={br=1487..1491}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={br=1492..1495}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={br=1496..1499}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={br=1500..1503}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=1504..1506}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={br=1507..1508}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=1509..1510}] ~ ~ ~ setblock 0 0 0 slime
execute @s[scores={br=1511..1512}] ~ ~ ~ setblock 0 0 0 honey_block
execute @s[scores={br=1513..1514}] ~ ~ ~ setblock 0 0 0 ancient_debris
execute @s[scores={br=1515..1516}] ~ ~ ~ setblock 0 0 0 lit_pumpkin
execute @s[scores={br=1517..1518}] ~ ~ ~ setblock 0 0 0 crying_obsidian
execute @s[scores={br=1519}] ~ ~ ~ setblock 0 0 0 beehive
execute @s[scores={br=1520}] ~ ~ ~ setblock 0 0 0 bee_nest

scoreboard players reset @s br
