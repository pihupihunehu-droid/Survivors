setblock 0 0 0 chest

replaceitem block 0 0 0 slot.container 25 brown_mushroom 2

scoreboard players random @s cl-r 1 3
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 feather 2
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 feather 3
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 feather 4
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 sapling 1 4
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 sapling 2 4
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 coal 2
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 coal 3
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 3
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 0 leather 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 0 leather 2
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 0 leather 3
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 18 string 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 18 string 2
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 22 red_mushroom 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 22 red_mushroom 2
scoreboard players reset @s cl-r