scoreboard players random @s cl-r 0 1024
scoreboard players random @s cl-r 0 1024

execute @s[scores={cl-r=0..46}] ~ ~ ~ replaceitem block 0 0 0 slot.container 0 bone 3 0
execute @s[scores={cl-r=47..90}] ~ ~ ~ replaceitem block 0 0 0 slot.container 2 spider_eye 2 0
execute @s[scores={cl-r=91..137}] ~ ~ ~ replaceitem block 0 0 0 slot.container 4 emerald 3 0
execute @s[scores={cl-r=138..184}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 sand 10 0
execute @s[scores={cl-r=185..285}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 sand 10 0
execute @s[scores={cl-r=286..363}] ~ ~ ~ replaceitem block 0 0 0 slot.container 20 sand 10 0
execute @s[scores={cl-r=364..464}] ~ ~ ~ replaceitem block 0 0 0 slot.container 8 bucket 1 8
execute @s[scores={cl-r=465..511}] ~ ~ ~ replaceitem block 0 0 0 slot.container 13 deadbush 2 0
execute @s[scores={cl-r=512..1024}] ~ ~ ~ function Minecraft/blockdata/container/slot/type-0

scoreboard players reset @s cl-r