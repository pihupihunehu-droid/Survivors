scoreboard players random @s cl-r 0 1024
scoreboard players random @s cl-r 0 1024

execute @s[scores={cl-r=0..155}] ~ ~ ~ replaceitem block 0 0 0 slot.container 2 waterlily 3 0
execute @s[scores={cl-r=156..313}] ~ ~ ~ replaceitem block 0 0 0 slot.container 7 seagrass 4 0
execute @s[scores={cl-r=314..471}] ~ ~ ~ function Minecraft/blockdata/container/slot/type-3_1
execute @s[scores={cl-r=472..708}] ~ ~ ~ replaceitem block 0 0 0 slot.container 8 brown_mushroom 2 0
execute @s[scores={cl-r=709..945}] ~ ~ ~ replaceitem block 0 0 0 slot.container 20 red_mushroom 3 0
execute @s[scores={cl-r=946..1024}] ~ ~ ~ replaceitem block 0 0 0 slot.container 15 deadbush 1 0

scoreboard players reset @s cl-r