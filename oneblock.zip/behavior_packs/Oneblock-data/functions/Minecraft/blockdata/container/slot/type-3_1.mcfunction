scoreboard players random @s cl-r 0 1024
scoreboard players random @s cl-r 0 1024

execute @s[scores={cl-r=0..1024}] ~ ~ ~ replaceitem block 0 0 0 slot.container 1 diamond_sword 1 0
execute @s[scores={cl-r=145..226}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 diamond_helmet 1 0
execute @s[scores={cl-r=68..349}] ~ ~ ~ replaceitem block 0 0 0 slot.container 9 diamond 2 0
execute @s[scores={cl-r=511..692}] ~ ~ ~ replaceitem block 0 0 0 slot.container 10 gold_ingot 5 0
execute @s[scores={cl-r=397..478}] ~ ~ ~ replaceitem block 0 0 0 slot.container 13 diamond_chestplate 1 0
execute @s[scores={cl-r=496..577}] ~ ~ ~ replaceitem block 0 0 0 slot.container 15 diamond_pickaxe 1 0
execute @s[scores={cl-r=300..976}] ~ ~ ~ replaceitem block 0 0 0 slot.container 17 diamond_leggings 1 0
execute @s[scores={cl-r=711..792}] ~ ~ ~ replaceitem block 0 0 0 slot.container 20 horsearmordiamond 1 0
execute @s[scores={cl-r=543..824}] ~ ~ ~ replaceitem block 0 0 0 slot.container 21 enchanting_table 1 0
execute @s[scores={cl-r=827..908}] ~ ~ ~ replaceitem block 0 0 0 slot.container 23 diamond_boots 1 0
execute @s[scores={cl-r=943..1024}] ~ ~ ~ replaceitem block 0 0 0 slot.container 26 diamond 3 0

scoreboard players reset @s cl-r