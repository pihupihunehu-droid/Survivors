
scoreboard players random @s cl-r 0 1024
scoreboard players random @s cl-r 0 1024

execute @s[scores={cl-r=0..95}] ~ ~ ~ replaceitem block 0 0 0 slot.container 0 gunpowder 3 0
execute @s[scores={cl-r=96..191}] ~ ~ ~ replaceitem block 0 0 0 slot.container 1 rotten_flesh 3 0
execute @s[scores={cl-r=192..287}] ~ ~ ~ replaceitem block 0 0 0 slot.container 2 bone 5 0
execute @s[scores={cl-r=288..383}] ~ ~ ~ replaceitem block 0 0 0 slot.container 3 string 2 0
execute @s[scores={cl-r=384..439}] ~ ~ ~ replaceitem block 0 0 0 slot.container 4 wheat 4 0
execute @s[scores={cl-r=440..495}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 bread 2 0
execute @s[scores={cl-r=496..542}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 name_tag 1 0
execute @s[scores={cl-r=543..589}] ~ ~ ~ replaceitem block 0 0 0 slot.container 7 saddle 1 0
execute @s[scores={cl-r=590..634}] ~ ~ ~ replaceitem block 0 0 0 slot.container 8 coal 5 0
execute @s[scores={cl-r=635..679}] ~ ~ ~ replaceitem block 0 0 0 slot.container 9 redstone 5 0
execute @s[scores={cl-r=680..716}] ~ ~ ~ replaceitem block 0 0 0 slot.container 10 paper 3 0
execute @s[scores={cl-r=717..753}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 golden_apple 1 0
execute @s[scores={cl-r=754..784}] ~ ~ ~ replaceitem block 0 0 0 slot.container 12 beetroot_seeds 4 0
execute @s[scores={cl-r=785..815}] ~ ~ ~ replaceitem block 0 0 0 slot.container 13 melon_seeds 5 0
execute @s[scores={cl-r=816..846}] ~ ~ ~ replaceitem block 0 0 0 slot.container 14 pumpkin_seeds 3 0
execute @s[scores={cl-r=847..877}] ~ ~ ~ replaceitem block 0 0 0 slot.container 15 iron_ingot 1 0
execute @s[scores={cl-r=878..908}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 paper 1 0
execute @s[scores={cl-r=909..939}] ~ ~ ~ replaceitem block 0 0 0 slot.container 17 sugar_cane 3 0
execute @s[scores={cl-r=940..970}] ~ ~ ~ replaceitem block 0 0 0 slot.container 18 bucket 1 10
execute @s[scores={cl-r=971..995}] ~ ~ ~ replaceitem block 0 0 0 slot.container 20 sugar_cane 4 0
execute @s[scores={cl-r=996..1011}] ~ ~ ~ replaceitem block 0 0 0 slot.container 22 gold_ingot 1 0
execute @s[scores={cl-r=1012..1024}] ~ ~ ~ replaceitem block 0 0 0 slot.container 24 paper 2 0

scoreboard players reset @s cl-r