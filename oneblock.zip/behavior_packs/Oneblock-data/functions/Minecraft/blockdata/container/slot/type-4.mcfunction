scoreboard players random @s cl-r 0 1024
scoreboard players random @s cl-r 0 1024

execute @s[scores={cl-r=0..44}] ~ ~ ~ replaceitem block 0 0 0 slot.container 0 paper 2 0
execute @s[scores={cl-r=45..89}] ~ ~ ~ replaceitem block 0 0 0 slot.container 1 wheat 3 0
execute @s[scores={cl-r=90..134}] ~ ~ ~ replaceitem block 0 0 0 slot.container 2 carrot 1 0
execute @s[scores={cl-r=135..179}] ~ ~ ~ replaceitem block 0 0 0 slot.container 3 poisonous_potato 1 0
execute @s[scores={cl-r=180..224}] ~ ~ ~ replaceitem block 0 0 0 slot.container 4 potato 1 0
execute @s[scores={cl-r=225..269}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 gunpowder 3 0
execute @s[scores={cl-r=270..302}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 leather_helmet 1 0
execute @s[scores={cl-r=303..335}] ~ ~ ~ replaceitem block 0 0 0 slot.container 7 leather_chestplate 1 0
execute @s[scores={cl-r=336..368}] ~ ~ ~ replaceitem block 0 0 0 slot.container 8 leather_leggings 1 0
execute @s[scores={cl-r=369..401}] ~ ~ ~ replaceitem block 0 0 0 slot.container 9 leather_boots 1 0
execute @s[scores={cl-r=402..446}] ~ ~ ~ replaceitem block 0 0 0 slot.container 10 bamboo 4 0
execute @s[scores={cl-r=447..491}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 pumpkin 1 0
execute @s[scores={cl-r=492..536}] ~ ~ ~ replaceitem block 0 0 0 slot.container 12 tnt 3 0
execute @s[scores={cl-r=537..569}] ~ ~ ~ replaceitem block 0 0 0 slot.container 13 iron_ingot 1 0
execute @s[scores={cl-r=570..602}] ~ ~ ~ replaceitem block 0 0 0 slot.container 14 iron_nugget 1 0
execute @s[scores={cl-r=603..635}] ~ ~ ~ replaceitem block 0 0 0 slot.container 15 emerald 1 0
execute @s[scores={cl-r=636..668}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 gold_nugget 1 0
execute @s[scores={cl-r=669..701}] ~ ~ ~ replaceitem block 0 0 0 slot.container 17 gold_ingot 1 0
execute @s[scores={cl-r=702..746}] ~ ~ ~ replaceitem block 0 0 0 slot.container 18 experience_bottle 1 0
execute @s[scores={cl-r=747..770}] ~ ~ ~ replaceitem block 0 0 0 slot.container 19 diamond 1 0
execute @s[scores={cl-r=771..817}] ~ ~ ~ replaceitem block 0 0 0 slot.container 20 book 1 0
execute @s[scores={cl-r=818..864}] ~ ~ ~ replaceitem block 0 0 0 slot.container 21 clock 1 0
execute @s[scores={cl-r=865..911}] ~ ~ ~ replaceitem block 0 0 0 slot.container 22 compass 1 0
execute @s[scores={cl-r=912..958}] ~ ~ ~ replaceitem block 0 0 0 slot.container 23 map 1 0
execute @s[scores={cl-r=959..991}] ~ ~ ~ replaceitem block 0 0 0 slot.container 24 golden_apple 1 0
execute @s[scores={cl-r=992..1024}] ~ ~ ~ replaceitem block 0 0 0 slot.container 25 golden_helmet 1 0

scoreboard players reset @s cl-r