setblock 0 0 0 chest

replaceitem block 0 0 0 slot.container 10 water_bucket 1
