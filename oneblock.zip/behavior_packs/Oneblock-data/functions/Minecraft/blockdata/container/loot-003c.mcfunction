setblock 0 0 0 chest

function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0
function Minecraft/blockdata/container/slot/type-0