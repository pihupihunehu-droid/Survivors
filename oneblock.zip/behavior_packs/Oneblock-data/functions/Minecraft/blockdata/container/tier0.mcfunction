setblock 0 0 0 chest
loot insert 0 0 0 loot tier0 mainhand