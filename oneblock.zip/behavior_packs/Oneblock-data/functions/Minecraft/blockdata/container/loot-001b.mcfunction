setblock 0 0 0 chest

replaceitem block 0 0 0 slot.container 0 sapling 1
replaceitem block 0 0 0 slot.container 2 sapling 1 2
replaceitem block 0 0 0 slot.container 11 grass 1

scoreboard players random @s cl-r 1 5
execute @s[scores={cl-r=1..2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 apple 3
execute @s[scores={cl-r=3..4}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 apple 4
execute @s[scores={cl-r=5}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 apple 5
scoreboard players reset @s cl-r