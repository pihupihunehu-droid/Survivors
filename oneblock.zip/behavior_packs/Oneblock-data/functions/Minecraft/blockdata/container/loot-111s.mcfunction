setblock 0 0 0 chest

replaceitem block 0 0 0 slot.container 14 dirt 3
replaceitem block 0 0 0 slot.container 14 dirt 6
