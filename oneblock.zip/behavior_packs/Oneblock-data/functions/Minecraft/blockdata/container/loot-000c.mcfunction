setblock 0 0 0 chest

replaceitem block 0 0 0 slot.container 1 sapling 1
replaceitem block 0 0 0 slot.container 11 torch 1

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 log 5
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 log 6
scoreboard players reset @s cl-r