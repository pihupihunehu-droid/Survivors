setblock 0 0 0 chest

scoreboard players random @s cl-r 1 5
execute @s[scores={cl-r=1..2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 1 bone 2
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 2 iron_ingot 1
execute @s[scores={cl-r=4..5}] ~ ~ ~ replaceitem block 0 0 0 slot.container 2 bone_meal 4

scoreboard players random @s cl-r 1 6
execute @s[scores={cl-r=1..2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 log2 2
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 7 rabbit_foot 1
execute @s[scores={cl-r=4}] ~ ~ ~ replaceitem block 0 0 0 slot.container 7 rabbit_foot 2
execute @s[scores={cl-r=5..6}] ~ ~ ~ replaceitem block 0 0 0 slot.container 7 leather 2

scoreboard players random @s cl-r 1 4
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 9 coal 2
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 9 gold_ingot 1
execute @s[scores={cl-r=3..4}] ~ ~ ~ replaceitem block 0 0 0 slot.container 10 charcoal 1

scoreboard players random @s cl-r 1 32
execute @s[scores={cl-r=7}] ~ ~ ~ replaceitem block 0 0 0 slot.container 13 diamond 2
execute @s[tag=!acv-dis,scores={cl-r=7}] ~ ~ ~ tellraw @a {"rawtext":[{"selector":"@p[x=0,y=0,z=0,rm=0,c=1]"},{"text":" has just earned the achievement §d[Diamond in Ice]"}]}
execute @s[tag=!acv-dis,scores={cl-r=7}] ~ ~ ~ tag @s add acv-dis
execute @s[scores={cl-r=15..17}] ~ ~ ~ replaceitem block 0 0 0 slot.container 14 iron_ingot 3

scoreboard players reset @s cl-r
