setblock 0 0 0 chest
#var
function Minecraft/blockdata/container/slot/type-3_1
function Minecraft/blockdata/container/slot/type-3_1
function Minecraft/blockdata/container/slot/type-3_1
function Minecraft/blockdata/container/slot/type-3_1
function Minecraft/blockdata/container/slot/type-3_1
function Minecraft/blockdata/container/slot/type-3_1