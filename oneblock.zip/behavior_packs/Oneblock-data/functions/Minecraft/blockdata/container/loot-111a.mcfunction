setblock 0 0 0 chest

replaceitem block 0 0 0 slot.container 1 sapling 2
replaceitem block 0 0 0 slot.container 5 sapling 1 2
replaceitem block 0 0 0 slot.container 7 pumpkin_seeds 1
replaceitem block 0 0 0 slot.container 8 melon_seeds 1
replaceitem block 0 0 0 slot.container 9 arrow 11
replaceitem block 0 0 0 slot.container 10 carrot 1
replaceitem block 0 0 0 slot.container 11 potato 1
replaceitem block 0 0 0 slot.container 14 log2 2

scoreboard players random @s cl-r 1 3
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 2 apple 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 2 apple 2
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 2 apple 3

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 3 wheat_seeds 4
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 3 wheat_seeds 6

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 4 egg 2
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 4 egg 4

scoreboard players random @s cl-r 1 3
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 leather 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 leather 3
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 leather 6

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 12 feather 4
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 12 feather 2

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 13 sapling 3 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 13 sapling 3 2

scoreboard players random @s cl-r 1 3
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 15 rabbit_foot 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 15 rabbit_foot 2
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 15 rabbit_foot 3
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 4
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 coal 2
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 gold_ingot 1
execute @s[scores={cl-r=3..4}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 charcoal 1
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 4
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 emerald 2
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 diamond 1
execute @s[scores={cl-r=3..4}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 iron_ingot 1

scoreboard players reset @s cl-r
