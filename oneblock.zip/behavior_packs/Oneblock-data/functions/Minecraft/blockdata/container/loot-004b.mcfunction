setblock 0 0 0 chest

titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"text":"§dAncient ruin chest"}]}

replaceitem block 0 0 0 slot.container 1 obsidian 12
replaceitem block 0 0 0 slot.container 5 gold_ingot 1
replaceitem block 0 0 0 slot.container 10 flint_and_steel 1