setblock 0 0 0 chest
#end
function Minecraft/blockdata/container/slot/type-4
function Minecraft/blockdata/container/slot/type-4
function Minecraft/blockdata/container/slot/type-4
function Minecraft/blockdata/container/slot/type-4
function Minecraft/blockdata/container/slot/type-4
function Minecraft/blockdata/container/slot/type-4
function Minecraft/blockdata/container/slot/type-3_1
function Minecraft/blockdata/container/slot/type-3_1