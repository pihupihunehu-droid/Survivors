setblock 0 0 0 chest

replaceitem block 0 0 0 slot.container 0 sapling 1
replaceitem block 0 0 0 slot.container 2 sapling 1 2
replaceitem block 0 0 0 slot.container 22 pumpkin_seeds 1
replaceitem block 0 0 0 slot.container 24 potato 1
execute @s[scores={bb=115}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 water_bucket 1

scoreboard players random @s cl-r 1 3
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 apple 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 apple 2
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 apple 3
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1,bb=!115}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 carrot 3
execute @s[scores={cl-r=2,bb=!115}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 carrot 2
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 wheat_seeds 2
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 wheat_seeds 3
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 3
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 18 leather 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 18 leather 2
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 18 leather 3
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 20 egg 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 20 egg 2
scoreboard players reset @s cl-r