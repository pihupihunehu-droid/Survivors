setblock 0 0 0 chest

replaceitem block 0 0 0 slot.container 0 sapling 1
replaceitem block 0 0 0 slot.container 20 sapling 1
replaceitem block 0 0 0 slot.container 24 sapling 1 2
replaceitem block 0 0 0 slot.container 4 carrot 1
replaceitem block 0 0 0 slot.container 2 potato 1

scoreboard players random @s cl-r 1 3
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 apple 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 apple 2
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 5 apple 3
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 wheat_seeds 3
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 wheat_seeds 2
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 egg 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 egg 2
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 3
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 0 leather 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 0 leather 2
execute @s[scores={cl-r=3}] ~ ~ ~ replaceitem block 0 0 0 slot.container 0 leather 3
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 18 string 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 18 string 2
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 26 brown_mushroom 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 26 brown_mushroom 2
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 22 red_mushroom 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 22 red_mushroom 2
scoreboard players reset @s cl-r