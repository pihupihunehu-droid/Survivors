
## This map based of Oneblock by IJAMinecraft
## This content was created by him, you can visit his site at the link here: ijaminecraft.com or visit his own Youtube: IJAMinecraft
## One Block version 2.4.0 McLogic By CuBeyzM ( It is forbidden to change or steal our content without the knowledge of the manager or content owner, to get permission or information you can contact us via email : cbz.official.id@gmail.com )
## My YouTube: CubeyzM

setblock 0 0 0 chest
replaceitem block 0 0 0 slot.container 1 sapling 1

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 wheat_seeds 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 11 wheat_seeds 2
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 4
execute @s[scores={cl-r=1..2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 melon_slice 3
execute @s[scores={cl-r=3..4}] ~ ~ ~ replaceitem block 0 0 0 slot.container 6 apple 1
scoreboard players reset @s cl-r

scoreboard players random @s cl-r 1 2
execute @s[scores={cl-r=1}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 egg 1
execute @s[scores={cl-r=2}] ~ ~ ~ replaceitem block 0 0 0 slot.container 16 egg 2
scoreboard players reset @s cl-r