setblock 0 0 0 chest

titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"translate":"mojang.text.ui.name1"}]}

replaceitem block 0 0 0 slot.container 2 jukebox 1
replaceitem block 0 0 0 slot.container 4 record_13 1
replaceitem block 0 0 0 slot.container 6 record_cat 1
replaceitem block 0 0 0 slot.container 7 record_blocks 1
replaceitem block 0 0 0 slot.container 9 record_chirp 1
replaceitem block 0 0 0 slot.container 11 record_far 1
replaceitem block 0 0 0 slot.container 13 record_mall 1
replaceitem block 0 0 0 slot.container 15 record_mellohi 1
replaceitem block 0 0 0 slot.container 17 record_stal 1
replaceitem block 0 0 0 slot.container 19 record_strad 1
replaceitem block 0 0 0 slot.container 20 record_ward 1
replaceitem block 0 0 0 slot.container 22 record_wait 1