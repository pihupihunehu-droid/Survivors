setblock 0 0 0 chest

titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"translate":"mojang.text.ui.name2"}]}

replaceitem block 0 0 0 slot.container 8 noteblock 8
replaceitem block 0 0 0 slot.container 2 jukebox 1
replaceitem block 0 0 0 slot.container 4 record_11 1