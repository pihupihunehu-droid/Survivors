
scoreboard players random @s br 1 520

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={br=101..200}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=201..239}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=240..264}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={br=265..289}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={br=290..314}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=315..339}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={br=340..364}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={br=365..385}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={br=386..405}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={br=406..425}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={br=426..442}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=443..458}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={br=459..472}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={br=473..486}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=487..495}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={br=496..504}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=505..510}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=511..514}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={br=515..517}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={br=518..520}] ~ ~ ~ setblock 0 0 0 log 2

scoreboard players reset @s br
