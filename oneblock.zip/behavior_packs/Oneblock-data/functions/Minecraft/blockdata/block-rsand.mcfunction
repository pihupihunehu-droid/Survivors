setblock 0 -1 0 barrier 0 keep
setblock 0 0 0 sand 1