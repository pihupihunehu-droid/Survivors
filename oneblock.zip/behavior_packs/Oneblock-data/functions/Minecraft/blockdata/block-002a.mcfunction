
scoreboard players random @s br 1 517

execute @s[scores={br=1..100}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={br=101..190}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={br=191..240}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={br=241..285}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={br=286..323}] ~ ~ ~ setblock 0 0 0 log 0
execute @s[scores={br=324..353}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={br=354..378}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={br=379..403}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={br=404..428}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={br=429..453}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={br=454..473}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={br=474..488}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={br=489..501}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={br=502..511}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={br=512..517}] ~ ~ ~ setblock 0 0 0 pumpkin

scoreboard players reset @s br