tag @s remove mr-show
scoreboard players reset @s mt
tag @s remove mr-star
fill 1 -61 1 -1 -57 -1 air 0 replace barrier
weather clear
tellraw @a[r=64] {"rawtext":[{"translate":"mojang.text.msg40"},{"score":{"name":"negative","objective":"b-u2"}},{"translate":"mojang.text.msg41"},{"score":{"name":"negative","objective":"b-u2"}},{"translate":"mojang.text.msg42"}]}
execute @a[x=0,y=0,z=0,r=64] ~ ~ ~ playsound random.orb @s ~ ~ ~ 0.8 0.5