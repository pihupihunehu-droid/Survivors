execute @s[tag=!mr-star] ~ ~ ~ function Minecraft/blockdata/structure-void_prison
tag @s add mr-star
tag @e[type=!player,tag=!a,x=0,y=-61,z=0,dy=3] add int

execute @s[scores={bp=..3}] ~  ~ ~ function Minecraft/entitydata/entity-103a
execute @s[scores={bp=4}] ~  ~ ~ function Minecraft/entitydata/entity-104a
execute @s[scores={bp=5}] ~  ~ ~ function Minecraft/entitydata/entity-105a
execute @s[scores={bp=6}] ~  ~ ~ function Minecraft/entitydata/entity-106a
execute @s[scores={bp=7}] ~  ~ ~ function Minecraft/entitydata/entity-107a
execute @s[scores={bp=8}] ~  ~ ~ function Minecraft/entitydata/entity-108a
execute @s[scores={bp=9}] ~  ~ ~ function Minecraft/entitydata/entity-109a
execute @s[scores={bp=10}] ~  ~ ~ function Minecraft/entitydata/entity-110a
execute @s[scores={bp=11}] ~  ~ ~ function Minecraft/entitydata/entity-111rc
scoreboard players remove @s[scores={mt=1..}] mt 1

effect @e[tag=int,tag=!a] invisibility 1 20
effect @e[tag=int,tag=!a,type=!chicken,type=!vex] slow_falling 9 30
spreadplayers 0 0 1 5 @e[tag=int,tag=!a]
tag @e[tag=int] add a
tag @e[tag=a] remove int
execute @e[tag=a,tag=!int] ~ ~ ~ tp @s ~ 50 ~
tag @e[tag=a,tag=!int] remove a
execute @s[tag=!plon,scores={mt=0}] ~ ~ ~ function Minecraft/eventdata/party/partyoff
execute @s[scores={mt=0}] ~ ~ ~ tag @s add plon