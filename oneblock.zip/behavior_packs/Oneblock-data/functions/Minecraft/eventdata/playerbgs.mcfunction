execute @s[ry=-90,rx=20] ~ ~ ~ scoreboard players set @s b-u2 2
scoreboard players remove @s[scores={b-u2=1..}] b-u2 1
playsound misc.dawn @s[scores={b-u2=0}] 6 1 0 0.8 1
tag @s[scores={b-u2=0}] add c
scoreboard players reset @s[scores={b-u2=0}] b-u2