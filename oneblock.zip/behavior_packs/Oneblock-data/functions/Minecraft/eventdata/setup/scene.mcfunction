tag @s add r1
summon mojang.minecraft:box "Please wait a moment" 0 1 0
summon mojang.minecraft:entity 0 1 0
tag @e[type=mojang.minecraft:entity,tag=!on-block] add cl