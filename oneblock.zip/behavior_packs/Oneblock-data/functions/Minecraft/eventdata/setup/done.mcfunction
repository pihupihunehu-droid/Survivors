scoreboard players reset @s r1
tp @e[tag=cl] 0 -104 0
kill @e[tag=cl]
kill @e[family=box]
playanimation @e[family=box] animation.main.death
playsound item.spyglass.use @a[x=0,y=0,z=0,r=10] 0 1 0
tellraw @a {"rawtext":[{"translate":"mojang.text.msg16"}]}
summon mojang.minecraft:entity "§bBox Menu" 0 3.545 0
tag @e[type=mojang.minecraft:entity,r=1,x=~,y=~2.545,z=~] add dis
summon mojang.minecraft:main "Hold here to open" 0 3 0
tag @e[type=mojang.minecraft:main] add npc