execute @s[tag=!r1] ~ ~ ~ function Minecraft/eventdata/setup/scene
execute @s[scores={r1=0}] ~ ~ ~ function Minecraft/eventdata/setup/done
execute @s[scores={r1=1..}] ~ ~ ~ scoreboard players remove @s r1 1

##8 sec, 180°
execute @s[scores={r1=3}] ~ ~ ~ effect @e[family=box] invisibility 100 255 true
execute @s[scores={r1=4..}] ~ ~ ~ execute @e[family=box] ~ ~ ~ tp @s 0 ~0.02 0 ~9
execute @s[scores={r1=3}] ~ ~ ~ tp @e[family=box] 0 -104 0

##num=(1*a-b÷cos)-a^2
execute @s[scores={r1=10..}] ~ ~ ~ execute @e[tag=cl] ~ ~ ~ particle minecraft:falling_dust_top_snow_particle ^ ^3.5 ^0.8
execute @s[scores={r1=10..}] ~ ~ ~ execute @e[tag=cl] ~ ~ ~ particle minecraft:falling_dust_top_snow_particle ^ ^2.1 ^1
#execute @e[tag=cl] ~ ~ ~ particle minecraft:falling_dust_top_snow_particle ^ ^1.1 ^1.1
execute @e[tag=cl] ~ ~ ~ tp @s ~ ~ ~ ~-10