
execute @s[scores={r2=1..}] ~ ~ ~ scoreboard players remove @s r2 1
execute @s[scores={r2=0}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={r2=0}] ~ ~ ~ scoreboard players reset @s r2