scoreboard players add @s[scores={ss=1..,tc=..19}] tc 1
scoreboard players remove @s[scores={ss=1..,tc=20}] ss 1
scoreboard players set @s[scores={ss=1..,tc=20}] tc 0

execute @s[scores={ss=1..}] ~ ~ ~ setblock 0 0 0 bedrock
execute @s[scores={ss=1..}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"translate":"mojang.text.render10"},{"score":{"name":"@s","objective":"ss"}}]}

execute @s[scores={ss=0}] ~ ~ ~ function Minecraft/globaldata/rca-000az
execute @s[scores={ss=0}] ~ ~ ~ scoreboard players set @s tc 0

effect @e[tag=on-block] regeneration 1 255 true
scoreboard players add @s b-u1 1
scoreboard players add @s[scores={b-u1=20..}] b-u2 1
scoreboard players set @s[scores={b-u1=20..}] b-u1 0
tag @s[scores={b-u2=4..}] remove b1
tag @s[scores={b-u2=4..}] remove b2
scoreboard players set @s[scores={b-u2=4..}] b-u2 1

execute @s[tag=!b1,scores={b-u2=1,ss=1..}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,rm=6] actionbar {"rawtext":[{"translate":"mojang.text.render7"}]}
execute @s[tag=!b1,scores={b-u2=1}] ~ ~ ~ tag @s remove b3
execute @s[tag=!b1,scores={b-u2=1}] ~ ~ ~ tag @s add b1
execute @s[tag=!b2,scores={b-u2=2,ss=1..}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,rm=6] actionbar {"rawtext":[{"translate":"mojang.text.render8"}]}
execute @s[tag=!b2,scores={b-u2=2}] ~ ~ ~ tag @s add b2
execute @s[tag=!b3,scores={b-u2=3,ss=1..}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,rm=6] actionbar {"rawtext":[{"translate":"mojang.text.render9"}]}
execute @s[tag=!b3,scores={b-u2=3}] ~ ~ ~ tag @s add b3