fill 0 0 0 0 0 0 barrier 0 destroy
execute @a[x=0,y=-1,z=0,dy=1] ~ ~ ~ tp @s ~ 1 ~
scoreboard players set @s[scores={bp=0}] cd 9
scoreboard players set @s[scores={bp=1..2}] cd 7
scoreboard players set @s[scores={bp=3..4}] cd 8
scoreboard players set @s[scores={bp=5}] cd 6
scoreboard players set @s[scores={bp=6}] cd 7
scoreboard players set @s[scores={bp=7..8}] cd 5
scoreboard players set @s[scores={bp=9..}] cd 4
fill 0 -1 0 0 -1 0 air 0 replace barrier 0
scoreboard players set @s air 1