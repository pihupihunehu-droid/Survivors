scoreboard players set @s air 0
scoreboard players add @p[c=1,x=0,y=0,z=0,rm=0] bb 1
scoreboard players add @s bb 1
execute @s[scores={bp=11}] ~ ~ ~ scoreboard players add @s bc 1
execute @s[scores={bc=401..}] ~ ~ ~ scoreboard players set @s bc 0
effect @e[tag=on-block] clear

scoreboard players set @s sw 1
scoreboard players add @s bd 1
scoreboard players operation @s pattern = @s bd
scoreboard players operation @s pattern %= size pattern

execute @s[scores={bp=0}] ~ ~ ~ function Minecraft/miscdata/dir-000a
execute @s[scores={bp=1}] ~ ~ ~ function Minecraft/miscdata/dir-001a
execute @s[scores={bp=2}] ~ ~ ~ function Minecraft/miscdata/dir-002a
execute @s[scores={bp=3}] ~ ~ ~ function Minecraft/miscdata/dir-003a
execute @s[scores={bp=4}] ~ ~ ~ function Minecraft/miscdata/dir-004a
execute @s[scores={bp=5}] ~ ~ ~ function Minecraft/miscdata/dir-005a
execute @s[scores={bp=6}] ~ ~ ~ function Minecraft/miscdata/dir-006a
execute @s[scores={bp=7}] ~ ~ ~ function Minecraft/miscdata/dir-007a
execute @s[scores={bp=8}] ~ ~ ~ function Minecraft/miscdata/dir-008a
execute @s[scores={bp=9}] ~ ~ ~ function Minecraft/miscdata/dir-009a
execute @s[scores={bp=10}] ~ ~ ~ function Minecraft/miscdata/dir-010a
execute @s[scores={bp=11}] ~ ~ ~ function Minecraft/miscdata/dir-auto