## hybrid-tier: #02

particle minecraft:llama_spit_smoke 0 0.8 0

execute @s[scores={bd=90}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=185}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=280}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=375}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[tag=c0,scores={pattern=0..2,sw=1}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=0..2,sw=1}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[scores={bb=284..295}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=296..297}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=298..301}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=302}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=303}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=304}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=305..309}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=310..311}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=312..322}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=323}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=323}] ~ ~ ~ summon mooshroom 0 1 0
execute @s[scores={bb=323}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=324}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=325..328}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=329..331}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=332..334}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=335..337}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=338..340}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=341..342}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=343..344}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=345..346}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=346}] ~ ~ ~ summon mooshroom 0 1 0
execute @s[scores={bb=346}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=347..350}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=351}] ~ ~ ~ function Minecraft/blockdata/container/loot-002a
execute @s[scores={bb=351}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=352..355}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=356..357}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=358}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=359..360}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=361..367}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=367}] ~ ~ ~ summon zombie 0 1 0
execute @s[scores={bb=367}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=368..370}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=371..372}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=373..380}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=381..382}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=383..384}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=385}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=386..390}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=390}] ~ ~ ~ summon zombie 0 1 0
execute @s[scores={bb=390}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=391..394}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=395..399}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=400}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=401}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=402}] ~ ~ ~ function Minecraft/blockdata/container/loot-002a
execute @s[scores={bb=403..411}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=411}] ~ ~ ~ summon rabbit 0 1 0
execute @s[scores={bb=411}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=412..414}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=415..417}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=418..423}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=424..427}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=428..430}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=431..434}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=434}] ~ ~ ~ summon mooshroom 0 1 0
execute @s[scores={bb=434}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=435..437}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=438..442}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=443}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=444}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=445..452}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=453}] ~ ~ ~ function Minecraft/blockdata/container/loot-002b
execute @s[scores={bb=454}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=454}] ~ ~ ~ function Minecraft/entitydata/entity-002a
execute @s[scores={bb=454}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=455..458}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=459..462}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=463}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=464..466}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=467}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=468..477}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=477}] ~ ~ ~ summon spider 0 1 0
execute @s[scores={bb=477}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=478}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=479}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=480..483}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=484..486}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=487..493}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=494}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=495..496}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=497..498}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=499}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=500}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=500}] ~ ~ ~ function Minecraft/entitydata/entity-002a
execute @s[scores={bb=500}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=501}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=502..503}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=504}] ~ ~ ~ function Minecraft/blockdata/container/loot-002a
execute @s[scores={bb=505..506}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=507..513}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=514}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=515..516}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=517..518}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=518}] ~ ~ ~ title @a[x=0,y=0,z=0,r=6] times 10 60 20
execute @s[scores={bb=518}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=5] actionbar {"rawtext":[{"translate":"mojang.text.render13"},{"text":"§e0"}]}
execute @s[scores={bb=518}] ~ ~ ~ playsound note.pling @a[r=6] 0 1 0 1 0.5 1
execute @s[scores={bb=519..521}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=521}] ~ ~ ~ summon creeper 0 1 0 minecraft:entity_spawned "Creeper"
execute @s[scores={bb=521}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=522..526}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=527..528}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=529..531}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=532..533}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=534}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=535}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=536..537}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=538}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=539..541}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=542..543}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=544}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=544}] ~ ~ ~ function Minecraft/entitydata/entity-002a
execute @s[scores={bb=544}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=545}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=546}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=547}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=548..549}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=550}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=551}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=552..554}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=555}] ~ ~ ~ function Minecraft/blockdata/container/loot-002a
execute @s[scores={bb=556..557}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=558..561}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=562..564}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=565}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=565}] ~ ~ ~ summon zombie 0 1 0
execute @s[scores={bb=565}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=566..567}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=568..571}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=572}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=573..574}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=575..577}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=578}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=579..580}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=581..583}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=584..585}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=586}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=587}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=588}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=588}] ~ ~ ~ function Minecraft/entitydata/entity-002a
execute @s[scores={bb=588}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=589}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=590..593}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=594..595}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=596}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=597..600}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=601}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=602}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=603..605}] ~ ~ ~ function Minecraft/blockdata/block-002a
execute @s[scores={bb=606}] ~ ~ ~ function Minecraft/blockdata/container/loot-002a
execute @s[scores={bb=607..609}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=609}] ~ ~ ~ summon spider 0 1 0
execute @s[scores={bb=609}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=610}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=611}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=612}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=613}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=614..615}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=616..620}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=621}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=622..623}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=624}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=625}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=626}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=627}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=628}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=629}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=630}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=631..632}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=632}] ~ ~ ~ summon creeper 0 1 0
execute @s[scores={bb=632}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=633..635}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=636..637}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=638..639}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=640}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=641..643}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=644..646}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=647..649}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=650}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=651..656}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=657}] ~ ~ ~ function Minecraft/blockdata/container/loot-002a
execute @s[scores={bb=658..659}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=660..662}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=663..665}] ~ ~ ~ setblock 0 0 0 dirt
execute @s[scores={bb=666}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=667..668}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=669..671}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=672}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=673..675}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=676}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=677..679}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=680}] ~ ~ ~ function Minecraft/blockdata/container/loot-002c
execute @s[scores={bb=681}] ~ ~ ~ scoreboard players set @s ss 30
execute @s[scores={bb=681}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=681}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9