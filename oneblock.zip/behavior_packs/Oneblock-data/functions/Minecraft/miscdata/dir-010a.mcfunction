execute @s[scores={pattern=0,bd=141}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={pattern=0,bd=281}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={pattern=0,bd=421}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={pattern=0,bd=561}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={pattern=0,bd=701}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={pattern=0,bd=841}] ~ ~ ~ scoreboard players set @s sw 0

execute @s[scores={bd=854}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={bd=854}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=0,sw=1}] ~ ~ ~ scoreboard players add @s hp 8
execute @s[tag=c0,scores={pattern=0,sw=1}] ~ ~ ~ effect @e[tag=boss] instant_health 1 1 true

execute @s[scores={bb=5447..5466}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=5467..5481}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5482..5489}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=5490..5502}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=5503}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=5504..5518}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=5518}] ~ ~ ~ function Minecraft/entitydata/mob/endermite
execute @s[scores={bb=5518}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5519..5521}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=5522}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=5523}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=5524..5544}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5545..5548}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5548}] ~ ~ ~ function Minecraft/entitydata/mob/endermite
execute @s[scores={bb=5548}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5549}] ~ ~ ~ function Minecraft/blockdata/container/loot-010a
execute @s[scores={bb=5550..5554}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5555..5573}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=5574..5576}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5576}] ~ ~ ~ function Minecraft/entitydata/mob/enderman
execute @s[scores={bb=5576}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5577..5581}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5582..5599}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5600}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=5601..5606}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5606}] ~ ~ ~ function Minecraft/entitydata/mob/enderman
execute @s[scores={bb=5606}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5607..5608}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5609}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5610}] ~ ~ ~ function Minecraft/blockdata/container/loot-010a
execute @s[scores={bb=5611..5619}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5620}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5621..5634}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5634}] ~ ~ ~ function Minecraft/entitydata/mob/endermite
execute @s[scores={bb=5634}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5635..5642}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5643}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5644..5645}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5646}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=5647..5648}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5649}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=5650..5664}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=5664}] ~ ~ ~ function Minecraft/entitydata/entity-010a
execute @s[scores={bb=5664}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5665..5666}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=5667..5670}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5671}] ~ ~ ~ function Minecraft/blockdata/container/tier2
execute @s[scores={bb=5671}] ~ ~ ~ playsound respawn_anchor.charge @a[r=35] 0 1 0 1 0.5 1
execute @s[scores={bb=5672..5679}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5680..5686}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5687}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5688..5689}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5690}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5691}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5691}] ~ ~ ~ function Minecraft/entitydata/mob/shulker
execute @s[scores={bb=5691}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5692..5696}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5697}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5698}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=5699..5711}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=5712}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=5713..5721}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5721}] ~ ~ ~ function Minecraft/entitydata/entity-010a
execute @s[scores={bb=5721}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5722..5727}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5728..5729}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=5730..5731}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5732}] ~ ~ ~ function Minecraft/blockdata/container/loot-010a
execute @s[scores={bb=5733..5740}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5741..5749}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=5749}] ~ ~ ~ function Minecraft/entitydata/mob/endermite
execute @s[scores={bb=5749}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5750..5755}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=5756..5773}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5774..5775}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5776}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5777}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5778}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5779}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=5779}] ~ ~ ~ function Minecraft/entitydata/entity-010a
execute @s[scores={bb=5779}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5780..5791}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=5792}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5793}] ~ ~ ~ function Minecraft/blockdata/container/loot-010b
execute @s[scores={bb=5793}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=5794..5806}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5806}] ~ ~ ~ function Minecraft/entitydata/mob/endermite
execute @s[scores={bb=5806}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5807..5809}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5810}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5811}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5812}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5813..5814}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=5815}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=5816}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5817}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=5818..5828}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=5829}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5830}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=5831}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5832..5836}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=5836}] ~ ~ ~ function Minecraft/entitydata/mob/enderman
execute @s[scores={bb=5836}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5837..5845}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=5846}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=5847..5853}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=5854}] ~ ~ ~ function Minecraft/blockdata/container/tier1
execute @s[scores={bb=5854}] ~ ~ ~ playsound item.trident.thunder @a[r=35] 0 1 0 0.6 0.5 0.6
execute @s[scores={bb=5855..5862}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=5863}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5863}] ~ ~ ~ function Minecraft/entitydata/entity-010a
execute @s[scores={bb=5863}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5864}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5865..5876}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=5877}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5878}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5879..5893}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5893}] ~ ~ ~ function Minecraft/entitydata/mob/enderman
execute @s[scores={bb=5893}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5894..5899}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=5899}] ~ ~ ~ tag @s add mr-show
execute @s[scores={bb=5904}] ~ ~ ~ function Minecraft/blockdata/structure-end_portal
execute @s[scores={bb=5900..5901}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5902}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=5903}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5904..5913}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=5914}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5915}] ~ ~ ~ function Minecraft/blockdata/container/loot-010b
execute @s[scores={bb=5915}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=5916}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=5917}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=5918}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=5919}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5920}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=5920}] ~ ~ ~ function Minecraft/entitydata/mob/endermite
execute @s[scores={bb=5920}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5921..5933}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=5934}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=5935..5944}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5945}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5946..5950}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=5950}] ~ ~ ~ function Minecraft/entitydata/entity-010a
execute @s[scores={bb=5950}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5951..5955}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=5956}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=5957}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=5958}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=5959..5975}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=5976}] ~ ~ ~ function Minecraft/blockdata/container/loot-010a
execute @s[scores={bb=5977..5978}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=5978}] ~ ~ ~ function Minecraft/entitydata/mob/shulker
execute @s[scores={bb=5978}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5979..5985}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=5986..5987}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bb=5988..6008}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6008}] ~ ~ ~ function Minecraft/entitydata/entity-010a
execute @s[scores={bb=6008}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=6009..6015}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6016..6027}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=6028}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=6029}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=6030..6036}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=6037}] ~ ~ ~ function Minecraft/blockdata/container/loot-010a
execute @s[scores={bb=6037}] ~ ~ ~ function Minecraft/entitydata/mob/endermite
execute @s[scores={bb=6037}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=6038..6048}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=6049..6050}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=6051}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=6052..6053}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=6054..6066}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=6066}] ~ ~ ~ function Minecraft/entitydata/entity-010a
execute @s[scores={bb=6066}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=6067..6071}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=6072..6087}] ~ ~ ~ setblock 0 0 0 end_bricks
execute @s[scores={bb=6088}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=6089..6096}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=6096}] ~ ~ ~ function Minecraft/entitydata/mob/endermite
execute @s[scores={bb=6096}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=6097}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=6098}] ~ ~ ~ function Minecraft/blockdata/container/loot-010b
execute @s[scores={bb=6098}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=6099..6109}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=6110}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=6111}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=6112..6123}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6123}] ~ ~ ~ function Minecraft/entitydata/mob/enderman
execute @s[scores={bb=6123}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=6124..6139}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6140}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=6141..6151}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=6152..6153}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=6153}] ~ ~ ~ function Minecraft/entitydata/entity-010a
execute @s[scores={bb=6153}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=6154}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=6155..6158}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=6159}] ~ ~ ~ function Minecraft/blockdata/container/tier0
execute @s[scores={bb=6159}] ~ ~ ~ playsound note.pling @a[r=35] 0 1 0 1 0.5 1
execute @s[scores={bb=6160..6172}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=6173}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=6174..6180}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=6180}] ~ ~ ~ function Minecraft/entitydata/mob/enderman
execute @s[scores={bb=6180}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=6181..6183}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=6184}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=6185}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=6186}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=6187}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=6188..6189}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=6190}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=6191..6210}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6210}] ~ ~ ~ function Minecraft/entitydata/mob/endermite
execute @s[scores={bb=6210}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=6211..6219}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6220}] ~ ~ ~ function Minecraft/blockdata/container/loot-010b
execute @s[scores={bb=6220}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=6221}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6222}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=6223..6225}] ~ ~ ~ setblock 0 0 0 purpur_block 2
execute @s[scores={bb=6226}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=6227..6231}] ~ ~ ~ setblock 0 0 0 purpur_block
execute @s[scores={bb=6232..6237}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6237}] ~ ~ ~ function Minecraft/entitydata/entity-010a
execute @s[scores={bb=6237}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=6238..6258}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6259}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=6260..6280}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6281}] ~ ~ ~ function Minecraft/blockdata/container/loot-010a
execute @s[scores={bb=6282..6290}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6291..6292}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=6293..6296}] ~ ~ ~ setblock 0 0 0 end_stone
execute @s[scores={bb=6297..6298}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=6299}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=6300}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=6301}] ~ ~ ~ function Minecraft/blockdata/container/loot-010c
execute @s[scores={bb=6302}] ~ ~ ~ scoreboard players set @s ss 120
execute @s[scores={bb=6302}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=6302}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9