## hybrid-tier: #03

particle minecraft:llama_spit_smoke 0 0.8 0

execute @s[scores={bd=142}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=428}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[tag=c0,scores={pattern=0,sw=1}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=0,sw=1}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[scores={bb=682..689}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=690..691}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=692..695}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=696..701}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=702}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=703..705}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=706..707}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=708..709}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=710..711}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=712..714}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=715..716}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=717..721}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=721}] ~ ~ ~ summon wolf 0 1 0
execute @s[scores={bb=721}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=722..723}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=724..733}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=734..735}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=734}] ~ ~ ~ tag @s add mr-show
execute @s[scores={bb=736}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=737..739}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=740..744}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=745..746}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=747}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=748}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=748}] ~ ~ ~ summon stray 0 1 0
execute @s[scores={bb=748}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=749}] ~ ~ ~ function Minecraft/blockdata/container/loot-003b
execute @s[scores={bb=749}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=750..751}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=752..757}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=758}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=759..760}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=761..769}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=770}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=771..772}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=772}] ~ ~ ~ summon stray 0 1 0
execute @s[scores={bb=772}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=773..780}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=781..782}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=783..785}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=786}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=787..791}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=792}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=793..794}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=795..798}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=799}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=799}] ~ ~ ~ summon fox 0 1 0
execute @s[scores={bb=799}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=800..803}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=804}] ~ ~ ~ function Minecraft/blockdata/container/loot-003a
execute @s[scores={bb=805..807}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=808..810}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=811..821}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=822}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=823}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=824}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=824}] ~ ~ ~ summon fox 0 1 0
execute @s[scores={bb=824}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=825..828}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=829}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=830..833}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=834..836}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=837..845}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=846..847}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=848..849}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=850}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=851}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=851}] ~ ~ ~ function Minecraft/entitydata/entity-002a
execute @s[scores={bb=851}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=852}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=853}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=854..855}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=856..858}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=859}] ~ ~ ~ function Minecraft/blockdata/container/loot-003a
execute @s[scores={bb=860..861}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=862}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=863..865}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=866..868}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=869..870}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=871}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=872..873}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=874..877}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=876}] ~ ~ ~ summon polar_bear 0 1 0
execute @s[scores={bb=876}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=878}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=879..880}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=881}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=882..883}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=884}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=885..886}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=887}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=888..889}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=890}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=891..895}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=896..897}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=898}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=899}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=900..901}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=902..903}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=903}] ~ ~ ~ function Minecraft/entitydata/entity-002a
execute @s[scores={bb=903}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=904..906}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=907}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=908..913}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=914}] ~ ~ ~ function Minecraft/blockdata/container/loot-003a
execute @s[scores={bb=915..918}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=919}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=920..928}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=928}] ~ ~ ~ summon wolf 0 1 0
execute @s[scores={bb=928}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=929}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=930..939}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=940}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=941..942}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=943..944}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=945}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=946}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=947..948}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=949}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=950..953}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=954..955}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=955}] ~ ~ ~ summon stray 0 1 0
execute @s[scores={bb=955}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=956}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=957}] ~ ~ ~ function Minecraft/blockdata/block-003a
execute @s[scores={bb=958}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=959..966}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=967..968}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=969}] ~ ~ ~ function Minecraft/blockdata/container/loot-003a
execute @s[scores={bb=970..971}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=972..980}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=980}] ~ ~ ~ summon stray 0 1 0
execute @s[scores={bb=980}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=981}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=982}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=983..984}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=985..986}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=987}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=988..989}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=990}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=991..992}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=993..1004}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1005}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1006}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=1007}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1007}] ~ ~ ~ summon fox 0 1 0
execute @s[scores={bb=1007}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1008..1014}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1015}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1016}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1017..1023}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1024}] ~ ~ ~ function Minecraft/blockdata/container/loot-003a
execute @s[scores={bb=1025..1030}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1031..1032}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1032}] ~ ~ ~ summon wolf 0 1 0
execute @s[scores={bb=1032}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1033..1035}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=1036}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1037}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=1038}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1039..1040}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1041}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=1042..1045}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=1046..1047}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1048..1056}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1057..1058}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=1059}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1059}] ~ ~ ~ summon stray 0 1 0
execute @s[scores={bb=1059}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1060}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=1061}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1062..1066}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=1067..1071}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1072..1077}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=1078}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1079}] ~ ~ ~ function Minecraft/blockdata/container/loot-003a
execute @s[scores={bb=1080}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1081..1083}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=1084}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1084}] ~ ~ ~ summon stray 0 1 0
execute @s[scores={bb=1084}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1085}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1086}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=1087}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1088..1089}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=1090..1091}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1092}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=1093..1094}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=1095}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1096..1100}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=1101..1104}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=1105..1107}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=1108..1109}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1110}] ~ ~ ~ setblock 0 0 0 stone 5
execute @s[scores={bb=1111}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=1111}] ~ ~ ~ summon polar_bear 0 1 0
execute @s[scores={bb=1111}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1112..1114}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=1115}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1116..1119}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=1120..1124}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=1125}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=1126..1128}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=1129..1130}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=1131..1132}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=1133}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=1134}] ~ ~ ~ function Minecraft/blockdata/container/loot-003a
execute @s[scores={bb=1135}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=1136..1138}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=1139..1140}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=1141}] ~ ~ ~ setblock 0 0 0 snow
execute @s[scores={bb=1142..1143}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1144}] ~ ~ ~ setblock 0 0 0 packed_ice
execute @s[scores={bb=1145..1146}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=1147}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1148}] ~ ~ ~ setblock 0 0 0 log 1
execute @s[scores={bb=1149..1150}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1151..1152}] ~ ~ ~ setblock 0 0 0 stone 1
execute @s[scores={bb=1153}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1154}] ~ ~ ~ function Minecraft/blockdata/container/loot-003c
execute @s[scores={bb=1155}] ~ ~ ~ scoreboard players set @s ss 40
execute @s[scores={bb=1155}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=1155}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9