## hybrid-tier: #05

particle minecraft:llama_spit_smoke 0 0.8 0

execute @s[scores={pattern=0,bd=55..}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={pattern=0,bd=55..}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=1,bd=1..584}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={pattern=1,bd=1..584}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=2,bd=617}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={pattern=2,bd=617}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={bb=1727..1742}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1743..1745}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=1746..1750}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1751..1761}] ~ ~ ~ function Minecraft/blockdata/block-005a
execute @s[scores={bb=1762}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1763..1770}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=1771}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1772..1779}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1779}] ~ ~ ~ summon parrot 0 1 0
execute @s[scores={bb=1779}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1780..1794}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1795..1803}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=1804}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1805..1807}] ~ ~ ~ function Minecraft/blockdata/block-005a
execute @s[scores={bb=1808}] ~ ~ ~ function Minecraft/blockdata/container/loot-005a
execute @s[scores={bb=1808}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=1808}] ~ ~ ~ summon vex 0 1 0
execute @s[scores={bb=1808}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1809..1812}] ~ ~ ~ function Minecraft/blockdata/block-005a
execute @s[scores={bb=1813..1837}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1837}] ~ ~ ~ summon ocelot 0 1 0
execute @s[scores={bb=1837}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1838}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1839..1843}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1844..1861}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1862}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1863..1866}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1867}] ~ ~ ~ function Minecraft/blockdata/container/loot-005b
execute @s[scores={bb=1867}] ~ ~ ~ summon ocelot 0 1 0
execute @s[scores={bb=1867}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1868..1887}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1888..1889}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=1890..1894}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=1894}] ~ ~ ~ summon panda 0 1 0
execute @s[scores={bb=1894}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1895..1900}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=1901..1903}] ~ ~ ~ function Minecraft/blockdata/block-005a
execute @s[scores={bb=1904..1905}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1906..1922}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1923}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1924}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1924}] ~ ~ ~ summon witch 0 1 0
execute @s[scores={bb=1924}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1925}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1926}] ~ ~ ~ function Minecraft/blockdata/container/loot-005c
execute @s[scores={bb=1927..1928}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1929..1930}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1931}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1932..1938}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1939..1951}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1951}] ~ ~ ~ summon horse 0 1 0
execute @s[scores={bb=1951}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1952..1954}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1955..1971}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=1972..1980}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=1981}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1981}] ~ ~ ~ function Minecraft/entitydata/entity-005a
execute @s[scores={bb=1981}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1982..1984}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=1985}] ~ ~ ~ function Minecraft/blockdata/container/loot-005a
execute @s[scores={bb=1986..2005}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=2006}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2007}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=2008..2009}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2009}] ~ ~ ~ summon parrot 0 1 0
execute @s[scores={bb=2009}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2010}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=2011}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2012}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=2013..2014}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2015..2021}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=2022..2040}] ~ ~ ~ function Minecraft/blockdata/block-005a
execute @s[scores={bb=2039}] ~ ~ ~ function Minecraft/entitydata/entity-005a
execute @s[scores={bb=2039}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2041}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2042..2043}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2044}] ~ ~ ~ function Minecraft/blockdata/container/loot-005a
execute @s[scores={bb=2045..2049}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2050..2051}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2052}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2053..2059}] ~ ~ ~ function Minecraft/blockdata/block-005a
execute @s[scores={bb=2060}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=2060}] ~ ~ ~ tag @s add mr-show
execute @s[scores={bb=2061}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2062..2064}] ~ ~ ~ function Minecraft/blockdata/block-005a
execute @s[scores={bb=2065..2067}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2067}] ~ ~ ~ summon vex 0 1 0
execute @s[scores={bb=2067}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2068..2074}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2075..2077}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2078}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=2079..2097}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2097}] ~ ~ ~ function Minecraft/entitydata/entity-005a
execute @s[scores={bb=2097}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2098}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=2099..2102}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2103}] ~ ~ ~ function Minecraft/blockdata/container/loot-005s
execute @s[scores={bb=2104..2118}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2119..2124}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=2124}] ~ ~ ~ summon ocelot 0 1 0
execute @s[scores={bb=2124}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2125..2142}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=2143}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=2144..2154}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=2154}] ~ ~ ~ function Minecraft/entitydata/entity-005a
execute @s[scores={bb=2154}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2155..2161}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=2162}] ~ ~ ~ function Minecraft/blockdata/container/loot-005a
execute @s[scores={bb=2163..2173}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=2174..2178}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=2179..2182}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2182}] ~ ~ ~ summon witch 0 1 0
execute @s[scores={bb=2182}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2183..2185}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2186}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=2187..2188}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2189}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2190..2202}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2203..2208}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=2209}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2210..2212}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2212}] ~ ~ ~ function Minecraft/entitydata/entity-005a
execute @s[scores={bb=2212}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2213..2220}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2221}] ~ ~ ~ function Minecraft/blockdata/container/loot-005b
execute @s[scores={bb=2222}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2223..2228}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=2229..2239}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2239}] ~ ~ ~ summon horse 0 1 0
execute @s[scores={bb=2239}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2240..2248}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2249..2254}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2255..2261}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=2262..2269}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2269}] ~ ~ ~ summon vex 0 1 0
execute @s[scores={bb=2269}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2270..2279}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2280}] ~ ~ ~ function Minecraft/blockdata/container/loot-005a
execute @s[scores={bb=2281..2289}] ~ ~ ~ setblock 0 0 0 cobblestone
execute @s[scores={bb=2290..2292}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2293..2294}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2295..2297}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2297}] ~ ~ ~ summon witch 0 1 0
execute @s[scores={bb=2297}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2298..2305}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2306}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2307..2308}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2309..2314}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2315}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2316..2318}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=2319}] ~ ~ ~ setblock 0 0 0 log 3
execute @s[scores={bb=2320..2322}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2323..2334}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2335..2336}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2337..2338}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2339}] ~ ~ ~ function Minecraft/blockdata/container/loot-005a
execute @s[scores={bb=2340..2347}] ~ ~ ~ setblock 0 0 0 mossy_cobblestone
execute @s[scores={bb=2348..2349}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2350..2352}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2353}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2354..2356}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2357}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2358..2359}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2360..2361}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2362}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2363}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2364}] ~ ~ ~ function Minecraft/blockdata/container/loot-005d
execute @s[scores={bb=2365}] ~ ~ ~ scoreboard players set @s ss 60
execute @s[scores={bb=2365}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=2365}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9