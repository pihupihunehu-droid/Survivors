## hybrid-tier: #06

particle llama_spit_smoke 0 0.8 0

##execute @s[scores={bd=180}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=360}] ~ ~ ~ scoreboard players set @s sw 0
##execute @s[scores={bd=540}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=720}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={pattern=0,sw=1}] ~ ~ ~ scoreboard players add @s hp 8
execute @s[tag=c0,scores={pattern=0,sw=1}] ~ ~ ~ effect @e[tag=boss] instant_health 1 1 true
execute @s[scores={bb=2366..2383}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2384..2387}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2388..2395}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2396}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=2397..2400}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2401..2411}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2412..2421}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2421}] ~ ~ ~ function Minecraft/entitydata/mob/llama
execute @s[scores={bb=2421}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2422}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2423..2425}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=2426}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2427..2430}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=2431..2433}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2434}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2435}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=2436}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2437}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2438..2440}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2441..2443}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2444..2446}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2447..2448}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=2448}] ~ ~ ~ function Minecraft/entitydata/mob/fox
execute @s[scores={bb=2448}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2449..2453}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2454}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=2455}] ~ ~ ~ function Minecraft/blockdata/container/loot-006a
execute @s[scores={bb=2456}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=2457..2459}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2460..2465}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=2466..2467}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2468..2470}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2471..2473}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2473}] ~ ~ ~ function Minecraft/entitydata/mob/fox
execute @s[scores={bb=2473}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2474..2475}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2476..2477}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=2478..2479}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2480..2482}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2483..2485}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2486..2488}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2489..2498}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2499}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2500}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2500}] ~ ~ ~ function Minecraft/entitydata/mob/villager
execute @s[scores={bb=2500}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2501..2504}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2505..2508}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=2509}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=2510}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=2511}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2512..2514}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2515}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2516}] ~ ~ ~ function Minecraft/blockdata/container/loot-006a
execute @s[scores={bb=2517..2519}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2520..2521}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2522..2525}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2525}] ~ ~ ~ function Minecraft/entitydata/mob/husk
execute @s[scores={bb=2525}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2526}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2527..2529}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2530}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2531..2536}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2537..2539}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2540..2542}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2543..2546}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2547..2548}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2549..2550}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2551..2552}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2552}] ~ ~ ~ function Minecraft/entitydata/mob/pillager
execute @s[scores={bb=2552}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2553..2555}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2556..2560}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=2561..2562}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2563..2565}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2566..2568}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=2569..2571}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=2572}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2573..2576}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2577}] ~ ~ ~ function Minecraft/blockdata/container/loot-006a
execute @s[scores={bb=2577}] ~ ~ ~ function Minecraft/entitydata/mob/wanderingtrader
execute @s[scores={bb=2577}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2578..2581}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=2582..2583}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2584}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2585..2587}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=2588..2590}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2591..2594}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2595..2598}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2599..2600}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2601..2603}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=2604}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2604}] ~ ~ ~ function Minecraft/entitydata/mob/donkey
execute @s[scores={bb=2604}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2605..2610}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2611}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2612..2615}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2616..2619}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2620..2628}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2629..2631}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=2631}] ~ ~ ~ function Minecraft/entitydata/mob/donkey
execute @s[scores={bb=2631}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2632..2633}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=2634..2636}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2637}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2638}] ~ ~ ~ function Minecraft/blockdata/container/loot-006a
execute @s[scores={bb=2639..2641}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2642..2648}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=2649..2651}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2652..2653}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2654}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2655..2656}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2656}] ~ ~ ~ function Minecraft/entitydata/entity-006a
execute @s[scores={bb=2656}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2657..2659}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2660..2662}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2663..2664}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2665..2668}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=2669}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2670..2680}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2681..2683}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2683}] ~ ~ ~ function Minecraft/entitydata/mob/vindicator
execute @s[scores={bb=2683}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2684..2692}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2693..2694}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2695..2698}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2699}] ~ ~ ~ function Minecraft/blockdata/container/loot-006a
execute @s[scores={bb=2700..2705}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2706..2708}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2708}] ~ ~ ~ function Minecraft/entitydata/entity-006a
execute @s[scores={bb=2708}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2709..2712}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2713..2717}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=2718}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2719..2723}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2724..2727}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2728..2735}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2735}] ~ ~ ~ function Minecraft/entitydata/mob/llama
execute @s[scores={bb=2735}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2736..2738}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=2739..2743}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=2744}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2745..2754}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2755}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2755}] ~ ~ ~ tag @s add mr-show
execute @s[scores={bb=2756..2759}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=2760}] ~ ~ ~ function Minecraft/blockdata/container/loot-006b
execute @s[scores={bb=2760}] ~ ~ ~ function Minecraft/entitydata/entity-006a
execute @s[scores={bb=2760}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2760}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=2761..2762}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=2763..2765}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=2766}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2767}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=2768..2770}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2771..2772}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2773..2784}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2785..2786}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2786}] ~ ~ ~ function Minecraft/entitydata/mob/villager
execute @s[scores={bb=2786}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2787..2789}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2790..2799}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2800..2803}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=2804}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2805..2809}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=2810}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2811}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2812..2813}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2813}] ~ ~ ~ function Minecraft/entitydata/entity-006a
execute @s[scores={bb=2813}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2814..2815}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=2816}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2817..2819}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2820}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2821}] ~ ~ ~ function Minecraft/blockdata/container/loot-006c
execute @s[scores={bb=2821}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=2822..2826}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2827..2828}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2829..2831}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2832..2833}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2834..2836}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2837}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2837}] ~ ~ ~ function Minecraft/entitydata/mob/husk
execute @s[scores={bb=2837}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2838..2847}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2848..2852}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=2853}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2854..2860}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=2861..2864}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2864}] ~ ~ ~ function Minecraft/entitydata/entity-006a
execute @s[scores={bb=2864}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2865..2870}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2871..2873}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2874..2877}] ~ ~ ~ function Minecraft/blockdata/block-rsand
execute @s[scores={bb=2878..2881}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=2882}] ~ ~ ~ function Minecraft/blockdata/container/loot-006s
execute @s[scores={bb=2882}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=2883}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=2884..2885}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2886..2887}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2888}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2888}] ~ ~ ~ function Minecraft/entitydata/mob/pillager
execute @s[scores={bb=2888}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2889..2894}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2895..2899}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2900..2901}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=2902..2904}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2905..2909}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2910..2911}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=2912..2913}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=2914..2915}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2915}] ~ ~ ~ function Minecraft/entitydata/mob/wanderingtrader
execute @s[scores={bb=2915}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2916..2917}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2918}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2919..2920}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2921..2923}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2924}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=2925..2934}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2935}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=2936..2940}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=2941..2942}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=2942}] ~ ~ ~ function Minecraft/entitydata/mob/vindicator
execute @s[scores={bb=2942}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2943}] ~ ~ ~ function Minecraft/blockdata/container/loot-006a
execute @s[scores={bb=2944..2947}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=2948}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 1
execute @s[scores={bb=2949..2952}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=2953}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2954}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=2955}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2956..2962}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=2963}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2964..2965}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=2966..2967}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2967}] ~ ~ ~ function Minecraft/entitydata/mob/husk
execute @s[scores={bb=2967}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2968..2970}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 4
execute @s[scores={bb=2971..2975}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=2976}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2977}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2978}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=2979..2987}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=2988}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=2989..2993}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=2994}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2994}] ~ ~ ~ function Minecraft/entitydata/mob/pillager
execute @s[scores={bb=2994}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=2995..2996}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=2997}] ~ ~ ~ setblock 0 0 0 log2
execute @s[scores={bb=2998}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay
execute @s[scores={bb=2999..3000}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=3001..3003}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 8
execute @s[scores={bb=3004}] ~ ~ ~ function Minecraft/blockdata/container/loot-006a
execute @s[scores={bb=3005}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=3006..3009}] ~ ~ ~ setblock 0 0 0 hardened_clay
execute @s[scores={bb=3010..3013}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=3014}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=3015..3019}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=3019}] ~ ~ ~ function Minecraft/entitydata/mob/husk
execute @s[scores={bb=3019}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3020}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=3021..3025}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=3026}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=3027..3028}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=3029..3034}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=3035..3037}] ~ ~ ~ setblock 0 0 0 red_sandstone
execute @s[scores={bb=3038}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=3039..3043}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=3044..3045}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=3046}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=3047..3053}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=3054..3057}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=3058..3063}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=3064}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=3065}] ~ ~ ~ function Minecraft/blockdata/container/loot-006b
execute @s[scores={bb=3065}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=3066..3070}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=3071..3073}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=3074..3075}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=3076..3078}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 14
execute @s[scores={bb=3079..3080}] ~ ~ ~ setblock 0 0 0 stained_hardened_clay 12
execute @s[scores={bb=3081..3082}] ~ ~ ~ setblock 0 0 0 sandstone
execute @s[scores={bb=3083..3087}] ~ ~ ~ function Minecraft/blockdata/block-006a
execute @s[scores={bb=3088}] ~ ~ ~ function Minecraft/blockdata/container/loot-006d
execute @s[scores={bb=3089}] ~ ~ ~ scoreboard players set @s ss 70
execute @s[scores={bb=3089}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=3089}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9