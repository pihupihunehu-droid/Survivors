
execute @s[scores={bd=81}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=162}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=243}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=324}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=405}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=486}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=567}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=648}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[scores={bd=729}] ~ ~ ~ scoreboard players set @s sw 0
execute @s[tag=c0,scores={pattern=0,sw=1}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[scores={pattern=0,sw=1}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={bb=3927..3941}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=3942..3943}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=3944..3947}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=3948..3952}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=3953..3954}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=3955..3956}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=3957..3958}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=3959}] ~ ~ ~ setblock 0 0 0 beehive
execute @s[scores={bb=3960}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=3961}] ~ ~ ~ setblock 0 0 0 honey_block
execute @s[scores={bb=3962}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=3963}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=3964}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=3965}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=3966}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=3967}] ~ ~ ~ setblock 0 0 0 slime
execute @s[scores={bb=3968..3975}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=3975}] ~ ~ ~ function Minecraft/entitydata/mob/bee
execute @s[scores={bb=3975}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3976..3994}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=3995..4002}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4003}] ~ ~ ~ function Minecraft/blockdata/container/tier1
execute @s[scores={bb=4003}] ~ ~ ~ function Minecraft/entitydata/mob/bee
execute @s[scores={bb=4003}] ~ ~ ~ function Minecraft/audiodata/sound-01a
#execute @s[scores={bb=4003}] ~ ~ ~ playsound item.trident.thunder @a[r=35] 0 1 0 0.6 0.5 0.6
execute @s[scores={bb=4004..4025}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4026..4027}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4028..4030}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4030}] ~ ~ ~ function Minecraft/entitydata/mob/cat
execute @s[scores={bb=4030}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4031..4056}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4057..4059}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4059}] ~ ~ ~ function Minecraft/entitydata/mob/slime
execute @s[scores={bb=4059}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4060}] ~ ~ ~ function Minecraft/blockdata/container/loot-008a
execute @s[scores={bb=4061}] ~ ~ ~ setblock 0 0 0 bee_nest
execute @s[scores={bb=4062..4083}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4084..4086}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4086}] ~ ~ ~ function Minecraft/entitydata/mob/mule
execute @s[scores={bb=4086}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4087..4101}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4102..4105}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4106..4107}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4108}] ~ ~ ~ setblock 0 0 0 slime
execute @s[scores={bb=4109}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=4110}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=4111}] ~ ~ ~ setblock 0 0 0 honey_block
execute @s[scores={bb=4112..4115}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4115}] ~ ~ ~ function Minecraft/entitydata/mob/skeletonhorse
execute @s[scores={bb=4115}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4116}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4117}] ~ ~ ~ function Minecraft/blockdata/container/loot-008b
execute @s[scores={bb=4117}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=4118..4138}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4139}] ~ ~ ~ setblock 0 0 0 slime
execute @s[scores={bb=4140}] ~ ~ ~ setblock 0 0 0 honey_block
execute @s[scores={bb=4141}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4141}] ~ ~ ~ function Minecraft/entitydata/mob/phantom
execute @s[scores={bb=4141}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4142..4143}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4144..4159}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4160..4165}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4166}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4167..4168}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4169..4170}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4170}] ~ ~ ~ function Minecraft/entitydata/mob/zombiehorse
execute @s[scores={bb=4170}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4171}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4172}] ~ ~ ~ setblock 0 0 0 slime
execute @s[scores={bb=4173}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4174}] ~ ~ ~ function Minecraft/blockdata/container/loot-008a
execute @s[scores={bb=4175..4176}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4177..4182}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4183}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4184..4189}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4190}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=4191}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4192..4197}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4197}] ~ ~ ~ function Minecraft/entitydata/mob/bee
execute @s[scores={bb=4197}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4198..4212}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4213..4226}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4226}] ~ ~ ~ function Minecraft/entitydata/entity-008a
execute @s[scores={bb=4226}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4227..4230}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4231}] ~ ~ ~ function Minecraft/blockdata/container/loot-008a
execute @s[scores={bb=4232..4234}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4235}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4236}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4237}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=4238}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4239..4241}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4242..4253}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4253}] ~ ~ ~ function Minecraft/entitydata/mob/bee
execute @s[scores={bb=4253}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4254..4270}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4271..4282}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4282}] ~ ~ ~ function Minecraft/entitydata/mob/cat
execute @s[scores={bb=4282}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4283..4287}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4288}] ~ ~ ~ function Minecraft/blockdata/container/loot-008b
execute @s[scores={bb=4288}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=4289}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4290..4307}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4308}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4308}] ~ ~ ~ function Minecraft/entitydata/entity-008a
execute @s[scores={bb=4308}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4309..4318}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4319..4320}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=4321}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4321}] ~ ~ ~ tag @s add mr-show
execute @s[scores={bb=4322..4323}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4324}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=4325}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4326..4327}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=4328..4334}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4335..4337}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4337}] ~ ~ ~ function Minecraft/entitydata/mob/slime
execute @s[scores={bb=4337}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4338..4344}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4345}] ~ ~ ~ function Minecraft/blockdata/container/tier0
#execute @s[scores={bb=4345}] ~ ~ ~ playsound note.pling @a[r=35] 0 1 0 1 0.5 1
execute @s[scores={bb=4346}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4347}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4348}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=4349..4353}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4354..4356}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4357}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4358}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4359..4361}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4362}] ~ ~ ~ setblock 0 0 0 honey_block
execute @s[scores={bb=4363}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4363}] ~ ~ ~ function Minecraft/entitydata/entity-008a
execute @s[scores={bb=4363}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4364..4366}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4367}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4368}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4369}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4370..4371}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4372..4374}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=4375..4376}] ~ ~ ~ function Minecraft/blockdata/block-008a
execute @s[scores={bb=4377}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4378..4379}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=4380..4388}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4389..4390}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4391}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=4392}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4392}] ~ ~ ~ function Minecraft/entitydata/mob/mule
execute @s[scores={bb=4392}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4393..4394}] ~ ~ ~ setblock 0 0 0 honeycomb_block
execute @s[scores={bb=4395..4401}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4402}] ~ ~ ~ function Minecraft/blockdata/container/loot-008a
execute @s[scores={bb=4403..4419}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4419}] ~ ~ ~ function Minecraft/entitydata/entity-008a
execute @s[scores={bb=4419}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4420..4423}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4424..4430}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4431..4439}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4440..4445}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4446}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4447..4448}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4448}] ~ ~ ~ function Minecraft/entitydata/mob/phantom
execute @s[scores={bb=4448}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4449..4458}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4459}] ~ ~ ~ function Minecraft/blockdata/container/loot-008b
execute @s[scores={bb=4459}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=4460..4474}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4474}] ~ ~ ~ function Minecraft/entitydata/entity-008a
execute @s[scores={bb=4474}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4475..4477}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4478..4484}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4485}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4486..4491}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4492}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4493..4503}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4503}] ~ ~ ~ function Minecraft/entitydata/mob/bee
execute @s[scores={bb=4503}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4504..4515}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4516}] ~ ~ ~ function Minecraft/blockdata/container/loot-008a
execute @s[scores={bb=4517..4519}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4520}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4521..4530}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4530}] ~ ~ ~ function Minecraft/entitydata/mob/cat
execute @s[scores={bb=4530}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4531..4532}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4533..4539}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4540..4541}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4542}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4543..4559}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4559}] ~ ~ ~ function Minecraft/entitydata/mob/slime
execute @s[scores={bb=4559}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4560..4562}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4563}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4564..4565}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4566..4567}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4568}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4569..4570}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4571..4572}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4573}] ~ ~ ~ function Minecraft/blockdata/container/loot-008a
execute @s[scores={bb=4574..4582}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4583..4586}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4586}] ~ ~ ~ function Minecraft/entitydata/mob/slime
execute @s[scores={bb=4586}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4587..4602}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4603..4608}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4609}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=4610}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=4611}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=4612..4613}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4614..4629}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4630}] ~ ~ ~ function Minecraft/blockdata/container/loot-008b
execute @s[scores={bb=4630}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=4631..4640}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4641..4642}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4643..4655}] ~ ~ ~ setblock 0 0 0 quartz_block
execute @s[scores={bb=4656}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4657}] ~ ~ ~ function Minecraft/blockdata/container/loot-008c
execute @s[scores={bb=4658}] ~ ~ ~ scoreboard players set @s ss 90
execute @s[scores={bb=4658}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
#execute @s[scores={bb=4658}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9