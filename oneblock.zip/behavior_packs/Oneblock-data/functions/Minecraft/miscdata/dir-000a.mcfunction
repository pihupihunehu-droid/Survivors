
## This map based of Oneblock by IJAMinecraft
## This content was created by him, you can visit his site at the link here: ijaminecraft.com or visit his own Youtube: IJAMinecraft
## One Block version 2.4.0 McLogic By CuBeyzM ( It is forbidden to change or steal our content without the knowledge of the manager or content owner, to get permission or information you can contact us via email : cbz.official.id@gmail.com )
## My YouTube: CubeyzM

particle minecraft:llama_spit_smoke 0 0.8 0

#execute @e[tag=system31,tag=system114] ~ ~ ~ say sys114call
#execute @e[type=system:initialize,tag=!system31,tag=!system114] ~ ~ ~ say sys31call
execute @e[tag=system31,tag=system114] ~ ~ ~ scoreboard players set @e[tag=s,scores={bb=47}] r1 100
execute @e[type=system:initialize,tag=!system31,tag=!system114] ~ ~ ~ scoreboard players set @e[tag=s,scores={bb=47}] r1 100
execute @s[tag=c0,scores={pattern=0..2}] ~ ~ ~ effect @e[tag=boss] instant_health 1 2 true
execute @s[scores={pattern=0..2}] ~ ~ ~ scoreboard players add @s hp 16
execute @s[tag=c0,scores={pattern=3}] ~ ~ ~ effect @e[tag=boss] instant_health 1 3 true
execute @s[scores={pattern=3}] ~ ~ ~ scoreboard players add @s hp 32
execute @s[scores={bb=1..3}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=1}] ~ ~ ~ playsound random.levelup @a[x=0,y=0,z=0,r=10] 0 1 0
execute @s[scores={bb=2}] ~ ~ ~ playsound random.bow @a[x=0,y=0,z=0,r=10] 0 1 0
execute @s[scores={bb=3}] ~ ~ ~ playsound random.orb @a[x=0,y=0,z=0,r=10] 0 1 0
execute @s[scores={bb=4..5}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=4}] ~ ~ ~ weather clear
execute @s[scores={bb=4}] ~ ~ ~ playsound block.barrel.open @a[x=0,y=0,z=0,r=10] 0 1 0
execute @s[scores={bb=5}] ~ ~ ~ playsound item.book.page_turn @a[x=0,y=0,z=0,r=10] 0 1 0
execute @s[scores={bb=5}] ~ ~ ~ titleraw @a[x=0,y=0,z=0,r=6] actionbar {"rawtext":[{"translate":"mojang.text.render6"}]}
execute @s[scores={bb=6}] ~ ~ ~ function Minecraft/blockdata/container/loot-000a
execute @s[scores={bb=6}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=7}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=8..13}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=14}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=15}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=16..18}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=18}] ~ ~ ~ function Minecraft/entitydata/entity-000a
execute @s[scores={bb=18}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=19..21}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=22}] ~ ~ ~ function Minecraft/blockdata/container/loot-000a
execute @s[scores={bb=23}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=24..26}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=27..28}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=29..30}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=31}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=32}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=33}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=34}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=35}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=36}] ~ ~ ~ function Minecraft/blockdata/container/loot-000b
execute @s[scores={bb=36}] ~ ~ ~ playsound bucket.fill_water @a[r=6] 0 1 0 0.8 0.9
execute @s[scores={bb=37}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=38}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=39}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=40..42}] ~ ~ ~ function Minecraft/blockdata/block-gravel
execute @s[scores={bb=43}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=44..45}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=45}] ~ ~ ~ summon system:initialize 0 -61 0
execute @s[scores={bb=45}] ~ ~ ~ structure load mystructure:cmd1 40 -60 40
execute @s[scores={bb=45}] ~ ~ ~ setblock 40 -60 41 redstone_block
execute @s[scores={bb=46}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=47}] ~ ~ ~ kill @e[type=system:initialize]
execute @s[scores={bb=47}] ~ ~ ~ function Minecraft/blockdata/container/loot-000c
execute @s[scores={bb=47}] ~ ~ ~ playsound item.spyglass.stop_using @a[r=10] 0 1.4 0
execute @s[scores={bb=47}] ~ ~ ~ titleraw @a[r=6] actionbar {"rawtext":[{"translate":"mojang.text.render14"}]}
execute @s[scores={bb=48}] ~ ~ ~ scoreboard players set @s ss 10
execute @s[scores={bb=48}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=48}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9