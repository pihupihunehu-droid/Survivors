## hybrid-tier: #11rc

particle minecraft:llama_spit_smoke 0 0.8 0

execute @s[scores={bc=1..11}] ~ ~ ~ function Minecraft/entitydata/entity-auto
execute @s[scores={bc=1..11}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bc=0..395}] ~ ~ ~ function Minecraft/blockdata/block-010a
execute @s[scores={bc=100}] ~ ~ ~ tag @s add mr-show
execute @s[scores={bc=396..397}] ~ ~ ~ function Minecraft/blockdata/container/loot-111a
execute @s[scores={bc=398}] ~ ~ ~ function Minecraft/blockdata/container/loot-111a
execute @s[scores={bc=399}] ~ ~ ~ function Minecraft/blockdata/container/loot-111a
execute @s[scores={bc=400}] ~ ~ ~ function Minecraft/blockdata/container/loot-111a

##absc