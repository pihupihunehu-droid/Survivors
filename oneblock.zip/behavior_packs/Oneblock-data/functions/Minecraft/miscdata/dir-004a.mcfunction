## hybrid-tier: #04

particle minecraft:llama_spit_smoke 0 0.8 0

execute @s[tag=c0,scores={pattern=0..1}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=0..1}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={pattern=2,bd=539..}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=2,bd=539..}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[scores={bb=1156..1168}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1169..1170}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1171..1178}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1179..1184}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1185}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1186}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1187}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1188}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1189}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1190}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1191..1192}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1193..1197}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1198}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1199..1206}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1206}] ~ ~ ~ summon turtle 0 1 0
execute @s[scores={bb=1206}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1207}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1208}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1209}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1210}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=1211}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1212}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1213}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1214..1221}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1222}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1223..1224}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1225..1229}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1229}] ~ ~ ~ summon squid 0 1 0
execute @s[scores={bb=1229}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1230..1232}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1233..1239}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1240}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1241}] ~ ~ ~ function Minecraft/blockdata/container/loot-004a
execute @s[scores={bb=1241}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=1242}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1243}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1244}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1245}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1246}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1247}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1248}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1249}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1250}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1250}] ~ ~ ~ summon drowned 0 1 0
execute @s[scores={bb=1250}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1251..1252}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1253}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1254..1259}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1260}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1261}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1262}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1263}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1264}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1265}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1266..1273}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1273}] ~ ~ ~ summon salmon 0 1 0
execute @s[scores={bb=1273}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1274..1276}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1277}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1278..1287}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1288}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1289..1295}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1296}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1296}] ~ ~ ~ summon tropicalfish 0 1 0
execute @s[scores={bb=1296}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1297..1298}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1299}] ~ ~ ~ function Minecraft/blockdata/container/loot-004b
execute @s[scores={bb=1300..1306}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1307}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1308..1310}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1311}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1312..1313}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1314..1316}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1316}] ~ ~ ~ summon guardian 0 1 0
execute @s[scores={bb=1316}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1317..1321}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1322..1323}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1324}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1325}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1326..1330}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1331..1332}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1333..1338}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1339}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1339}] ~ ~ ~ summon guardian 0 1 0
execute @s[scores={bb=1339}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1340..1344}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1345}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1346}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1347..1356}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1357}] ~ ~ ~ function Minecraft/blockdata/container/loot-004a
execute @s[scores={bb=1358}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1359}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1360}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1360}] ~ ~ ~ summon pufferfish 0 1 0
execute @s[scores={bb=1360}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1361..1367}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1368}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1369}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=1370}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1371..1372}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1373}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1374}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1375}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1376}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1377..1380}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1381..1382}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1383}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1383}] ~ ~ ~ summon cod 0 1 0
execute @s[scores={bb=1383}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1384..1387}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1388}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1389..1395}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1396}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1397}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1398..1405}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1406}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1406}] ~ ~ ~ summon elder_guardian 0 1 0
execute @s[scores={bb=1406}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1407..1408}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1409}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1410}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1411..1414}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1415}] ~ ~ ~ function Minecraft/blockdata/container/loot-004a
execute @s[scores={bb=1416}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1417}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1418}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1419}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1420}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1421}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1422..1423}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1424..1427}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1427}] ~ ~ ~ summon dolphin 0 1 0
execute @s[scores={bb=1427}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1428..1435}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1436}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1437}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1438..1442}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1443..1444}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1445..1446}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=1447..1450}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1450}] ~ ~ ~ function Minecraft/entitydata/entity-004a
execute @s[scores={bb=1450}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1451..1454}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1455}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1456..1463}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1464..1465}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1466}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1467}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1468..1472}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1473}] ~ ~ ~ function Minecraft/blockdata/container/loot-004a
execute @s[scores={bb=1473}] ~ ~ ~ summon turtle 0 1 0
execute @s[scores={bb=1473}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1474..1479}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1479}] ~ ~ ~ tag @s add mr-show
execute @s[scores={bb=1480}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1481}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1482..1488}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1489}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1490}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1491}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1492..1493}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1494}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1494}] ~ ~ ~ function Minecraft/entitydata/entity-004a
execute @s[scores={bb=1494}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1495..1504}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1505..1506}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1507}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1508..1515}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1516..1517}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1517}] ~ ~ ~ summon drowned 0 1 0
execute @s[scores={bb=1517}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1518..1519}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1520..1522}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1523..1530}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1531}] ~ ~ ~ function Minecraft/blockdata/container/loot-004a
execute @s[scores={bb=1532}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1533}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1534}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1535}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1536}] ~ ~ ~ setblock 0 0 0 prismarine
execute @s[scores={bb=1537}] ~ ~ ~ setblock 0 0 0 coral_block
execute @s[scores={bb=1538}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1538}] ~ ~ ~ function Minecraft/entitydata/entity-004a
execute @s[scores={bb=1538}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1539..1540}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1541}] ~ ~ ~ setblock 0 0 0 gold_ore
execute @s[scores={bb=1542}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1543..1544}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1545..1549}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1550}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1551..1552}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1553}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1554}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1555..1561}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1561}] ~ ~ ~ summon salmon 0 1 0
execute @s[scores={bb=1561}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1562..1563}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=1564..1568}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1569..1576}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1577}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1578..1582}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1583}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1584}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1584}] ~ ~ ~ function Minecraft/entitydata/entity-004a
execute @s[scores={bb=1584}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1585..1586}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1587..1588}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1589}] ~ ~ ~ function Minecraft/blockdata/container/loot-004a
execute @s[scores={bb=1590..1595}] ~ ~ ~ function Minecraft/blockdata/block-sand
execute @s[scores={bb=1596}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1597..1601}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1602}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1603..1604}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1605}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1605}] ~ ~ ~ summon tropicalfish 0 1 0
execute @s[scores={bb=1605}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1606}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1607}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1608..1613}] ~ ~ ~ setblock 0 0 0 prismarine 2
execute @s[scores={bb=1614}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1615}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1616..1619}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1620..1621}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1622}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1623}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1624}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1625..1628}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1628}] ~ ~ ~ summon guardian 0 1 0
execute @s[scores={bb=1628}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1629}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1630}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1631..1632}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=1633}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1634..1635}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=1636}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1637..1638}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1639}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1640}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1641}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1642}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1643..1646}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1647}] ~ ~ ~ function Minecraft/blockdata/container/loot-004a
execute @s[scores={bb=1648..1649}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1649}] ~ ~ ~ summon cod 0 1 0
execute @s[scores={bb=1649}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1650}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1651}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1652}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1653..1657}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1658}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1659}] ~ ~ ~ setblock 0 0 0 coral_block 1
execute @s[scores={bb=1660}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1661..1663}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1664}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1665}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1666}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1667..1668}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1669..1672}] ~ ~ ~ function Minecraft/blockdata/block-004a
execute @s[scores={bb=1672}] ~ ~ ~ summon elder_guardian 0 1 0
execute @s[scores={bb=1672}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=1673..1677}] ~ ~ ~ setblock 0 0 0 prismarine 1
execute @s[scores={bb=1678}] ~ ~ ~ setblock 0 0 0 coral_block 2
execute @s[scores={bb=1679}] ~ ~ ~ setblock 0 0 0 log2 1
execute @s[scores={bb=1680}] ~ ~ ~ setblock 0 0 0 coral_block 3
execute @s[scores={bb=1681}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1682..1683}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=1684..1685}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1686}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1687..1688}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1689}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=1690}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=1691..1692}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1693}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1694..1695}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1696}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1697}] ~ ~ ~ setblock 0 0 0 stone 3
execute @s[scores={bb=1698..1699}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1700}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=1701}] ~ ~ ~ setblock 0 0 0 sponge
execute @s[scores={bb=1702..1703}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=1704}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1705}] ~ ~ ~ function Minecraft/blockdata/container/loot-004s
execute @s[scores={bb=1706}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=1707..1708}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1709..1710}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1711..1712}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=1713}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1714}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=1715}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1716..1717}] ~ ~ ~ setblock 0 0 0 sealantern
execute @s[scores={bb=1718}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1719}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1720..1721}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1722..1723}] ~ ~ ~ setblock 0 0 0 coral_block 4
execute @s[scores={bb=1724}] ~ ~ ~ setblock 0 0 0 stone
execute @s[scores={bb=1725}] ~ ~ ~ function Minecraft/blockdata/container/loot-004c
execute @s[scores={bb=1726}] ~ ~ ~ scoreboard players set @s ss 50
execute @s[scores={bb=1726}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=1726}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9