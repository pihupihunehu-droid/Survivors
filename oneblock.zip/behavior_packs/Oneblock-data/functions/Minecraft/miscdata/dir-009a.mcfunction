#respawn_anchor.charge=minecraft:block.respawn_anchor.charge
execute @s[scores={pattern=0}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={pattern=0}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=1,bd=1..100}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={pattern=1,bd=1..100}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=1,bd=250..350}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={pattern=1,bd=250..350}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={pattern=1,bd=500..600}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={pattern=1,bd=500..600}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[scores={bb=4659..4671}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=4672..4677}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4678..4685}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=4686..4695}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=4696..4700}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=4701}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=4702..4703}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4704}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4705}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=4706..4707}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=4708..4710}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=4711..4714}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=4714}] ~ ~ ~ function Minecraft/entitydata/mob/silverfish
execute @s[scores={bb=4714}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4715..4718}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=4719..4724}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=4725..4734}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=4735..4740}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=4741}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4742..4744}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=4744}] ~ ~ ~ function Minecraft/entitydata/mob/creeper
execute @s[scores={bb=4744}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4745}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=4746}] ~ ~ ~ function Minecraft/blockdata/container/tier2
execute @s[scores={bb=4746}] ~ ~ ~ playsound respawn_anchor.charge @a[r=35] 0 1 0 1 0.5 1
execute @s[scores={bb=4747..4749}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=4750..4753}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=4754}] ~ ~ ~ setblock 0 0 0 lit_pumpkin
execute @s[scores={bb=4755..4769}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4770..4771}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=4771}] ~ ~ ~ function Minecraft/entitydata/mob/cavespider
execute @s[scores={bb=4771}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4772}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=4773..4774}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=4775..4780}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=4781}] ~ ~ ~ setblock 0 0 0 lit_pumpkin
execute @s[scores={bb=4782}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=4783..4797}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4798}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4799..4800}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=4801}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4801}] ~ ~ ~ function Minecraft/entitydata/mob/skeletonhorse
execute @s[scores={bb=4801}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4802..4807}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4808}] ~ ~ ~ function Minecraft/blockdata/container/loot-009a
execute @s[scores={bb=4809..4811}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4812}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4813..4823}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=4824}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4825..4826}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=4827}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=4828..4829}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4829}] ~ ~ ~ function Minecraft/entitydata/mob/creeper
execute @s[scores={bb=4829}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4830..4844}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4845}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4846}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=4847..4859}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4859}] ~ ~ ~ function Minecraft/entitydata/mob/evoker
execute @s[scores={bb=4859}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4860..4863}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4864}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=4865}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4866..4868}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=4869}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4870}] ~ ~ ~ function Minecraft/blockdata/container/loot-009b
execute @s[scores={bb=4870}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=4871..4885}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4886}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4886}] ~ ~ ~ function Minecraft/entitydata/mob/skeletonhorse
execute @s[scores={bb=4886}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4887..4895}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=4896}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=4897}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4898..4899}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=4900..4909}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=4910..4911}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=4912}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=4913..4916}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=4916}] ~ ~ ~ function Minecraft/entitydata/mob/skeletonhorse
execute @s[scores={bb=4916}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4917..4931}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=4932}] ~ ~ ~ function Minecraft/blockdata/container/tier2
execute @s[scores={bb=4932}] ~ ~ ~ playsound respawn_anchor.charge @a[r=35] 0 1 0 1 0.5 1
execute @s[scores={bb=4933}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=4934..4936}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4937..4943}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=4943}] ~ ~ ~ function Minecraft/entitydata/entity-009a
execute @s[scores={bb=4943}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4944..4945}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=4946..4952}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=4953..4954}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=4955}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=4956..4973}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=4973}] ~ ~ ~ function Minecraft/entitydata/mob/silverfish
execute @s[scores={bb=4973}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=4974..4975}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=4976}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=4977}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=4978..4986}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=4987..4988}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=4989..4993}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=4994}] ~ ~ ~ function Minecraft/blockdata/container/loot-009rare
execute @s[scores={bb=4994}] ~ ~ ~ playsound item.trident.thunder @a[r=35] 0 1 0 0.6 0.5 0.6
execute @s[scores={bb=4995}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=4996..4997}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=4998}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=4999..5000}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=5000}] ~ ~ ~ function Minecraft/entitydata/entity-009a
execute @s[scores={bb=5000}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5001..5015}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=5016..5028}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5029}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=5030}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5030}] ~ ~ ~ function Minecraft/entitydata/mob/cavespider
execute @s[scores={bb=5030}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5031..5038}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=5039}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5040}] ~ ~ ~ setblock 0 0 0 lit_pumpkin
execute @s[scores={bb=5041}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=5042}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5043..5055}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5056}] ~ ~ ~ function Minecraft/blockdata/container/loot-009a
execute @s[scores={bb=5057..5058}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5058}] ~ ~ ~ function Minecraft/entitydata/entity-009a
execute @s[scores={bb=5058}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5059}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=5060..5061}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5062..5063}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=5064..5069}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=5070}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=5071}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=5072}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=5073..5082}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5082}] ~ ~ ~ tag @s add mr-show
execute @s[scores={bb=5083..5084}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5085..5088}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5088}] ~ ~ ~ function Minecraft/entitydata/mob/skeletonhorse
execute @s[scores={bb=5088}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5089..5094}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5095..5106}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=5107..5114}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=5115}] ~ ~ ~ setblock 0 0 0 lapis_ore
execute @s[scores={bb=5116}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5117}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=5118}] ~ ~ ~ function Minecraft/blockdata/container/loot-009b
execute @s[scores={bb=5118}] ~ ~ ~ function Minecraft/entitydata/entity-009a
execute @s[scores={bb=5118}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5118}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=5119..5120}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5121}] ~ ~ ~ setblock 0 0 0 emerald_ore
execute @s[scores={bb=5122}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5123..5130}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=5131}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=5132..5133}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5134..5135}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=5136..5142}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=5143..5145}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=5145}] ~ ~ ~ function Minecraft/entitydata/mob/creeper
execute @s[scores={bb=5145}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5146..5154}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=5155..5156}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5157..5167}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=5168..5171}] ~ ~ ~ setblock 0 0 0 stonebrick 1
execute @s[scores={bb=5172..5175}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5175}] ~ ~ ~ function Minecraft/entitydata/entity-009a
execute @s[scores={bb=5175}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5176}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5177..5179}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5180}] ~ ~ ~ function Minecraft/blockdata/container/loot-009a
execute @s[scores={bb=5181}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5182}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5183}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5184..5186}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5187..5188}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=5189..5191}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5192}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5193}] ~ ~ ~ setblock 0 0 0 diamond_ore
execute @s[scores={bb=5194}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5195..5200}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5201..5202}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5203}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=5203}] ~ ~ ~ function Minecraft/entitydata/mob/evoker
execute @s[scores={bb=5203}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5204..5205}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=5206..5207}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=5208..5211}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=5212..5230}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5231}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5232..5233}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5233}] ~ ~ ~ function Minecraft/entitydata/entity-009a
execute @s[scores={bb=5233}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5234..5237}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5238..5241}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5242}] ~ ~ ~ function Minecraft/blockdata/container/loot-009a
execute @s[scores={bb=5243..5244}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5245..5251}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=5252..5261}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5261}] ~ ~ ~ function Minecraft/entitydata/mob/skeletonhorse
execute @s[scores={bb=5261}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5262..5271}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5272..5273}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5274..5280}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=5281..5286}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5287}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5288..5289}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5290..5291}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5291}] ~ ~ ~ function Minecraft/entitydata/mob/skeletonhorse
execute @s[scores={bb=5291}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5292..5301}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5302..5303}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5304}] ~ ~ ~ function Minecraft/blockdata/container/tier2
execute @s[scores={bb=5304}] ~ ~ ~ playsound respawn_anchor.charge @a[r=35] 0 1 0 1 0.5 1
execute @s[scores={bb=5305}] ~ ~ ~ setblock 0 0 0 redstone_ore
execute @s[scores={bb=5306}] ~ ~ ~ setblock 0 0 0 coal_ore
execute @s[scores={bb=5307..5316}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5317..5318}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5318}] ~ ~ ~ function Minecraft/entitydata/mob/silverfish
execute @s[scores={bb=5318}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5319}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5320..5327}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5328..5330}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=5331..5335}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5336..5347}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5348}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5348}] ~ ~ ~ function Minecraft/entitydata/mob/cavespider
execute @s[scores={bb=5348}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5349}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5350..5351}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5352..5358}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=5359..5361}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=5362..5365}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=5366}] ~ ~ ~ function Minecraft/blockdata/container/loot-009a
execute @s[scores={bb=5367..5368}] ~ ~ ~ setblock 0 0 0 mycelium
execute @s[scores={bb=5369..5374}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5375}] ~ ~ ~ setblock 0 0 0 stonebrick
execute @s[scores={bb=5376}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=5376}] ~ ~ ~ function Minecraft/entitydata/mob/cavespider
execute @s[scores={bb=5376}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=5377..5378}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=5379}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5380}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5381}] ~ ~ ~ setblock 0 0 0 bone_block
execute @s[scores={bb=5382..5391}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5392}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5393}] ~ ~ ~ setblock 0 0 0 stonebrick 2
execute @s[scores={bb=5394}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5395..5401}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=5402..5409}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5410..5411}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5412}] ~ ~ ~ setblock 0 0 0 gravel
execute @s[scores={bb=5413..5414}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5415}] ~ ~ ~ function Minecraft/blockdata/block-009a
execute @s[scores={bb=5416}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5417..5424}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5425..5426}] ~ ~ ~ setblock 0 0 0 iron_ore
execute @s[scores={bb=5427}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5428}] ~ ~ ~ function Minecraft/blockdata/container/loot-009b
execute @s[scores={bb=5428}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=5429..5434}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5435}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5436..5439}] ~ ~ ~ setblock 0 0 0 stonebrick 3
execute @s[scores={bb=5440}] ~ ~ ~ setblock 0 0 0 log 5
execute @s[scores={bb=5441..5444}] ~ ~ ~ function Minecraft/blockdata/block-concretpowder
execute @s[scores={bb=5445}] ~ ~ ~ function Minecraft/blockdata/container/loot-009c
execute @s[scores={bb=5446}] ~ ~ ~ scoreboard players set @s ss 100
execute @s[scores={bb=5446}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=5446}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9