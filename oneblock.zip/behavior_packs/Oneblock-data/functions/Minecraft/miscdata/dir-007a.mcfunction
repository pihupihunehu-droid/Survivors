## hybrid-tier: #07
##rev=chestodd:sound:3

scoreboard players set size pattern1 32
scoreboard players operation @s pattern1 = @s bd
scoreboard players operation @s pattern1 %= size pattern1
execute @s[scores={pattern=0}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[tag=c0,scores={pattern=0}] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
execute @s[tag=c0,scores={pattern1=0}] ~ ~ ~ scoreboard players add @s r2 3
execute @s[scores={pattern1=0}] ~ ~ ~ scoreboard players add @s hp 4
execute @s[scores={bb=3090..3106}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3107..3110}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3111..3115}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3116..3119}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3120..3121}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3122..3128}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3129..3136}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3137..3139}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3140..3141}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3142..3143}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3144..3146}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3146}] ~ ~ ~ function Minecraft/entitydata/mob/piglin
execute @s[scores={bb=3146}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3147..3148}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3149}] ~ ~ ~ setblock 0 0 0 ancient_debris
execute @s[scores={bb=3150}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3151..3155}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3156..3158}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3159..3163}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3164..3166}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3167}] ~ ~ ~ setblock 0 0 0 ancient_debris
execute @s[scores={bb=3168..3173}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3174..3177}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3178}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3178}] ~ ~ ~ function Minecraft/entitydata/mob/magmacube
execute @s[scores={bb=3178}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3179}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3180}] ~ ~ ~ function Minecraft/blockdata/container/loot-007b
execute @s[scores={bb=3180}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=3181}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3182}] ~ ~ ~ setblock 0 0 0 crying_obsidian
execute @s[scores={bb=3183..3189}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3190..3194}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3195}] ~ ~ ~ setblock 0 0 0 crying_obsidian
execute @s[scores={bb=3196..3197}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3198}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3199..3201}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3202..3205}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3206..3207}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3207}] ~ ~ ~ function Minecraft/entitydata/mob/hoglin
execute @s[scores={bb=3207}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3208..3209}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3210..3211}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3212..3213}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3214..3221}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3222..3229}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3230}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3231..3235}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3236}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3237..3239}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3239}] ~ ~ ~ function Minecraft/entitydata/mob/blaze
execute @s[scores={bb=3239}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3240..3241}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3242..3245}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3246}] ~ ~ ~ function Minecraft/blockdata/container/loot-007c
execute @s[scores={bb=3246}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=3247..3249}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3250}] ~ ~ ~ setblock 0 0 0 crying_obsidian
execute @s[scores={bb=3251..3253}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3254..3257}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3258}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3259..3263}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3264..3266}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3267..3268}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3268}] ~ ~ ~ function Minecraft/entitydata/mob/strider
execute @s[scores={bb=3268}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3269}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3270..3273}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3274..3277}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3278}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3279..3281}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3282..3287}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3288..3289}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3290..3292}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3293..3300}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3300}] ~ ~ ~ function Minecraft/entitydata/mob/witherskeleton
execute @s[scores={bb=3300}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3301..3303}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3304..3309}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3310..3311}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3312}] ~ ~ ~ function Minecraft/blockdata/container/loot-007a
execute @s[scores={bb=3313..3320}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3321..3324}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3325..3330}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3330}] ~ ~ ~ function Minecraft/entitydata/mob/ghast
execute @s[scores={bb=3330}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3331..3335}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3336..3337}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3338}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3339..3342}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3343..3348}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3349..3351}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3352..3355}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3356..3358}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3359..3362}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3362}] ~ ~ ~ function Minecraft/entitydata/mob/piglin
execute @s[scores={bb=3362}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3363..3366}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3367..3368}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3369..3370}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3371}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3372..3374}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3375}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3376}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3377}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3378}] ~ ~ ~ function Minecraft/blockdata/container/loot-007a
execute @s[scores={bb=3379..3384}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3385..3387}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3388..3390}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3391}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3392}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3392}] ~ ~ ~ function Minecraft/entitydata/entity-007a
execute @s[scores={bb=3392}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3393..3395}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3396}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3397..3398}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3399..3401}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3402..3404}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3405}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3406}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3407..3409}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3410..3412}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3413..3416}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3417..3419}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3420..3423}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3424}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3424}] ~ ~ ~ function Minecraft/entitydata/mob/magmacube
execute @s[scores={bb=3424}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3425..3428}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3429..3434}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3435}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3436..3443}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3444}] ~ ~ ~ function Minecraft/blockdata/container/loot-007c
execute @s[scores={bb=3444}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=3445..3448}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3449..3452}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3453}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3453}] ~ ~ ~ function Minecraft/entitydata/entity-007a
execute @s[scores={bb=3453}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3454..3456}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3457..3458}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3459}] ~ ~ ~ setblock 0 0 0 ancient_debris
execute @s[scores={bb=3460..3461}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3462}] ~ ~ ~ setblock 0 0 0 ancient_debris
execute @s[scores={bb=3463..3474}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3475..3476}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3477..3478}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3479..3485}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3485}] ~ ~ ~ function Minecraft/entitydata/mob/hoglin
execute @s[scores={bb=3485}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3486}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3487..3489}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3490..3500}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3501..3503}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3504..3509}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3510}] ~ ~ ~ function Minecraft/blockdata/container/loot-007a
execute @s[scores={bb=3511..3515}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3515}] ~ ~ ~ function Minecraft/entitydata/entity-007a
execute @s[scores={bb=3515}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3516..3523}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3524}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3524}] ~ ~ ~ tag @s add mr-show
execute @s[scores={bb=3525..3529}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3530..3531}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3532..3533}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3534..3538}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3539..3542}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3543..3546}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3547}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3547}] ~ ~ ~ function Minecraft/entitydata/mob/blaze
execute @s[scores={bb=3547}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3548..3550}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3551..3553}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3554}] ~ ~ ~ setblock 0 0 0 warped_wart_block
execute @s[scores={bb=3555..3559}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3560..3562}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3563..3564}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3565}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3566..3571}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3572..3575}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3576}] ~ ~ ~ function Minecraft/blockdata/container/loot-007a
execute @s[scores={bb=3577}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3577}] ~ ~ ~ function Minecraft/entitydata/entity-007a
execute @s[scores={bb=3577}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3578..3582}] ~ ~ ~ setblock 0 0 0 netherrack
execute @s[scores={bb=3583..3584}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3585..3596}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3597..3598}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3599}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3600..3602}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3603..3606}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3607}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3608..3609}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3609}] ~ ~ ~ function Minecraft/entitydata/mob/strider
execute @s[scores={bb=3609}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3610}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3611..3612}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3613..3615}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3616..3622}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3623..3628}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3629..3630}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3631..3632}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3633..3636}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3637..3639}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3640..3641}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3641}] ~ ~ ~ function Minecraft/entitydata/entity-007a
execute @s[scores={bb=3641}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3642}] ~ ~ ~ function Minecraft/blockdata/container/loot-007a
execute @s[scores={bb=3643..3649}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3650..3657}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3658..3659}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3660}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3661..3662}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3663..3664}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3665}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3666..3669}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3670..3671}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3671}] ~ ~ ~ function Minecraft/entitydata/mob/witherskeleton
execute @s[scores={bb=3671}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3672..3674}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3675..3677}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3678..3683}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3684..3687}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3688..3689}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3690}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3691..3692}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3693}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3694..3696}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3697..3702}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3703}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3703}] ~ ~ ~ function Minecraft/entitydata/entity-007a
execute @s[scores={bb=3703}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3704}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3705..3707}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3708}] ~ ~ ~ function Minecraft/blockdata/container/loot-007a
execute @s[scores={bb=3709..3711}] ~ ~ ~ setblock 0 0 0 soul_sand
execute @s[scores={bb=3712..3714}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3715..3717}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3718..3721}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3722..3724}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3725}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3726..3729}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3730..3733}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3733}] ~ ~ ~ function Minecraft/entitydata/mob/ghast
execute @s[scores={bb=3733}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3734..3736}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3737..3740}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3741..3742}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3743..3745}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3746}] ~ ~ ~ setblock 0 0 0 warped_nylium
execute @s[scores={bb=3747..3749}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3750..3752}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3753..3755}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3756}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3757..3760}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3761}] ~ ~ ~ setblock 0 0 0 soul_soil
execute @s[scores={bb=3762..3765}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3765}] ~ ~ ~ function Minecraft/entitydata/mob/piglin
execute @s[scores={bb=3765}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3766..3773}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3774}] ~ ~ ~ function Minecraft/blockdata/container/loot-007c
execute @s[scores={bb=3774}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=3775..3776}] ~ ~ ~ setblock 0 0 0 glowstone
execute @s[scores={bb=3777..3779}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3780..3783}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3784..3786}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3787..3790}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3791..3792}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3793..3794}] ~ ~ ~ setblock 0 0 0 nether_gold_ore
execute @s[scores={bb=3794}] ~ ~ ~ function Minecraft/entitydata/mob/magmacube
execute @s[scores={bb=3794}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3795..3803}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3804}] ~ ~ ~ setblock 0 0 0 nether_wart_block
execute @s[scores={bb=3805..3807}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3808..3809}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3810}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3811..3812}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3813..3816}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3817..3823}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3824..3826}] ~ ~ ~ setblock 0 0 0 red_nether_brick
execute @s[scores={bb=3826}] ~ ~ ~ function Minecraft/entitydata/mob/hoglin
execute @s[scores={bb=3826}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3827..3830}] ~ ~ ~ setblock 0 0 0 quartz_ore
execute @s[scores={bb=3831..3834}] ~ ~ ~ setblock 0 0 0 blackstone
execute @s[scores={bb=3835}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3836..3839}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3840}] ~ ~ ~ function Minecraft/blockdata/container/loot-007a
execute @s[scores={bb=3841}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3842}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3843..3846}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3847..3850}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3851..3854}] ~ ~ ~ setblock 0 0 0 crimson_nylium
execute @s[scores={bb=3855}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3856}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3856}] ~ ~ ~ function Minecraft/entitydata/mob/blaze
execute @s[scores={bb=3856}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=3857}] ~ ~ ~ setblock 0 0 0 magma
execute @s[scores={bb=3858..3860}] ~ ~ ~ setblock 0 0 0 gilded_blackstone
execute @s[scores={bb=3861..3863}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3864..3865}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3866..3871}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3872..3875}] ~ ~ ~ setblock 0 0 0 basalt
execute @s[scores={bb=3876..3879}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3880..3883}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3884}] ~ ~ ~ setblock 0 0 0 obsidian
execute @s[scores={bb=3885}] ~ ~ ~ function Minecraft/blockdata/block-007a
execute @s[scores={bb=3886..3887}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3888..3893}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3894}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3895..3900}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3901..3902}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3903..3905}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3906}] ~ ~ ~ function Minecraft/blockdata/container/loot-007a
execute @s[scores={bb=3907..3910}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3911..3913}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3914..3917}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3918..3920}] ~ ~ ~ setblock 0 0 0 shroomlight
execute @s[scores={bb=3921..3924}] ~ ~ ~ setblock 0 0 0 nether_brick
execute @s[scores={bb=3925}] ~ ~ ~ function Minecraft/blockdata/container/loot-007d
execute @s[scores={bb=3926}] ~ ~ ~ scoreboard players set @s ss 80
execute @s[scores={bb=3926}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=3926}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9