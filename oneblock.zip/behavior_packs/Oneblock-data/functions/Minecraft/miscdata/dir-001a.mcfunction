
## This map based of Oneblock by IJAMinecraft
## This content was created by IJAMinecraft, you can visit his site at the link here: ijaminecraft.com or visit his own Youtube: IJAMinecraft
## One Block version 2.0.3 McLogic By CuBeyzM ( It is forbidden to change or steal our content without the knowledge of the manager or content owner, to get permission or information you can contact us via email : cbz.official.id@gmail.com )
## My YouTube: CubeyzM

particle minecraft:llama_spit_smoke 0 0.8 0

execute @s[tag=c0] ~ ~ ~ effect @e[tag=boss] instant_health 1 0 true
scoreboard players add @s hp 4
execute @s[scores={bb=49..57}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=62}] ~ ~ ~ playsound item.spyglass.use @a[r=10] 0 1 0 0.6 1
execute @s[scores={bb=62}] ~ ~ ~ tellraw @a[r=60] {"rawtext":[{"translate":"mojang.text.msg10"}]}
execute @s[scores={bb=58..61}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=62..66}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=67..68}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={bb=69}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=70}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=71..76}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=77}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=78..83}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=84..88}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=84}] ~ ~ ~ summon pig 0 1 0
execute @s[scores={bb=84}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=89}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={bb=90..91}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=92..97}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=98}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={bb=99..103}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=103}] ~ ~ ~ summon cow 0 1 0
execute @s[scores={bb=103}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=104..106}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=107}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=108}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=109}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={bb=110..114}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=115}] ~ ~ ~ function Minecraft/blockdata/container/loot-001a
execute @s[scores={bb=115}] ~ ~ ~ function Minecraft/audiodata/sound-02a
execute @s[scores={bb=116..120}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=120}] ~ ~ ~ summon sheep 0 1 0
execute @s[scores={bb=120}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=121}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={bb=122}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={bb=123..124}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={bb=125}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=126}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={bb=127}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=128}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=129..135}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=136..137}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=138..139}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=139}] ~ ~ ~ summon chicken 0 1 0
execute @s[scores={bb=139}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=140}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=141..143}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=144}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={bb=145}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=146..155}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=156}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=157..158}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=158}] ~ ~ ~ summon pig 0 1 0
execute @s[scores={bb=158}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=159..164}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=165}] ~ ~ ~ function Minecraft/blockdata/container/loot-001a
execute @s[scores={bb=166}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=167..168}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=169}] ~ ~ ~ setblock 0 0 0 pumpkin
execute @s[scores={bb=170..171}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=172..175}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=175}] ~ ~ ~ function Minecraft/entitydata/entity-001a
execute @s[scores={bb=175}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=176..183}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=184}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=185..190}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=191..192}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=193..194}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=194}] ~ ~ ~ summon cow 0 1 0
execute @s[scores={bb=194}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=195..196}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=197..199}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=200}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=201..203}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=204}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=205}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=206..209}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=210}] ~ ~ ~ setblock 0 0 0 melon_block
execute @s[scores={bb=211..212}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=213}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=213}] ~ ~ ~ function Minecraft/entitydata/entity-001a
execute @s[scores={bb=213}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=214}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=215}] ~ ~ ~ function Minecraft/blockdata/container/loot-001a
execute @s[scores={bb=216..226}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=227..228}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={bb=229..230}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=230}] ~ ~ ~ summon sheep 0 1 0
execute @s[scores={bb=230}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=231..232}] ~ ~ ~ setblock 0 0 0 grass
execute @s[scores={bb=233..235}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=236..237}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={bb=238}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=239}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=240..242}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=243..244}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=245..246}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={bb=247}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=248}] ~ ~ ~ function Minecraft/blockdata/block-001a
execute @s[scores={bb=249}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={bb=249}] ~ ~ ~ summon chicken 0 1 0
execute @s[scores={bb=249}] ~ ~ ~ function Minecraft/audiodata/sound-01a
execute @s[scores={bb=250..251}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=252}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=253}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=254..255}] ~ ~ ~ setblock 0 0 0 podzol
execute @s[scores={bb=256..257}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=258..259}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=260}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=261..262}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=263}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=264}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=265}] ~ ~ ~ function Minecraft/blockdata/container/loot-001a
execute @s[scores={bb=266..268}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=269}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=270}] ~ ~ ~ setblock 0 0 0 log 2
execute @s[scores={bb=271}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=272}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=273..274}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=275}] ~ ~ ~ setblock 0 0 0 clay
execute @s[scores={bb=276}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=277}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=278..279}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=280}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=281}] ~ ~ ~ setblock 0 0 0 log
execute @s[scores={bb=282}] ~ ~ ~ function Minecraft/blockdata/container/loot-001b
execute @s[scores={bb=283}] ~ ~ ~ scoreboard players set @s ss 20
execute @s[scores={bb=283}] ~ ~ ~ particle minecraft:totem_particle 0 0.9 0
execute @s[scores={bb=283}] ~ ~ ~ playsound random.orb @a 0 1 0 1.1 0.9