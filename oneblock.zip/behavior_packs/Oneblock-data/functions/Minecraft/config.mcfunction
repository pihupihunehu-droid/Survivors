gamerule functioncommandlimit 5000


## One Block version 2.4.0 McLogic By CuBeyzM
## This map based of Oneblock by IJAMinecraft
## This content was created by IJAMinecraft, you can visit his site at the link here: ijaminecraft.com or visit his own Youtube: IJAMinecraft
## to get permission or information you can contact us via email : cbz.official.id@gmail.com


##=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
## Through this document we let you know that our "CBZ Studio" team works continuously to offer you quality content, for which we kindly ask you to respect the following.
##
## You Can :
##
## - Modify our content for personal use only
## - Use our plugins for your projects as long as you grant us our credits
## - Share our work on gameplays or reviews, as long as you put our credits and original download links in the description.
## - Report to users or platforms that are violating these terms and conditions.
##
## It's Forbidden :
##
## - Remove creator credits
## - Modify or steal our content
## - Add your own shorteners or ads to download our content
## - Re-upload our content on other platforms without authorization
##
## WARNING
## If our team finds content of our authorship on other platforms without authorization and that violate our copyright terms and conditions, we will proceed to legally report it on the corresponding platform, since it would be considered a fraudulent act, in addition to which you must pay compensation for lost and illegal distribution of our content (All this will come from not reaching an agreement)
##
## to get permission or information you can contact us via Email
##
## [] Contacts []      
## Email      : cbz.official.id@gmail.com
## IG            : @Curezor
## Youtube : CubeyzM
##
## [] Creators []
## [🇮🇩] Design        : Arta Mulyana
## [🇮🇩] Debuger     : Nabila Rachmadani
##
## No other person than the mentioned Owner or Manager can grant permissions regarding the content of the CBZ Studio.
##=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=

#hybrid-data: #tick-event
execute @e[tag=s] ~ ~ ~ function Minecraft/globaldata/rca-main
execute @a ~ ~ ~ function Minecraft/globaldata/rca-register
tp @e[tag=boss,tag=!del] 0 0.4975 0
tp @e[tag=npc] 0 3 0
tp @e[tag=dis] 0 3.545 0
execute @p[tag=o,tag=!c] ~ ~ ~ function Minecraft/eventdata/playerbgs
scoreboard objectives add blockdisplay dummy " §l§6Leaderboard §r"
scoreboard objectives setdisplay list blockdisplay
scoreboard objectives setdisplay belowname bb