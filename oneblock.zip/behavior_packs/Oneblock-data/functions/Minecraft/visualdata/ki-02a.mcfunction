#particle minecraft:death_explosion_emitter 0 1 0
particle minecraft:cauldron_explosion_emitter 0 1 0