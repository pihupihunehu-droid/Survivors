##VFX: render_dragonui

particle minecraft:enchanting_table_particle 0 1 0
particle minecraft:enchanting_table_particle 0.1 1 0
particle minecraft:enchanting_table_particle 0 1 0.1
particle minecraft:enchanting_table_particle 0.15 1 0
particle minecraft:enchanting_table_particle 0 1 0.15
particle minecraft:enchanting_table_particle 0.15 1 0.15
particle minecraft:enchanting_table_particle 0 1 0.2
particle minecraft:enchanting_table_particle 0.2 1 0